var board = 'mac808_B';

function boardInit (aForConfig)
{
	if (aForConfig)
		document.title="Dateq MAC808 Configuration";
	else
		document.title="Dateq MAC808";
}

function boardPostInit (aForConfig)
{
	if (aForConfig) {
		$('#room-amplifier').css('visibility', 'visible');
	}
	$('#temperature').css('visibility', 'visible');
}
