mom.changed.zones = new notifier('zones');
mom.changed.combies = new notifier('combies');
mom.changed.busy = new notifier('busy');

var busyC = {combi : false, zone : false };

function parseBusy (data) {
	if (dataChanged('busy',data)){
		mom.busy = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		mom.changed.busy.notify();
	}
}

function urlBusy(){
	return 'cfg=1&busy=?';
}

function getBusy () {
	balancedAjax({
		url			: urlBusy(),
		async		: false,
		success	: parseBusy
	}); 
}

function parseCombiesConfig(data){
	if (dataChanged('combies',data)){	
		mom.combies = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		c = mom.config.max_combies; 
		while (c >= 1 && mom.combies[c-1] == null) {
			mom.combies[c-1] = {"name":"combi_"+c.toString(), "master":0,"active":0,"multi":0,"outputs":"0x0"};
			c--;
		}
		mom.changed.combies.notify();
	}		
}

function urlCombiesConfig(){
	return 'cfg=1&_combies=?';
}

function getCombiesConfig(){
	if (busyC.combi) return;
	balancedAjax({
		url			: urlCombiesConfig(),
		async		: false,
		success	: parseCombiesConfig
	});
}

function parseZonesConfig(data){
	if (dataChanged('zones',data)){
		mom.zones = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		z = mom.config.max_zones; 
		while (z >= 1 && mom.zones[z-1] == null) {
			mom.zones[z-1] = {"name":"zone_"+c.toString(), "outputs":"0x0"};
			z--;
		}
		mom.changed.zones.notify();
	}
}

function urlZonesConfig(){
	return 'cfg=1&_zones=?';
}

function getZonesConfig(){
	if (busyC.zone) return;
	balancedAjax({
		url			: urlZonesConfig(),
		async		: false,
		success	: parseZonesConfig
	});
}

function inCombiActive(output){
	var ca = hexToBinArr(mom.busy.combies_active);
	for (var c = 1; c <= ca.length; c++){
		if (ca[ca.length - c]==1) {
			co =  hexToBinArr(mom.combies[c-1].outputs);
			if (co[co.length - output]==1) {
				return {"combi" : c, "master" : (output == mom.combies[c-1].master)};
			}
		}
	}
	return 0;
}

function displayListBusy(tag){
	if (!mom.busy) return;
	var busyClasses = 'busy-no busy-paging busy-combi busy-paging-combi';
	var masterClasses = 'busy-slave busy-master';
	var showBusy = busyClasses.split(' ');
	var showMaster = masterClasses.split(' ');
	var p = hexToBinArr(mom.busy.page_outputs);
	var c = hexToBinArr(mom.busy.combi_outputs);
	var b, o, stat, thisCombi, info;
	for (var n = 1; n <= maxRooms(); n++){
		o = room2Output(n);
		stat = p[64-o] + 2*c[64-o];
		info ='';
		master = 0;
		if ((mom.config.max_combies > 1) && (stat == 2 || stat == 3)) {
			thisCombi = inCombiActive(o);
			master = thisCombi.master?1:0;
			if (thisCombi.combi > 0) info = thisCombi.combi.toString();
		}		
		$(tag+n.toString()).html(info).removeClass(busyClasses+' '+masterClasses).addClass(showBusy[stat]+' '+showMaster[master]);
	}
}

function displayOutputBusy(roomNr, tag){
	if (!mom.busy || roomNr == 0) return;
	var busyTexts = ['','{in_active_paging}','{in_active_combi}','{in_active_paging_combi}'];
	var masterTexts = ['{slave}','{master}'];
	var p = hexToBinArr(mom.busy.page_outputs);
	var c = hexToBinArr(mom.busy.combi_outputs);
	var b, thisCombi, info;
	var o = room2Output(roomNr);
	var stat = p[64-o] + 2*c[64-o];
	info ='';
	master = 0;
	if ((mom.config.max_combies > 1) && (stat == 2 || stat == 3)) {
		thisCombi = inCombiActive(o);
		master = thisCombi.master?1:0;
		if (thisCombi.combi > 0) info = thisCombi.combi.toString();
	}
	if (stat == 0) 
		$(tag).html('');
	else
		$(tag).html(xLateKey(masterTexts[master])+' '+xLateKey(busyTexts[stat])+info);
}



