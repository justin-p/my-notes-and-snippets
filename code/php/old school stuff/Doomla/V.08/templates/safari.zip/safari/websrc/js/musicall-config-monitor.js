mom.changed.monitor = new notifier();

function parseMonitor(data) {
	if (dataChanged('monitor',data)){
		var newMon = data.split('&')[1].split('=')[1];
		if (newMon != '?'){
			mom.monitor = jQuery.parseJSON(newMon);

			if (mom.monitor.output != 0) {
				var name = outputConnection (mom.monitor.output);
				$("#monitor-label").text("Output "+name);
				$('#monitor-check').attr('checked',true);
			} else {
				$("#monitor-label").text("");
				$('#monitor-check').removeAttr('checked');
			}
		}	
	}
}	

function checkMonitor(actNr) { // A different output has been selected
	if (mom.monitor && mom.monitor.output) { // If the monitor function is active:
			var outputNr = room2Output(actNr);
			if (mom.monitor.output != outputNr) {
					mom.monitor.output = outputNr;
					mom.monitor.confirm = 1;
					setConfig('monitor=*&settings='+encodeURIComponent($.toJSON(mom.monitor)), false);
			}
	}
}

function urlMonitor(){
	return 'monitor=*&settings={confirm:true}';
}

function getMonitor () {
	balancedAjax({
			url			: urlMonitor(),
			async		: true,
			success	: parseMonitor
	});
}

function flipMonitorUse(onOff) { // Checkbox has been pressed
	var outputNr = room2Output(roomNr(0));
	mom.monitor.output = (onOff)?outputNr:0;
	mom.monitor.confirm = 1;
	setConfig('monitor=*&settings='+encodeURIComponent($.toJSON(mom.monitor)), false);
	mom.changed.monitor.notify();
}