// Extracted from source SourceVersion 2.31f and translation musicall.yaml
// 11-12-2011 0:03:17
// 23-2-2012 ST: vertalingen
// http://www.w3schools.com/tags/ref_entities.asp

var uiText = {
	"Language" :
	{
		"limit" : "20",
		"EN" : "Language",
		"NL" : "Taal",
		"FR" : "Langue",
		"DE" : "Sprache"
	},
	"language_option" :
	{
		"EN" : "English",
		"NL" : "Nederlands",
		"FR" : "Fran&ccedil;ais",
		"DE" : "Deutsch"
	},
	"General" :
	{
		"EN" : "General",
		"NL" : "Algemeen",
		"FR" : "G&eacute;n&eacute;ral",
		"DE" : "Allgemein"
	},
	"Inputs" :
	{
		"EN" : "Inputs",
		"NL" : "Ingangen",
		"FR" : "Entr&eacute;e",
		"DE" : "Eingang"
	},
	"Outputs" :
	{
		"EN" : "Outputs",
		"NL" : "Uitgangen",
		"FR" : "Sortie",
		"DE" : "Ausgang"
	},
	"Scrolls" :
	{
		"EN" : "Scrolls",
		"NL" : "Scrolls",
		"FR" : "Rouleaux ",
		"DE" : "Scrolls"
	},
	"PagingParty" :
	{
		"EN" : "Paging/Party",
		"NL" : "Oproep/Feest",
		"FR" : "Appelez/F&ecirc;te",
		"DE" : "Anruf/Fest"
	},
	"Stations" :
	{
		"EN" : "FM presets",
		"NL" : "Voorkeuze zenders",
		"FR" : "FM Preset fr&eacute;quence",
		"DE" : "FM Voreinstellungen"
	},
	"Racks" :
	{
		"EN" : "IP settings",
		"NL" : "IP instellingen",
		"FR" : "IP Param&egrave;tres",
		"DE" : "IP einstellungen"
	},
	"Monitor" :
	{
		"EN" : "Headphone",
		"NL" : "Koptelefoon",
		"FR" : "Casque",
		"DE" : "Kopfh&ouml;rer "
	},
	"not_active" :
	{
		"EN" : "Not active",
		"NL" : "Niet aktief",
		"FR" : "?not_active",
		"DE" : "?not_active"
	},
	"Connect" :
	{
		"EN" : "Type",
		"NL" : "Type",
		"FR" : "Type",
		"DE" : "Typus"
	},
	"ST" :
	{
		"EN" : "ST",
		"NL" : "ST",
		"FR" : "ST",
		"DE" : "ST"
	},
	"Name" :
	{
		"EN" : "Name",
		"NL" : "Naam",
		"FR" : "Nom",
		"DE" : "Name"
	},
	"Default" :
	{
		"EN" : "Default settings",
		"NL" : "Opstart waarden",
		"FR" : "D&eacute;faut",
		"DE" : "Grundeinstellung"
	},
	"gain" :
	{
		"EN" : "gain",
		"NL" : "versterking",
		"FR" : "gain",
		"DE" : "gain"
	},
	"Owner" :
	{
		"EN" : "Linked to",
		"NL" : "Eigenaar",
		"FR" : "Li&eacute; &agrave;",
		"DE" : "Inhaber"
	},
	"Station" :
	{
		"EN" : "Station name",
		"NL" : "Stations naam",
		"FR" : "Nom des stations",
		"DE" : "Stationen name"
	},
	"Tuner" :
	{
		"EN" : "Tuner",
		"NL" : "Radio",
		"FR" : "Radio",
		"DE" : "Radio"
	},
	"Output" :
	{
		"EN" : "Output",
		"NL" : "Uitgang",
		"FR" : "Sortie",
		"DE" : "Ausgang"
	},
	"open" :
	{
		"EN" : "Open",
		"NL" : "Open",
		"FR" : "Ouvrir",
		"DE" : "&Ouml;ffnen "
	},
	"Scroll" :
	{
		"EN" : "Scroll",
		"NL" : "Scroll",
		"FR" : "?Scroll",
		"DE" : "?Scroll"
	},
	"Inputs_available" :
	{
		"EN" : "Inputs Available",
		"NL" : "Ingangen",
		"FR" : "?Inputs_available",
		"DE" : "?Inputs_available"
	},
	"Stations_available" :
	{
		"EN" : "Stations Available",
		"NL" : "Radio stations",
		"FR" : "?Stations_available",
		"DE" : "?Stations_available"
	},
	"move_selected_channels" :
	{
		"EN" : "Move selected channels",
		"NL" : "Verplaats geselecteerde scrolls",
		"FR" : "?move_selected_channels",
		"DE" : "?move_selected_channels"
	},
	"Nr" :
	{
		"EN" : "Nr",
		"NL" : "Nr",
		"FR" : "Nr",
		"DE" : "Nr"
	},
	"Freq" :
	{
		"EN" : "Frequency",
		"NL" : "Frequentie",
		"FR" : "Fr&eacute;quence",
		"DE" : "Frequenz"
	},
	"drop_preset_here_to_remove" :
	{
		"EN" : "Drag and drop preset here to remove",
		"NL" : "Sleep voorkeuze hierheen om te verwijderen",
		"FR" : "Drag and drop pr&eacute;d&eacute;finis ici &agrave; supprimer",
		"DE" : "Drag & Drop hier voreingestellt auf Entfernen"
	},
	"New_list" :
	{
		"EN" : "New preset list",
		"NL" : "Nieuwe voorkeuze lijst",
		"FR" : "Nouveau liste de preset fr&eacute;quence",
		"DE" : "Neue voreinstellungen liste"
	},
	"previous_station" :
	{
		"EN" : "Previous station",
		"NL" : "Vorig station",
		"FR" : "Station pr&eacute;cedente",
		"DE" : "Niedrigere Frequenz"
	},
	"double_click_to_edit" :
	{
		"EN" : "Double-click to edit",
		"NL" : "Double-click om te wijzigen",
		"FR" : "?double_click_to_edit",
		"DE" : "?double_click_to_edit"
	},
	"press_Enter_to_submit" :
	{
		"EN" : "Press Enter to submit",
		"NL" : "Druk op Enter om toe te passen",
		"FR" : "?press_Enter_to_submit",
		"DE" : "?press_Enter_to_submit"
	},
	"next_station" :
	{
		"EN" : "Next station",
		"NL" : "Volgend station",
		"FR" : "Station suivante",
		"DE" : "H&ouml;here Frequenz"
	},
	"add_to_preset_stations" :
	{
		"EN" : "Add to list preset stations",
		"NL" : "Voeg toe aan de voorkeuze lijst",
		"FR" : "Ajouter &agrave; la liste",
		"DE" : "Zur voreinstellung liste hinzuf&uuml;gen"
	},
	"preset" :
	{
		"EN" : "Add to list",
		"NL" : "Toevoegen",
		"FR" : "Ajouter",
		"DE" : "Hinzuf&uuml;gen"
	},
	"Pi_code" :
	{
		"EN" : "Program id",
		"NL" : "Programma id",
		"FR" : "Programme id",
		"DE" : "Program id"
	},
	"RDS" :
	{
		"EN" : "RDS info",
		"NL" : "RDS info",
		"FR" : "RDS info",
		"DE" : "RDS info"
	},
	"RSSI" :
	{
		"EN" : "Signal level (dBuV)",
		"NL" : "Signaal sterkte (dBuV)",
		"FR" : "Force du signal (dBuV)",
		"DE" : "Signalst&auml;rke (dBuV)"
	},
	"Room" :
	{
		"EN" : "Output",
		"NL" : "Uitgang",
		"FR" : "Sortie",
		"DE" : "Ausgang"
	},
	"Input" :
	{
		"EN" : "Input",
		"NL" : "Ingang",
		"FR" : "Entree",
		"DE" : "Eingang"
	},
	"volume" :
	{
		"EN" : "Volume",
		"NL" : "Volume",
		"FR" : "Volume",
		"DE" : "Volume"
	},
	"bass" :
	{
		"EN" : "Bass",
		"NL" : "Laag",
		"FR" : "L&acirc;che",
		"DE" : "Tief"
	},
	"mid" :
	{
		"EN" : "Mid",
		"NL" : "Midden",
		"FR" : "Centre",
		"DE" : "Mittel"
	},
	"treble" :
	{
		"EN" : "Treble",
		"NL" : "Hoog",
		"FR" : "Haut",
		"DE" : "Hoch"
	},
	"balance" :
	{
		"EN" : "Balance",
		"NL" : "Balans",
		"FR" : "Balance",
		"DE" : "Ausgleich"
	},
	"muted" :
	{
		"EN" : "Audio muted",
		"NL" : "Geluid uit",
		"FR" : "Audio mut&eacute;",
		"DE" : "Mute Audio"
	},
	"amplified" :
	{
		"EN" : "Amplifier",
		"NL" : "Versterker",
		"FR" : "Amplificateur",
		"DE" : "Endstufen"
	},
	"info" :
	{
		"EN" : "Information",
		"NL" : "Informatie",
		"FR" : "Renseignement",
		"DE" : "Auskunft"
	},
	"RDS_on_Wall_Controller" :
	{
		"EN" : "RDS information on wallcontroller",
		"NL" : "RDS informatie op wandregelaar",
		"FR" : "RDS info sur le r&eacute;gulateur de mur",
		"DE" : "RDS auskunft auf wandregler"
	},
	"Outputs_Stereo_Mono" :
	{
		"EN" : "Outputs Stereo/Mono",
		"NL" : "Uitgangen Stereo/Mono",
		"FR" : "?Outputs_Stereo_Mono",
		"DE" : "?Outputs_Stereo_Mono"
	},
	"All_outputs_Stereo" :
	{
		"EN" : "All outputs Stereo",
		"NL" : "Alle uitgangen Stereo",
		"FR" : "?All_outputs_Stereo",
		"DE" : "?All_outputs_Stereo"
	},
	"All_outputs_Mono" :
	{
		"EN" : "All outputs Mono",
		"NL" : "Alle uitgangen Mono",
		"FR" : "?All_outputs_Mono",
		"DE" : "?All_outputs_Mono"
	},
	"Output_1_3_Stereo" :
	{
		"EN" : "Output 1 to 3 Stereo",
		"NL" : "Uitg 1 t/m 3 Stereo",
		"FR" : "?Output_1_3_Stereo",
		"DE" : "?Output_1_3_Stereo"
	},
	"Output_1_2_Stereo" :
	{
		"EN" : "Output 1 and 2 Stereo",
		"NL" : "Uitg 1 en 2 Stereo",
		"FR" : "?Output_1_2_Stereo",
		"DE" : "?Output_1_2_Stereo"
	},
	"Output_1_Stereo" :
	{
		"EN" : "Output 1 Stereo",
		"NL" : "Uitg 1 Stereo",
		"FR" : "?Output_1_Stereo",
		"DE" : "?Output_1_Stereo"
	},
	"Output_2_4_Stereo" :
	{
		"EN" : "Output 2 to 4 Stereo",
		"NL" : "Uitg 2 t/m 4 Stereo",
		"FR" : "?Output_2_4_Stereo",
		"DE" : "?Output_2_4_Stereo"
	},
	"Output_3_4_Stereo" :
	{
		"EN" : "Output 3 and 4 Stereo",
		"NL" : "Uitg 3 en 4 Stereo",
		"FR" : "?Output_3_4_Stereo",
		"DE" : "?Output_3_4_Stereo"
	},
	"Output_4_Stereo" :
	{
		"EN" : "Output 4 Stereo",
		"NL" : "Uitg 4 Stereo",
		"FR" : "?Output_4_Stereo",
		"DE" : "?Output_4_Stereo"
	},
	"Internal_amplifiers" :
	{
		"EN" : "Internal Amplifiers",
		"NL" : "Interne versterkers",
		"FR" : "?Internal_amplifiers",
		"DE" : "?Internal_amplifiers"
	},
	"Chime" :
	{
		"EN" : "Chime",
		"NL" : "Dingdong",
		"FR" : "?Chime",
		"DE" : "?Chime"
	},
	"play" :
	{
		"EN" : "Play",
		"NL" : "Afspelen",
		"FR" : "Jouer",
		"DE" : "Abspielen"
	},
	"My_settings" :
	{
		"EN" : "My Settings",
		"NL" : "Mijn instellingen",
		"FR" : "?My_settings",
		"DE" : "?My_settings"
	},
	"My_settings_file" :
	{
		"EN" : "Settings file",
		"NL" : "Instellingen bestand",
		"FR" : "?My_settings_file",
		"DE" : "?My_settings_file"
	},
	"Load" :
	{
		"EN" : "Load",
		"NL" : "Laden",
		"FR" : "Charger",
		"DE" : "Laden"
	},
	"Save" :
	{
		"EN" : "Save",
		"NL" : "Opslaan",
		"FR" : "Pr&eacute;server",
		"DE" : "Behalten"
	},
	"Restore" :
	{
		"EN" : "Restore",
		"NL" : "Herstellen",
		"FR" : "Restaurer",
		"DE" : "Zur&uuml;ck"
	},
	"Factory_settings" :
	{
		"EN" : "Factory settings",
		"NL" : "Fabrieks instellingen",
		"FR" : "R&eacute;glages par d&eacute;faut d'usine",
		"DE" : "Werkseinstellungen"
	},
	"Input_settings" :
	{
		"EN" : "Input Settings",
		"NL" : "Ingang instellingen",
		"FR" : "Param&egrave;tres d'entr&eacute;e ",
		"DE" : "Eingang einstellungen "
	},
	"Outputs_and_scrolls" :
	{
		"EN" : "Outputs and scrolls",
		"NL" : "Uitgangen en scrolls",
		"FR" : "?Outputs_and_scrolls",
		"DE" : "?Outputs_and_scrolls"
	},
	"Tuners_and_stations" :
	{
		"EN" : "Tuners and stations",
		"NL" : "Tuners en stations",
		"FR" : "?Tuners_and_stations",
		"DE" : "?Tuners_and_stations"
	},
	"Paging_zones" :
	{
		"EN" : "Paging zones",
		"NL" : "Oproen zones",
		"FR" : "Appelez",
		"DE" : "Anruf zones"
	},
	"Room_combi" :
	{
		"EN" : "Room Combining",
		"NL" : "Ruimte koppeling",
		"FR" : "?Room_combi",
		"DE" : "?Room_combi"
	},
	"slave" :
	{
		"EN" : "slave",
		"NL" : "slave",
		"FR" : "?slave",
		"DE" : "?slave"
	},
	"master" :
	{
		"EN" : "master",
		"NL" : "master",
		"FR" : "?master",
		"DE" : "?master"
	},
	"in_active_paging" :
	{
		"EN" : "in paging",
		"NL" : "in paging",
		"FR" : "?in_active_paging",
		"DE" : "?in_active_paging"
	},
	"in_active_combi" :
	{
		"EN" : "in active combi",
		"NL" : "in koppeling",
		"FR" : "?in_active_combi",
		"DE" : "?in_active_combi"
	},
	"in_active_paging_combi" :
	{
		"EN" : "in combi+paging",
		"NL" : "in koppeling+paging",
		"FR" : "?in_active_paging_combi",
		"DE" : "?in_active_paging_combi"
	},
	"State" :
	{
		"EN" : "",
		"NL" : "",
		"FR" : "",
		"DE" : ""
	},
	"range" :
	{
		"EN" : "Min/Max",
		"NL" : "Min/Max",
		"FR" : "Min/Max",
		"DE" : "Min/Max"
	},
	"treb" :
	{
		"EN" : "Treble",
		"NL" : "Hoog",
		"FR" : "?treb",
		"DE" : "?treb"
	},
	"page_ofs" :
	{
		"EN" : "Paging",
		"NL" : "Oproep",
		"FR" : "Appel",
		"DE" : "Anruf"
	},
	"Muted" :
	{
		"EN" : "Default output muted",
		"NL" : "Geluid uit bij opstarten",
		"FR" : "D&eacute;faut audio mut&eacute;",
		"DE" : "Grundeinstelling audio muted"
	},
	"User_balance_allowed" :
	{
		"EN" : "User balance allowed",
		"NL" : "User balance toegestaan",
		"FR" : "?User_balance_allowed",
		"DE" : "?User_balance_allowed"
	},
	"Chimes_allowed" :
	{
		"EN" : "Chimes allowed",
		"NL" : "Dingdong toegestaan",
		"FR" : "?Chimes_allowed",
		"DE" : "?Chimes_allowed"
	},
	"Paging_allowed" :
	{
		"EN" : "Paging_allowed",
		"NL" : "Paging toegestaan",
		"FR" : "?Paging_allowed",
		"DE" : "?Paging_allowed"
	},
	"GPIO" :
	{
		"EN" : "GPIO",
		"NL" : "GPIO",
		"FR" : "?GPIO",
		"DE" : "?GPIO"
	},
	"upload" :
	{
		"EN" : "upload",
		"NL" : "upload",
		"FR" : "?upload",
		"DE" : "?upload"
	},
	"Local_name" :
	{
		"EN" : "Local_name",
		"NL" : "Local naam",
		"FR" : "?Local_name",
		"DE" : "?Local_name"
	},
	"Amplified" :
	{
		"EN" : "Amplified",
		"NL" : "Versterkt",
		"FR" : "?Amplified",
		"DE" : "?Amplified"
	},
	"no_chime" :
	{
		"EN" : "No chime",
		"NL" : "Geen chime",
		"FR" : "?no_chime",
		"DE" : "?no_chime"
	},
	"no_chime_to_play" :
	{
		"EN" : "no_chime_to_play",
		"NL" : "Geen chimes om af te spelen",
		"FR" : "?no_chime_to_play",
		"DE" : "?no_chime_to_play"
	},
	"public" :
	{
		"EN" : "public",
		"NL" : "Gezamelijke ingang",
		"FR" : "Commun d'Entr&eacute;e",
		"DE" : "Gemeinsame eingang"
	},
	"Paging" :
	{
		"EN" : "Paging",
		"NL" : "Oproep",
		"FR" : "Appelez",
		"DE" : "Anruf"
	},
	"PartyMaster" :
	{
		"EN" : "PartyMaster",
		"NL" : "PartyMaster",
		"FR" : "?PartyMaster",
		"DE" : "?PartyMaster"
	},
	"line_out_only" :
	{
		"EN" : "Only line-out",
		"NL" : "Alleen line-out",
		"FR" : "?line_out_only",
		"DE" : "?line_out_only"
	},
	"always_on" :
	{
		"EN" : "(Always aan)",
		"NL" : "(Altijd aan)",
		"FR" : "?always_on",
		"DE" : "?always_on"
	},
	"line_out_internal_amplifier" :
	{
		"EN" : "line_out_internal_amplifier",
		"NL" : "Heeft ook line-out",
		"FR" : "?line_out_internal_amplifier",
		"DE" : "?line_out_internal_amplifier"
	},
	"Help_RDS_on_Wall_Controller" :
	{
		"EN" : "RDS information visible on wallcontroller",
		"NL" : "RDS informatie zichtbaar op wandregelaar",
		"FR" : "Information RDS apparant sur le r&eacute;gulateur de mur",
		"DE" : "RDS auskunft sichtbar auf wandregler"
	},
	"Help_language" :
	{
		"EN" : "Help language",
		"NL" : "Help taal",
		"FR" : "?Help_language",
		"DE" : "?Help_language"
	},
	"Chimes_list" :
	{
		"EN" : "Chime list",
		"NL" : "Geluiden lijst",
		"FR" : "?Chimes_list",
		"DE" : "?Chimes_list"
	},
	"delete" :
	{
		"EN" : "Delete",
		"NL" : "Verwijder",
		"FR" : "Effacer",
		"DE" : "Eliminieren"
	},
	"wait_restart" :
	{
		"EN" : "?wait_restart",
		"NL" : "?wait_restart",
		"FR" : "?wait_restart",
		"DE" : "?wait_restart"
	},
	"language_after_refresh" :
	{
		"EN" : "?language_after_refresh",
		"NL" : "?language_after_refresh",
		"FR" : "?language_after_refresh",
		"DE" : "?language_after_refresh"
	},
	"Help_show_tone_setup_on_Wall_Controller" :
	{
		"EN" : "Tone control (Bass/Mid/Treble) can be done on the wallcontroller",
		"NL" : "Toonregeling (Bass/Mid/Treble) aan te passen op de wandregelaar",
		"FR" : "Contr&ocirc;le de tonalit&eacute; (Bass/Mid/Treble) sur le r&eacute;gulateur de mur",
		"DE" : "Klangregler (Bass/Mid/Treble) anpassen auf dem wandregler"
	},
	"Show_tone_setup_on_Wall_Controller" :
	{
		"EN" : "Tone control on wallcontroller",
		"NL" : "Toon regeling op wandregelaar",
		"FR" : "Contr&ocirc;le de tonalit&eacute;",
		"DE" : "Klangregler auf dem wandregler"
	},
	"100kHz_up" :
	{
		"EN" : "",
		"NL" : "100 kHz omhoog",
		"FR" : "",
		"DE" : ""
	},
	"100kHz_down" :
	{
		"EN" : "",
		"NL" : "100 kHz omlaag",
		"FR" : "",
		"DE" : ""
	},	
	"generate_presets_list" :
	{
		"EN" : "",
		"NL" : "Laat automatisch een nieuwe voorkeuzelijst samenstellen",
		"FR" : "",
		"DE" : ""
	},
	"New_preset_list" :
	{
		"EN" : "",
		"NL" : "Nieuwe voorkeuzelijst",
		"FR" : "",
		"DE" : ""
	},
	"not_selected" :
	{
		"EN" : "",
		"NL" : "Niet geselecteerd",
		"FR" : "",
		"DE" : ""
	}	,
	"no_file_selected" :
	{
		"EN" : "",
		"NL" : "Geen bestand geselecteerd",
		"FR" : "",
		"DE" : ""
	},
	"cannot_remove_owned_input_from_scroll" :
	{
		"EN" : "",
		"NL" : "Je kunt geen aan output toegewezen input verwijderen van de scroll",
		"FR" : "",
		"DE" : ""
	},
	"not_accepted" :
	{
		"EN" : "",
		"NL" : "niet toegestaan",
		"FR" : "",
		"DE" : ""
	},
	"maximum_presets_reached_at" :
	{
		"EN" : "",
		"NL" : "maximu aantal voorkeurzenders bereikt",
		"FR" : "",
		"DE" : ""
	}
};


