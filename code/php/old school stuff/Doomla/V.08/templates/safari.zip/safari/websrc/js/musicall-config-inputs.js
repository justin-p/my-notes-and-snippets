var myInputUpdate = false;
var channelScrollRegion = 0;
var channelConnectionHTML = '';
var busyI = {owner : false, gain : false, station : false};
var station2 = -1;

function tunerActive() {
	return (selectedTab() == 'config-inputs');
}

function displayChannel(chanNr){
	getInputConfig(chanNr);
	if (board=='mac808_B'){
		if (inputType(channel2Input(chanNr)) != 'TUNER') 
			$('#owner-selection').attr('disabled','disabled');
		else
			$('#owner-selection').removeAttr('disabled');
	}		
	inputsTuner.tuner = input2Tuner(channel2Input(chanNr));
}

function freqStation(freq){
	for (var stationNr = 0; stationNr < mom.stations.length; stationNr++ ) {
		if (mom.stations[stationNr].freq == freq) return stationNr;
	}
	return null;
}

function parseTunerStation(tuner, data) {
	var station = freqStation(data.split('&')[1].split('=')[1]);
	if ((station2 == -1) || (station2 != station)) {
		if (station == null) {
			station = 0;
			setTunerStation(tuner, station); //reset to first preset
		}
		tunerStationNr(station);
		station2 = station;
	}	
}

function getTunerStation(tuner) {
	if (busyI['station']) return;
	balancedAjax({
		url: 'radio='+tuner+'&_fmchannel=?',
		success : function(data) { parseTunerStation(tuner, data);}
	});
}

function setTunerStation(tuner, station) {
	balancedAjax({
		url: 'radio='+tuner+'&_fmchannel='+mom.stations[station].freq
	});	
}

function displayInputLevel(id, setNr) {
	id = id.replace('_','');
	if ((setNr != null) && ($('#'+id).slider('value') != setNr)){
			$('#'+id).slider('value', setNr);
			$('#x'+id).text(mom.config[id+'_ofs']+setNr);
	}
}

function publicTunerStation() {
	if (typeof inputsTuner != 'undefined'){
	if (inputsTuner.tuner > 0)  {
		$('#inputs-tuner-box').css('visibility','visible');
		if (ownerNr() == 0) //public
			$('#tuner-station').css('visibility','visible');
		else
			$('#tuner-station').css('visibility','hidden');	
		if (mom.stations.length > 0) getTunerStation(inputsTuner.tuner);
	} else {
		$('#tuner-station').css('visibility','hidden');	
		$('#inputs-tuner-box').css('visibility','hidden');
	}
	}
}

function parseInputConfig(data){
	if (myInputUpdate) return; 
	mom.inputSettings = jQuery.parseJSON(data.split('&')[1].split('=')[1] );
	for (var s in mom.inputSettings) {
		switch (s){
			case 'gain'		: if (!busyI[s])displayInputLevel(s, mom.inputSettings[s]); break;
			case 'owner'	: if (!busyI[s])ownerNr(output2Room(mom.inputSettings[s])); publicTunerStation(); break;
		}	
	}
}

function urlInputConfig(){
	var c = chanNr();
	if (c <= 0) return '';
	return 'input='+channel2Input(c)+'&_settings=?';
}

function getInputConfig (chanNr) {
	if (chanNr <= 0) return;
	balancedAjax({
		url: 'input='+channel2Input(chanNr)+'&_settings=?',
		success: function (data) { parseInputConfig (data); }
	});
}

function setInputConfig (chanNr, property, value, forced) {
	myInputUpdate = true;
	balancedAjax({
		url: 'input='+channel2Input(chanNr)+'&'+property+'='+value,
		forced: (forced)?forced:false,
		complete: function(){myInputUpdate = false;}
	});
}

function chanNr(setNr) {
	var actNr = 0;	
	if ($.exists('#channel-selection .selected'))
		actNr = parseInt($('#channel-selection .selected').attr('id').replace('channel-row',''));
	if (typeof setNr != 'undefined' && setNr != actNr) {
		actNr = setNr;	
		$('#channel-selection .selected').removeClass('selected');
		$('#channel-row'+setNr).addClass('selected');
		displayChannel(actNr);
	}
	return actNr;	
}

function ownerNr(setNr) {
	// set
	if (setNr != null) {
			$('select#owner-selection').val(setNr.toString());
			return setNr;
	} else {
	//get
		setNr = $('select#owner-selection').val();
		if (setNr) 
			return parseInt(setNr);
		else
			return -1;
	}
}

function changeOwner(ownerNr) {
	setInputConfig(chanNr(), '_owner', room2Output(ownerNr));
}

function displayOwnerlist() {
	var o = ownerNr();
	var view = '<option class="owner-selector" value="0">{public}</option>';
	for (var n = 1; n <= maxRooms(); n++)
		view += '<option class="owner-selector" value="'+n.toString()+'">'+outputName(room2Output(n)) +'</option>';
	$('#owner-selection').html(xLateText(view));
	if (o > maxRooms()) ownerNr(maxRooms());	
}

function tunerStationNr(setNr) {
	actNr = $('#default-station-selection').prop("selectedIndex");
	if (setNr != null && setNr != actNr) {
			actNr = setNr;
			$('#default-station-selection').prop('selectedIndex', '-1');
			$('#station'+actNr).attr('selected','selected');
	}
	return actNr;		
}

function displayStationlist() {
	var view = '';
for (var stationNr = 0; stationNr < mom.stations.length; stationNr++ ){
		view += '<option class="station-selector" id="station'+stationNr+'">'+mom.stations[stationNr].name +'</option>';
	}
	if (view == '') {
		view = '<option>none</option>';
		$('#default-station-selection').attr('disabled','disabled');
	} else $('#default-station-selection').removeAttr('disabled');
	$('#default-station-selection').html(view);
}

function checkInStereo(obj) {
	var n = channel2Input(parseInt(obj.attr('name').replace('channel-stereo','')));
	flipInStereo(n);
	if (chanNr() > maxChannels()) chanNr(maxChannels());
}

function changeChannelName(obj) {
	var n = channel2Input(parseInt(obj.attr('name').replace('channel-name','')));
	changeInputName(n, obj.val());
}

function activateChannelRows() {
	$('.channel-selector')
		.mousedown(function (){$(this).click();})
		.click(function (){
			chanNr(parseInt($(this).attr('id').replace('channel','')));
		});
	$('.channel-connection .channel-stereo').click(function () {
		checkInStereo($(this));
	});
		
	$('.channel-connection .channel-name').change(function () {
		changeChannelName($(this));
	});
}

function initChannelScrollRegion() {
	channelScrollRegion.update();
}

function initInputTab() {
	initChannelScrollRegion();
}

function displayChannelList() {
	var c = chanNr(); if (c > maxChannels()) c = maxChannels();
	var focusObj = $('input:focus');
	var shown = 0;
	for (var n = 1; n <= maxChannels(); n++){
		var connection = inputConnection(channel2Input(n));
		if (board!='mac808_B' || connection != connectionStreaming){
			shown++;
		// add new channel row
			if (!$.exists('#channel-row'+n.toString())){
				var thisRow = channelConnectionHTML
					.replace(/_row_/g,n.toString())
					.replace('<tabindex>',n);
				$('#channel-selection').append(thisRow);
			}
			// refresh this channel row
			$('#channel'+n.toString()).html(connection);
			$('[name="channel-name'+n.toString()+'"]').val(inputName(channel2Input(n)))
			if (isStereo(channel2Input(n),mom.input.stereo))
				$('[name="channel-stereo'+n.toString()+'"]').attr('checked','checked');
			else	
				$('[name="channel-stereo'+n.toString()+'"]').removeAttr('checked');
			if (inputType(channel2Input(n)) == 'TUNER') 
				$('[name="channel-stereo'+n.toString()+'"]').attr('disabled','disabled');
			else
				$('[name="channel-stereo'+n.toString()+'"]').removeAttr('disabled');
		}		
	}
	// remove obsolete channel rows
	var l = $('.channel-connection').length;
	for (var obs = shown+1; obs <= l; obs++)
		$('#channel-row'+obs.toString()).remove();
	
	activateChannelRows();
	if (channelScrollRegion.update) channelScrollRegion.update();
	focusObj.focus();
}

function channelListChange() {
	displayChannelList();
	displayChannel(chanNr());
}

function inputSlide(data){
	var id = $(data.me).attr('id');		
	$('#x'+id).text(mom.config[id.replace('_','')+'_ofs']+data.ui.value);
	setInputConfig(chanNr(),'_'+id, data.ui.value, (data.forced)?data.forced:false);			
}

function configInputView(){
	channelConnectionHTML = getHTML('html/config-input-channel-connection-view.html');
	inputsTuner = new tunerControl('inputs-tuner',0,pollCycle, tunerActive);
	registerPoll(['config-inputs'],{id : 'setting'},{url: inputsTuner.urlPollOneFreq, success: inputsTuner.parseOneFreq, info : inputsTuner});		

	document.write(getHTML('html/config-input-view.html').replace('<tuner-control>',inputsTuner.view()));	
	inputsTuner.activate();
	displayOwnerlist();

	$('div.input-slider').each(function() {
		$(this).empty().slider({
			value: 1,
			min: 0,
			max: mom.config[$(this).attr('id').replace('_','')+'_range']-1,
			range: 'min',
			animate: true,
			orientation: 'vertical',
			slide: function( event, ui ) {
				inputSlide({me : this, ui : ui});
			},
			start : function(){canPoll = false; busyI[$(this).attr('id')] = true;},
			stop : function(event, ui){
				inputSlide({me : this, ui : ui, forced : true});
				busyI[$(this).attr('id')] = false;
				canPoll = true;
			}
		});
		var me = this;
		var id = $(this).attr('id');
		$('#'+id+'-box').mouseleave(
			function(){
					if (busyI[id]) { $(me).mouseup(); }
			}
		);
	});
		
	$('#owner-selection').change(function(){
		changeOwner(ownerNr());
		busyI['owner'] = false;
	});
	
	$('#owner-selection')
	.mousedown(function(){busyI['owner'] = true;})
	.blur(function() {busyI['owner'] = false;});
	
	$('#default-station-selection')
	.change(function(){
		setTunerStation(inputsTuner.tuner, tunerStationNr());
		busyI['station'] = false;
	});
	
	$('#default-station-selection')
	.mousedown(function(){busyI['station'] = true;})
	.blur(function() {busyI['station'] = false;});

	channelScrollRegion = $('#channelregion');
	channelScrollRegion.tinyscrollbar();
	mom.changed.input.register(channelListChange);
	mom.changed.output.register(displayOwnerlist);
	mom.changed.stations.register(displayStationlist);
}