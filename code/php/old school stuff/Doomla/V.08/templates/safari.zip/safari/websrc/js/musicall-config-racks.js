//var racks = new Array();
var rackHTML = '';
var rackScrollRegion = 0;
mom.changed.racks = new notifier();

function changeRackName(obj) {
	var n = parseInt(obj.attr('name').replace('rack-name',''))-1;
	mom.racks[n].name = obj.val();
	balancedAjax({
		url: 'net=1&names={"mac":"' +mom.racks[n].mac +'", "name":"' + mom.racks[n].name + '","ip":"'+mom.racks[n].ip+'" }'
	});
	$('#rack'+(n+1).toString()).attr('href','http://'+mom.racks[n].name+'/config.html');
	mom.changed.racks.notify(true);
}

function changeRackDHCP(obj){
	var n = parseInt(obj.attr('name').replace('rack-dhcp',''))-1;
	mom.racks[n].dhcp = (obj.is(':checked'))?1:0;
	balancedAjax({
		url: 'net=1&names={"mac":"' +mom.racks[n].mac +'", "dhcp":"' + mom.racks[n].dhcp + '","ip":"'+mom.racks[n].ip+'" }',
		async : false,
		success : function(){
			if (mom.racks[n].dhcp ==1){
				$('input[name="rack-ip'+(n+1).toString()+'"]').attr('disabled',true);
				$('input[name="rack-name'+(n+1).toString()+'"]').focus();	
			}	
			else {
				$('input[name="rack-ip'+(n+1).toString()+'"]').removeAttr('disabled');	
				$('input[name="rack-ip'+(n+1).toString()+'"]').focus();	
			}	
		}
	});
	mom.changed.racks.notify(true);
}

function parseRackIP(data,n){
	var oneRack = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]))[0];
	if (mom.racks[n].ip != oneRack.ip){
		alert('IP :'+mom.racks[n].ip+' '+ xLateText('{not_accepted}'));
		mom.racks[n].ip = oneRack.ip;
		$('input[name="rack-ip'+(n+1).toString()+'"]').val(mom.racks[n].ip);
	}	
	mom.changed.racks.notify(true);
}

function changeRackIP(obj){
	var n = parseInt(obj.attr('name').replace('rack-ip',''))-1;
	mom.racks[n].ip = obj.val();
	balancedAjax({
		url			: 'net=1&names={"mac":"' +mom.racks[n].mac +'","ip":"'+mom.racks[n].ip+'" }',
		success	: function(data){parseRackIP(data, n);}
	});
}

function linkRack(obj){
	var n = parseInt(obj.attr('id').replace('rack-link',''))-1;
	window.location = 'http://'+mom.racks[n].name+'/config.html';
}

function myRackName(){
	for (var p in mom.racks) {
		if (firm.mac == mom.racks[p].mac) return mom.racks[p].name;
	}
	return 'undefined';
}

function displayRacks(){

	var focusObj = $('input:focus');
	for (var p in mom.racks) {
		var n = parseInt(p) + 1;
		if (!$.exists('#rack'+n.toString())){
		// add new rack row
			$('#rack-selection').append(
				rackHTML
					.replace(/_row_/g,n.toString())
					.replace('<ip-tabindex>',(n*5+1).toString())
					.replace('<name-tabindex>',(n*5+2).toString()));			
			} 
			// refresh this rack row
			if (mom.racks[p].dhcp==1){
				$('[name="rack-dhcp'+n.toString()+'"]').attr('checked','checked');
				$('[name="rack-ip'+n.toString()+'"]').attr('disabled','disabled');
			} else {
				$('[name="rack-dhcp'+n.toString()+'"]').removeAttr('checked')
				$('[name="rack-ip'+n.toString()+'"]').removeAttr('disabled');
			}
			$('[name="rack-ip'+n.toString()+'"]').val(mom.racks[p].ip);
			$('[name="rack-name'+n.toString()+'"]').val(mom.racks[p].name);
	}
	// remove obsolete rack rows
	var l = $('.rack').length;
	for (var obs = n+1; obs <= l; obs++)
		$('#rack'+obs.toString()).remove();

	// re-activate handlers
	$('.rack-dhcp').click(function(){changeRackDHCP($(this));});
	$('.rack-ip').blur(function(){changeRackIP($(this));});
	$('.rack-link').click(function(){linkRack($(this));});
	$('.rack-name').blur(function () {changeRackName($(this));});
	focusObj.select();

	rackScrollRegion.update();
}

function parseRacksConfig (data){
	if (dataChanged('racks',data)){
		mom.racks = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		displayRacks();
		mom.changed.racks.notify();
	}	
}

function urlRacksConfig(){
	return 'net=1&names=?';
}

function getRacksConfig(){
	balancedAjax({
		async		: false,
		url			: urlRacksConfig(),
		success	: parseRacksConfig
	});
}

function initRacksTab(){
	getRacksConfig();
	rackScrollRegion.update();
}

function configRacksView(){
	rackHTML = getHTML('html/config-rack-view.html');
	document.write(getHTML('html/config-racks-view.html'));	
	rackScrollRegion = $('#racksregion');
	rackScrollRegion.tinyscrollbar();
}