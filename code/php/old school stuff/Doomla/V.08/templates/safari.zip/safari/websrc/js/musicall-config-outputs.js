var myOutputUpdate = false;
var myPush = false;
var pushCycle = 2000;
var roomScrollRegion = 0;
var roomConnectionHTML = '';
var busyO = {vchan : false, range : false, volume : false, bass : false, mid : false, treble : false, balance : false, page_ofs : false};

function displayRoom(roomNr){
	$('.balance').css('display',((isStereo(room2Output(roomNr),mom.output.stereo))?'block':'none'));
	//displayOutputBusy(roomNr, '.busy'); ?????????????????????????????????? waarom uitgevlagd?
	getOutputConfig(roomNr);
}

function getBalanceDim(aOutputNr) {
	if (!isStereo(aOutputNr,mom.output.stereo))
		return 0;
	var balanceMid = mom.config['balance_ofs'];
	var balance = mom.outputSettings['balance'];
	if ((aOutputNr & 1) == 0) { // Is it a stereo/right room, i.e. even number
		if (balance >= balanceMid)
			return 0;
		return balanceMid - balance;
	} else { // It is a stereo/left room
		if (balance <= balanceMid)
			return 0;
		return balance - balanceMid;
	}
}

function showDecibels(curVolume) {
	var balanceDim = 0; // getBalanceDim(1);
	var gain = inputGain (mom.outputSettings['channel']);
	var minLevel = 
		(mom.outputSettings['min'] + (gain + mom.config['gain_ofs'])) * 2; // Input gain in 1 dB steps (40 dB range)
	var maxVolume = (mom.config['volume_range']-1); // = 50
	var maxLevel = 130 + 2 * mom.outputSettings['max']; // Makes a Max of 132 + 120 = 252
	decibels = minLevel + ((curVolume * (maxLevel - minLevel)) / maxVolume) - 2 * balanceDim;
	var dbs = "muted";
	if (decibels > minLevel) {
		if (decibels > maxLevel)
			decibels = maxLevel;
		decibels = Math.round(-191 + decibels);
		if ((decibels & 1) == 0) {
			dbs = decibels / 2 + ".0";
		} else {
			dbs = decibels / 2;
		}
	}
	$('#voldbs').text(dbs + ' dB');
}
//	int minLevel =
//		(audioValues[mainRoom].minLevel +
//		 (inputValues[aInputNr].level - GAIN_OFFS)) * 2;  // Input gain in 1 dB steps (40 dB range)
//	int maxLevel = 130 + MAX_LEVEL_STEP * audioValues[mainRoom].maxLevel; // Makes a Max of 132 + 120 = 252
//	int retVal = minLevel + ((volume * (maxLevel - minLevel)) / LEVEL_MAX) - BALANCE_STEP * balanceDim;
//	int retVal = minLevel + ((volume * (maxLevel - minLevel)) / LEVEL_MAX) - BALANCE_STEP * balanceDim;
	// 254 = +31.5 dB
	// 253 = +31.0 dB
	// ...
	// 191 =   0.0 dB
	// 190 =  -0.5 dB
	// ...
	// 130 = -30.0 dB
	// ..
	//   2 = -94.5 dB
	//   1 = -95.0 dB
	//   0 = muted

function displayOutputLevel(id, setNr) {
	if (BrowserDetect.browser == 'Explorer' && selectedTab() != 'config-outputs') return;
	//id = id.replace('_','');
	if ((setNr != null) && ($('#'+id).slider('value') != setNr)){
			$('#'+id).slider('value', setNr);
			$('#x'+id).text(mom.config[id+'_ofs']+setNr);
			if (id == 'volume')
				showDecibels(setNr);
	}
}

function displayMin( setNr ){
	if (BrowserDetect.browser == 'Explorer' && selectedTab() != 'config-outputs') return;
	if ((setNr != null) && ($('#range').slider('values',0) != setNr)){
		$('#range').slider('values',0, setNr);
	}
	$('#minrange').text(setNr + mom.config.min_ofs + ' dB');
} 

function displayMax( setNr ){
	if (BrowserDetect.browser == 'Explorer' && selectedTab() != 'config-outputs') return;
	setNr += mom.config.max_ofs - mom.config.min_ofs;
	if ((setNr != null) && ($('#range').slider('values',1) != setNr)){
		$('#range').slider('values',1, setNr);
	}
	$('#maxrange').text(setNr + mom.config.min_ofs - 1 + ' dB');
} 

function setOutputConfig (query, forced) {
	myOutputUpdate = true;
	balancedAjax({
		url			: query,
		async		: true,
		forced	: (forced)?forced:false,
		complete: function(){
			myOutputUpdate = false;
		},
	});
}

function displayRoomChannels(vchan) {
	var view = '';
	for (var c = 0; c < mom.roomChannels.length; c++) 
		view += '<option class="room-channel-selector" value="'+c.toString()+'">'+mom.roomChannels[c].name+'</option>';
	$('#room-channel-selection').html(view);
	if (vchan > 0) roomChanNr(vchan);
}

function displayRoomMuted(muted){
	if (muted)
		$('#room-muted input').attr('checked','checked');
	else	
		$('#room-muted input').removeAttr('checked');
}

function displayRoomAmplifier(amplified){
	if (amplified)
		$('#room-amplifier input').attr('checked','checked');
	else	
		$('#room-amplifier input').removeAttr('checked');
}

function parseOutputConfig(data) {
	if (myOutputUpdate) return;
	var data1 = data.split('&')[1].split('=')[1];
	var data2 = data.split('&')[2].split('=')[1];
	if (dataChanged('1output',data1)){
		mom.outputSettings = jQuery.parseJSON(data.split('&')[1].split('=')[1]);
		for (var s in mom.outputSettings) {
			switch (s){
				case 'vchan'		: if (!busyO[s]) var vchan = mom.outputSettings[s]-1; break;
				case 'min'			: if (!busyO['range']) displayMin(mom.outputSettings[s]);
				case 'max'			: if (!busyO['range']) displayMax(mom.outputSettings[s]);
				case 'volume'		: ;
				case 'bass'			: ;
				case 'mid'			: ;
				case 'treble'		: ;
				case 'balance'	: ;
				case 'page_ofs' : if (!busyO[s]) displayOutputLevel(s,mom.outputSettings[s]); break;	
				case 'muted'		: displayRoomMuted(mom.outputSettings[s]==1); break;			
				case 'amp'			: displayRoomAmplifier(mom.outputSettings[s]==1); break;			
			}
		}
	}
	if (dataChanged('roomchannels',data2)){
		mom.roomChannels = jQuery.parseJSON( decodeURIComponent(data.split('&')[2].split('=')[1]) );
		displayRoomChannels(vchan);
	} else roomChanNr(vchan);
}

function urlOutputConfig(){
	var r = roomNr();
	return 'output='+room2Output(r)+'&_settings=?&chn_list=?';
}

function getOutputConfig(roomNr) {
	balancedAjax({
		url: 'output='+room2Output(roomNr)+'&_settings=?&chn_list=?',
		success: parseOutputConfig
	});
}

function roomChanNr(setNr) {
	//set
	if (setNr != null) {
			$('select#room-channel-selection').val(setNr.toString());
			return setNr;
	} else {
	//get
		setNr = $('select#room-channel-selection').val();
		if (setNr) 
			return parseInt(setNr);
		else
			return -1;
	}
}

// selected room 	get/set
function roomNr(setNr) {
	var actNr = 0;
	if ($.exists('#room-selection .selected')) 
		actNr = parseInt($('#room-selection .selected').attr('id').replace('room-row',''));
	if (actNr == 0 && setNr <= 0) setNr = 1;
	if  (setNr > 0 && setNr != actNr) { //set
		actNr = setNr;
		$('#room-selection .selected').removeClass('selected');
		$('#room-row'+actNr).addClass('selected');
		displayRoom(actNr);
		checkMonitor(actNr);
	}
	return actNr;
}

function changeRoomChannel(chanNr){
	setRoomSettings(roomNr(), '_vchan', chanNr+1);
}

function changeOneRoomAmp(obj){
	var roomNr = parseInt(obj.attr('name').replace('room-amp',''));
	setRoomSettings(roomNr,'_amp',(obj.is(':checked'))?'1':'0');
}

function checkOutStereo(obj) {
	var n = room2Output(parseInt(obj.attr('name').replace('room-stereo','')));
	flipOutStereo(n);
	if (roomNr() > maxRooms()) roomNr(maxRooms());
}

function changeRoomName(obj) {
	var n = room2Output(parseInt(obj.attr('name').replace('room-name','')));
	changeOutputName(n, obj.val());
}

function isTesting() {
	return 	false;//true; //$('.room-setting input[name=istest]').attr('checked');
}

function initOutputTab(){
	roomScrollRegion.update();
	displayRoom(roomNr());
}

function activateRoomRows(){
	$('.room-selector')	.mousedown(function (){$(this).click();})
											.click(function (){
		roomNr(parseInt($(this).attr('id').replace('room','')));
	});
	$('.room-connection .room-stereo').click(function () {
		checkOutStereo($(this));
	});
	
	$('.room-connection .room-name').change(function () {
		changeRoomName($(this));
	});
}

function displayRoomlist() {
	r = roomNr(); if (r > maxRooms()) r = maxRooms();
	var focusObj = $('input:focus');
	for (var n = 1; n <= maxRooms(); n++){
		// add new room row
		if (!$.exists('#room-row'+n.toString())){
			var thisRow = roomConnectionHTML
									.replace(/_row_/g,n.toString())
									.replace('<tabindex>',100+n);		
			$('#room-selection').append(thisRow);
		} 
		
		$('#room'+n.toString()).html(outputConnection(room2Output(n)));
		$('[name="room-name'+n.toString()+'"]').val(outputName(room2Output(n)))
		if (isStereo(room2Output(n),mom.output.stereo))
			$('[name="room-stereo'+n.toString()+'"]').attr('checked','checked');
		else	
			$('[name="room-stereo'+n.toString()+'"]').removeAttr('checked');
	}
	// remove obsolete room rows
	var l = $('.room-connection').length;
	for (var obs = n; obs <= l; obs++)
		$('#room-row'+obs.toString()).remove();
	roomNr(r);
	displayListBusy('#room-state');
	activateRoomRows();
	if (roomScrollRegion.update) roomScrollRegion.update();
	focusObj.focus();
}

function setRoomSettings(roomNr, property, value, forced) {
	myOutputUpdate = true; // block interference from polls en echo's
	var p =((property != 'default') && (isTesting()))?'&default=0':'';
	setOutputConfig('output='+room2Output(roomNr)+'&'+property+'='+value+p, forced);	
}

function pushDefaultSettings() {
	if ((selectedTab() != 'config-outputs') || (roomNr() == 0))return;
	if (isTesting()) {
		myPush = true;
		setRoomSettings(roomNr(), 'default', 0);
	}
}

function roomListChange() {
	displayRoomlist()
	displayRoom(roomNr());
}

function changeRoomMuted(roomNr) {
	setRoomSettings(roomNr,'_muted',($('#room-muted input').is(':checked'))?'1':'0');
}
function changeRoomAmplifier(roomNr) {
	setRoomSettings(roomNr,'_amp',($('#room-amplifier input').is(':checked'))?'1':'0');
}

function delayedSlideMinMax(data){
	setTimeout(function(data){slideMinMax(data);},10,data);
}

function slideMinMax (data) {
	var maxLimited = false;
	var max = data.ui.values[1] - mom.config.max_ofs + mom.config.min_ofs;
	if (max < 0){
		max = 0;
		$('#range').slider('values', 1, mom.config.max_ofs - mom.config.min_ofs );
		maxLimited = true;
	}
	var maxShown = max + mom.config.max_ofs - 1;
	setRoomSettings(roomNr(), '_max', max,(data.forced)?data.forced:false);
	$('#maxrange').text(maxShown+ ' dB');
	
	var minLimited = false;
	var min = data.ui.values[0];
	if (min > mom.config.min_range - 1) {
		min = mom.config.min_range - 1;
		$('#range').slider('values', 0, min);
		minLimited = true;
	}
	minShown = min + mom.config.min_ofs;
	setRoomSettings(roomNr(), '_min', min,(data.forced)?data.forced:false);	
	
	$('#minrange').text(minShown+ ' dB');
	return (!maxLimited && !minLimited);
}	

function slide(data) {
	var id = $(data.me).attr('id');
	setRoomSettings(roomNr(), '_'+id, data.ui.value, (data.forced)?data.forced:false);
	$('#x'+id).text(mom.config[id+'_ofs']+data.ui.value);
	if (id == "volume") {
		showDecibels(data.ui.value);
	}
}

function displayOutputListBusy(){
	displayListBusy('#room-state');
}

function displayMyOutputBusy(){
	displayOutputBusy(roomNr(),'.busy');
}

function configOutputView(){
	roomConnectionHTML = getHTML('html/board/config-output-room-connection-view.html');

	document.write(getHTML('html/board/config-output-view.html'));	
	
	$('#range').slider({
			min: 0,
			max: mom.config.max_range + mom.config.max_ofs - mom.config.min_ofs - 1,
			values : [1, mom.config.max_ofs-mom.config.min_ofs + 1],
			range: true,
			animate: false,
			orientation: 'vertical',
			slide : function(event, ui){
				slideMinMax({ui : ui});
			},
			start : function(){canPoll=false; busyO['range'] = true;},
			stop : function(event, ui){
				delayedSlideMinMax({ui : ui, forced : true});
				busyO['range'] = false;
				canPoll=true;
			}
	});
	
			var me = this;
		var id = $(this).attr('id');
		$('#range-box').mouseleave(
			function(){
					if (busyO['range']) { $('#range').mouseup(); }
			}
		);

	$('div.output-slider').each(function() {
		$(this).empty().slider({
			value: 1,
			min: 0,
			max: mom.config[$(this).attr('id')+'_range']-1,
			range: 'min',
			animate: true,
			orientation: 'vertical',
			slide: function( event, ui ) {
				slide({me : this, ui : ui});
			},
			start : function(){busyO[$(this).attr('id')] = true;
					canPoll = false;
			
			},
			stop : function(event, ui){
				slide({me : this, ui : ui, forced : true});
				busyO[$(this).attr('id')] = false;
				canPoll = true;
			}
		});
		var me = this;
		var id = $(this).attr('id');
		$('#'+id+'-box').mouseleave(
			function(){
					if (busyO[id]) { $(me).mouseup(); }
			}
		);
	});

	$('select#room-channel-selection').change(function (){
		changeRoomChannel(roomChanNr());
		busyO['vchan'] = false;
	});
	
	$('#room-channel-selection')
	.mousedown(function(){busyO['vchan'] = true;})
	.blur(function() {busyO['vchan'] = false;});

	$('#room-muted input').click(function(){
		changeRoomMuted(roomNr());
	});
	$('#room-amplifier input').click(function(){
		changeRoomAmplifier(roomNr());
	});
	
	roomScrollRegion = $('#roomregion');
	roomScrollRegion.tinyscrollbar();
	$(function(){
		mom.changed.output.register(roomListChange);
		mom.changed.busy.register(displayOutputListBusy);
		mom.changed.busy.register(displayMyOutputBusy);
	});
}
