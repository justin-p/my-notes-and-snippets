<?php
	$link = mysql_connect("localhost","root","");
	if ($link) {
		$hasDatabase = mysql_select_db("mac808");
		if (!$hasDatabase){
			$result = mysql_query("CREATE DATABASE mac808 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci");
			$hasDatabase = mysql_select_db("mac808");
			if ($hasDatabase) {
				$hasDatabase = mysql_query("CREATE TABLE IF NOT EXISTS rom (id varchar(15) NOT NULL, rom text NOT NULL, PRIMARY KEY (id)) ENGINE=MyISAM DEFAULT CHARSET=latin1");
				if (!$hasDatabase) echo "error: " . 'table could not be created ';
			}
		}
		if ($hasDatabase){
			$id = $_SERVER["REMOTE_ADDR"];
			$url = $_SERVER["REQUEST_URI"];
			$url = substr($url,strpos($url,'?')+1);
			$argValues = explode("&",substr($url,strpos($url,'?')));
			$argValue = explode("=",$argValues[0]);
			if ($argValue[0] == "action"){
				switch ($argValue[1]){
					case "save":
						$rom = $_REQUEST["rom"];
						$rows = mysql_query("SELECT id FROM rom WHERE id = '".$id."'");
						if (mysql_num_rows($rows) > 0){
							$result = mysql_query("UPDATE rom SET rom = '".$rom."' WHERE id = '".$id."'");
						} else {
							$result = mysql_query("INSERT INTO rom (id, rom) VALUES ('".$id."','".$rom."'	)");
						}	
						if ($result) echo "success: ".$result;
						break;
					case "load":
						$rows = mysql_query("SELECT * FROM rom WHERE id = '".$id."'");
						if ($row = mysql_fetch_assoc($rows)){
							echo $row["rom"];
						}
						break;
				}		
			}
		}	else {
			echo "error: "."database could not be found or created.";
		}
	} else {
		echo "error: ".mysql_error();
	}
	
	
?>