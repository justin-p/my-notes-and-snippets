function lampHandlerConfigView(lampStatus) {
	if ($('img#lamp'+lampStatus).css('visibility') == 'visible') return;
	for (var l = 0; l <=2; l++) {
		$('img#lamp'+l).css('visibility',(lampStatus==l?'visible':'hidden'));
	}
}

function startUp(){
	$('.version').text(version());
	$('#tabs').html(xLateText($('#tabs').html()));
	$('#config-monitor').html(xLateText($('#config-monitor').html()));
	$('#monitor-check').change(function(){
		flipMonitorUse($('#monitor-check').is(':checked'));
	});
	
	getBusy(); 
	displayRoomlist(); 
	roomNr(1); 
	displayChannelList(); 
	chanNr(1); 
	displayScrollRoomlist(); 
	getRacksConfig();
	getWC();
	getChimes();
	getSetup();	
	getGPIO();
	getPageRelVolume();
	getMonitor();
	
	getPollingTab = selectedTab;
	
	registerPoll(['config-outputs','config-scrolls','config-inputs','config-paging-combi'],{id : 'config', weight : 2},{url: urlOutputs, success: parseOutputs});
	if (board=='mac808_B')
		registerPoll(['config-general'],{id : 'config', weight : 2},{url: urlOutputs, success: parseOutputs});
	registerPoll(['config-outputs','config-scrolls','config-inputs','config-paging-combi'],{id : 'config'},{url: urlInputs, success: parseInputs});
	if (hasTemp) 
		registerPoll(['config-outputs','config-scrolls','config-inputs','config-paging-combi','config-general','config-stations'],
									{id : 'setting'},{url : urlTemperature, success : parseTemperature});
	registerPoll(['config-racks'],{id : 'setting', weight : 10},{url: urlRacksConfig, success: parseRacksConfig});		
	registerPoll(['config-outputs'],{id : 'setting', weight : 10},{url: urlOutputConfig, success: parseOutputConfig});		
	registerPoll(['config-inputs'],{id : 'setting', weight : 10},{url: urlInputConfig, success: parseInputConfig});		
	registerPoll(['config-scrolls'],{id : 'setting', weight : 10},{url: urlScrollList, success: parseScrollList});		
	registerPoll(['config-outputs','config-scrolls','config-inputs','config-paging-combi','config-racks'],{id : 'setting'},{url : urlBusy, success: parseBusy});
	registerPoll(['config-paging-combi'],{id : 'setting', weight : 10},{url: urlPages, success: parsePages});		
	registerPoll(['config-paging-combi'],{id : 'setting', weight : 10},{url: urlZonesConfig, success: parseZonesConfig});		
	registerPoll(['config-paging-combi'],{id : 'setting', weight : 10},{url: urlCombiesConfig, success: parseCombiesConfig});		
	registerPoll(['config-general'],{id : 'setting', weight : 10},{url: urlWC, success: parseWC});
	if (board=='mac808_B')
		registerPoll(['config-general'],{id : 'setting', weight : 10},{url: urlChimes, success: parseChimes});		
	else
		registerPoll(['config-paging-combi'],{id : 'setting', weight : 10},{url: urlChimes, success: parseChimes});	
	registerPoll(['config-general'],{id : 'setting', weight : 10},{url: urlGPIO, success: parseGPIO});	
	registerPoll(['config-general'],{id : 'setup', weight : 2},{url: urlSetup, success: parseSetup});	
	if (board=='mac808_B')
		registerPoll(['config-general'],{id : 'setting', weight : 10},{url: urlAmps, success: parseAmps});		
	registerPoll(['config-outputs','config-scrolls','config-inputs','config-paging-combi','config-general','config-stations'],
									{id : 'setting'},{url : urlMonitor, success : parseMonitor});
	registerPoll(['config-scrolls','config-inputs','config-stations'],
									{id : 'stations'},{url : urlStations, success : parseStations});

	activateAllHelp();

	var i = setInterval(pushDefaultSettings,pushCycle);
	
	initTabs();
	registerTabHandler('config-outputs',initOutputTab,'focus');
	registerTabHandler('config-inputs',initInputTab,'focus');
	registerTabHandler('config-stations',initStationScrollRegion,'focus');
	registerTabHandler('config-scrolls',focusScrollsTab,'focus');
	registerTabHandler('config-scrolls',blurScrollTab,'blur');
	registerTabHandler('config-racks',initRacksTab,'focus');
	registerTabHandler('config-paging-combi',initPagingCombiTab,'focus');
	registerTabHandler('config-general',initGeneralTab,'focus');
	
	registerLampHandler(lampHandlerConfigView);
	$('#monitor-check').change(function(){
		flipMonitorUse($('#monitor-check').is(':checked'));
	});
	$('div#container').css('visibility','visible');
}
