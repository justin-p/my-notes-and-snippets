var outputSTMO = [15,0,7,3,1,14,12,8];
var ampInfo = ['{always_on}','{always_on}','{line_out_only}', '{line_out_internal_amplifier}'];
var maxFixedAmps = 4;
var ampHTML = getHTML('html/config-output-amp-view.html');


function displayOutputSTMO(){
	for (var i in outputSTMO) {
		if (outputSTMO[i] == mom.output.stereo){
			$('#output-stmo input[value="'+i.toString()+'"]').attr('checked','true');
			return;
		}
	}
	$('#output-stmo input').click(function(){ 
		changeOutputSTMO();
	});
}

function parseAmps(data){
	//if (typeof ampData2 == 'undefined' || ampData2 != data) {
		ampData2 = data;
		var ampArr = data.split('&');
		for (var a in ampArr) {
			if (ampArr[a] != '') {
				var arg = ampArr[a].split('=');
				switch (arg[0]) {
					case 'output' : var n = output2Room(parseInt(arg[1])); break;
					case '_amp' 	: if (arg[1]==1)
														$('input[name="amp-check'+n+'"]').attr('checked','checked'); 
													else
														$('input[name="amp-check'+n+'"]').removeAttr('checked');
													break;
				}
			}
		}
//	}	
}

function urlAmps(){
	var query = '';
	for (var n = 1; n <= maxRooms(); n++){
		var o = room2Output(n);
		if (o > maxFixedAmps){
			if (query > '') query += '&&';
			query += 'output='+room2Output(n).toString()+'&_amp=?';
		}
	}
	return query;
}

function getAmps(){
	balancedAjax({
		url			: urlAmps(),
		async		: false,
		success	: parseAmps
	});
}

function activateAmpRows(){
	$('.amp-check').click(
		function(){
			var roomNr = parseInt($(this).attr('name').replace('amp-check',''));
			setRoomSettings(roomNr, '_amp', ($(this).is(":checked")?1:0));
		}
	);
}

function displayAmpList() {
	r = roomNr(); 
	view = '';
	for (var n = 1; n <= maxRooms(); n++){
		var thisRow = ampHTML
		.replace(/_row_/g,n.toString())
		.replace('<amp-label>','Output '+outputConnection(room2Output(n)));
		
		o = room2Output(n);
		c = Math.floor((o-1)/2);
		if (o <= maxFixedAmps) 
			thisRow = thisRow.replace('<amp-fixed>','checked disabled');
		else
			thisRow = thisRow.replace('<amp-fixed>','');
		thisRow = thisRow.replace('<amp-info>',xLateKey(ampInfo[c]));
		view += thisRow+'\n';
	}
	$('#int-amp-list').html(view);
	getAmps();
	activateAmpRows();
}

function changeOutputSTMO(){
	oldStereo = mom.output.stereo;
	mom.output.stereo = outputSTMO[parseInt($('#output-stmo input:checked').val())];
	if (oldStereo != mom.output.stereo){
		setConfig('cfg=*&_out_stereo='+mom.output.stereo);
	}	
}

