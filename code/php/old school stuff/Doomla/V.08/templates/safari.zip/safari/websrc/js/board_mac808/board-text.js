// Extracted from source SourceVersion 2.31f and translation musicall.yaml
// 11-12-2011 0:03:17
var uiText = {
	"Language" :
	{
		"limit" : "20",
		"EN" : "Language",
		"NL" : "Taal",
		"FR" : "Langue",
		"DE" : "?Language"
	},
	"language_option" :
	{
		"EN" : "English",
		"NL" : "Nederlands",
		"FR" : "Fran&ccedil;ais",
		"DE" : "Deutsch"
	},
	"General" :
	{
		"EN" : "General",
		"NL" : "General",
		"FR" : "?General",
		"DE" : "?General"
	},
	"Inputs" :
	{
		"EN" : "Inputs",
		"NL" : "Ingangen",
		"FR" : "?Inputs",
		"DE" : "?Inputs"
	},
	"Outputs" :
	{
		"EN" : "Outputs",
		"NL" : "Uitgangen",
		"FR" : "?Outputs",
		"DE" : "?Outputs"
	},
	"Scrolls" :
	{
		"EN" : "Scrolls",
		"NL" : "Scrolls",
		"FR" : "?Scrolls",
		"DE" : "?Scrolls"
	},
	"PagingParty" :
	{
		"EN" : "Paging/Party",
		"NL" : "Paging/Party",
		"FR" : "?PagingParty",
		"DE" : "?PagingParty"
	},
	"Stations" :
	{
		"EN" : "Radio stations",
		"NL" : "Radio stations",
		"FR" : "?Stations",
		"DE" : "?Stations"
	},
	"Racks" :
	{
		"EN" : "Racks",
		"NL" : "Racks",
		"FR" : "?Racks",
		"DE" : "?Racks"
	},
	"Monitor" :
	{
		"EN" : "Headphone",
		"NL" : "Koptelefoon",
		"FR" : "?Monitor",
		"DE" : "?Monitor"
	},
	"not_active" :
	{
		"EN" : "Not active",
		"NL" : "Niet aktief",
		"FR" : "?not_active",
		"DE" : "?not_active"
	},
	"Connect" :
	{
		"EN" : "Connect",
		"NL" : "Connect",
		"FR" : "?Connect",
		"DE" : "?Connect"
	},
	"ST" :
	{
		"EN" : "ST",
		"NL" : "ST",
		"FR" : "?ST",
		"DE" : "?ST"
	},
	"Name" :
	{
		"EN" : "Name",
		"NL" : "Naam",
		"FR" : "?Name",
		"DE" : "?Name"
	},
	"Default" :
	{
		"EN" : "Default",
		"NL" : "Default",
		"FR" : "?Default",
		"DE" : "?Default"
	},
	"gain" :
	{
		"EN" : "Gain",
		"NL" : "Gain",
		"FR" : "?gain",
		"DE" : "?gain"
	},
	"Owner" :
	{
		"EN" : "Owner",
		"NL" : "Eigenaar",
		"FR" : "?Owner",
		"DE" : "?Owner"
	},
	"Station" :
	{
		"EN" : "Station",
		"NL" : "Station",
		"FR" : "?Station",
		"DE" : "?Station"
	},
	"Tuner" :
	{
		"EN" : "Tuner",
		"NL" : "Tuner",
		"FR" : "?Tuner",
		"DE" : "?Tuner"
	},
	"Output" :
	{
		"EN" : "Output",
		"NL" : "Uitgang",
		"FR" : "?Output",
		"DE" : "?Output"
	},
	"open" :
	{
		"EN" : "Open",
		"NL" : "Open",
		"FR" : "?open",
		"DE" : "?open"
	},
	"Scroll" :
	{
		"EN" : "Scroll",
		"NL" : "Scroll",
		"FR" : "?Scroll",
		"DE" : "?Scroll"
	},
	"Inputs_available" :
	{
		"EN" : "Inputs Available",
		"NL" : "Ingangen",
		"FR" : "?Inputs_available",
		"DE" : "?Inputs_available"
	},
	"Stations_available" :
	{
		"EN" : "Stations Available",
		"NL" : "Radio stations",
		"FR" : "?Stations_available",
		"DE" : "?Stations_available"
	},
	"move_selected_channels" :
	{
		"EN" : "Move selected channels",
		"NL" : "Verplaats geselecteerde scrolls",
		"FR" : "?move_selected_channels",
		"DE" : "?move_selected_channels"
	},
	"Nr" :
	{
		"EN" : "Nr",
		"NL" : "Nr",
		"FR" : "?Nr",
		"DE" : "?Nr"
	},
	"Freq" :
	{
		"EN" : "Freq",
		"NL" : "Freq",
		"FR" : "?Freq",
		"DE" : "?Freq"
	},
	"drop_preset_here_to_remove" :
	{
		"EN" : "Drop preset here to remove",
		"NL" : "Hier presets verwijderen",
		"FR" : "?drop_preset_here_to_remove",
		"DE" : "?drop_preset_here_to_remove"
	},
	"New_list" :
	{
		"EN" : "New_list",
		"NL" : "Maak nieuwe lijst",
		"FR" : "?New_list",
		"DE" : "?New_list"
	},
	"previous_station" :
	{
		"EN" : "Prev station",
		"NL" : "Vorig station",
		"FR" : "?previous_station",
		"DE" : "?previous_station"
	},
	"double_click_to_edit" :
	{
		"EN" : "Double-click to edit",
		"NL" : "Double-click om te wijzigen",
		"FR" : "?double_click_to_edit",
		"DE" : "?double_click_to_edit"
	},
	"press_Enter_to_submit" :
	{
		"EN" : "Press Enter to submit",
		"NL" : "Druk op Enter om toe te passen",
		"FR" : "?press_Enter_to_submit",
		"DE" : "?press_Enter_to_submit"
	},
	"next_station" :
	{
		"EN" : "Next Station",
		"NL" : "Volgend station",
		"FR" : "?next_station",
		"DE" : "?next_station"
	},
	"add_to_preset_stations" :
	{
		"EN" : "Add to preset stations",
		"NL" : "Voeg toe aan lijst",
		"FR" : "?add_to_preset_stations",
		"DE" : "?add_to_preset_stations"
	},
	"preset" :
	{
		"EN" : "Preset",
		"NL" : "Preset",
		"FR" : "?preset",
		"DE" : "?preset"
	},
	"Pi_code" :
	{
		"EN" : "Pi-code",
		"NL" : "Pi-code",
		"FR" : "?Pi_code",
		"DE" : "?Pi_code"
	},
	"RDS" :
	{
		"EN" : "RDS",
		"NL" : "RDS",
		"FR" : "?RDS",
		"DE" : "?RDS"
	},
	"RSSI" :
	{
		"EN" : "RSSI",
		"NL" : "RSSI",
		"FR" : "?RSSI",
		"DE" : "?RSSI"
	},
	"Room" :
	{
		"EN" : "Room",
		"NL" : "Ruimte",
		"FR" : "?Room",
		"DE" : "?Room"
	},
	"Input" :
	{
		"EN" : "Input",
		"NL" : "Ingang",
		"FR" : "?Input",
		"DE" : "?Input"
	},
	"volume" :
	{
		"EN" : "Volume",
		"NL" : "Volume",
		"FR" : "?volume",
		"DE" : "?volume"
	},
	"bass" :
	{
		"EN" : "bass",
		"NL" : "Bass",
		"FR" : "?bass",
		"DE" : "?bass"
	},
	"mid" :
	{
		"EN" : "Mid",
		"NL" : "Mid",
		"FR" : "?mid",
		"DE" : "?mid"
	},
	"treble" :
	{
		"EN" : "Treble",
		"NL" : "Treble",
		"FR" : "?treble",
		"DE" : "?treble"
	},
	"balance" :
	{
		"EN" : "Balance",
		"NL" : "Balance",
		"FR" : "?balance",
		"DE" : "?balance"
	},
	"muted" :
	{
		"EN" : "Muted",
		"NL" : "Muted",
		"FR" : "?muted",
		"DE" : "?muted"
	},
	"amplified" :
	{
		"EN" : "Amplified",
		"NL" : "Versterkt",
		"FR" : "?amplified",
		"DE" : "?amplified"
	},
	"info" :
	{
		"EN" : "Info",
		"NL" : "Info",
		"FR" : "?info",
		"DE" : "?info"
	},
	"RDS_on_Wall_Controller" :
	{
		"EN" : "RDS on Wall Controller",
		"NL" : "RDS zichtbaar op Wand controller",
		"FR" : "?RDS_on_Wall_Controller",
		"DE" : "?RDS_on_Wall_Controller"
	},
	"Outputs_Stereo_Mono" :
	{
		"EN" : "Outputs Stereo/Mono",
		"NL" : "Uitgangen Stereo/Mono",
		"FR" : "?Outputs_Stereo_Mono",
		"DE" : "?Outputs_Stereo_Mono"
	},
	"All_outputs_Stereo" :
	{
		"EN" : "All outputs Stereo",
		"NL" : "Alle uitgangen Stereo",
		"FR" : "?All_outputs_Stereo",
		"DE" : "?All_outputs_Stereo"
	},
	"All_outputs_Mono" :
	{
		"EN" : "All outputs Mono",
		"NL" : "Alle uitgangen Mono",
		"FR" : "?All_outputs_Mono",
		"DE" : "?All_outputs_Mono"
	},
	"Output_1_3_Stereo" :
	{
		"EN" : "Output 1 to 3 Stereo",
		"NL" : "Uitg 1 t/m 3 Stereo",
		"FR" : "?Output_1_3_Stereo",
		"DE" : "?Output_1_3_Stereo"
	},
	"Output_1_2_Stereo" :
	{
		"EN" : "Output 1 and 2 Stereo",
		"NL" : "Uitg 1 en 2 Stereo",
		"FR" : "?Output_1_2_Stereo",
		"DE" : "?Output_1_2_Stereo"
	},
	"Output_1_Stereo" :
	{
		"EN" : "Output 1 Stereo",
		"NL" : "Uitg 1 Stereo",
		"FR" : "?Output_1_Stereo",
		"DE" : "?Output_1_Stereo"
	},
	"Output_2_4_Stereo" :
	{
		"EN" : "Output 2 to 4 Stereo",
		"NL" : "Uitg 2 t/m 4 Stereo",
		"FR" : "?Output_2_4_Stereo",
		"DE" : "?Output_2_4_Stereo"
	},
	"Output_3_4_Stereo" :
	{
		"EN" : "Output 3 and 4 Stereo",
		"NL" : "Uitg 3 en 4 Stereo",
		"FR" : "?Output_3_4_Stereo",
		"DE" : "?Output_3_4_Stereo"
	},
	"Output_4_Stereo" :
	{
		"EN" : "Output 4 Stereo",
		"NL" : "Uitg 4 Stereo",
		"FR" : "?Output_4_Stereo",
		"DE" : "?Output_4_Stereo"
	},
	"Internal_amplifiers" :
	{
		"EN" : "Internal Amplifiers",
		"NL" : "Interne versterkers",
		"FR" : "?Internal_amplifiers",
		"DE" : "?Internal_amplifiers"
	},
	"Chime" :
	{
		"EN" : "Chime",
		"NL" : "Dingdong",
		"FR" : "?Chime",
		"DE" : "?Chime"
	},
	"play" :
	{
		"EN" : "Play",
		"NL" : "Afspelen",
		"FR" : "?play",
		"DE" : "?play"
	},
	"My_settings" :
	{
		"EN" : "My Settings",
		"NL" : "Mijn Settings",
		"FR" : "?My_settings",
		"DE" : "?My_settings"
	},
	"My_settings_file" :
	{
		"EN" : "Settings file",
		"NL" : "Settings bestand",
		"FR" : "?My_settings_file",
		"DE" : "?My_settings_file"
	},
	"Load" :
	{
		"EN" : "Load",
		"NL" : "Laden",
		"FR" : "?Load",
		"DE" : "?Load"
	},
	"Save" :
	{
		"EN" : "Save",
		"NL" : "Opslaan",
		"FR" : "?Save",
		"DE" : "?Save"
	},
	"Restore" :
	{
		"EN" : "Restore",
		"NL" : "Herstellen",
		"FR" : "?Restore",
		"DE" : "?Restore"
	},
	"Factory_settings" :
	{
		"EN" : "Factory Settings",
		"NL" : "Fabriek Settings",
		"FR" : "?Factory_settings",
		"DE" : "?Factory_settings"
	},
	"Input_settings" :
	{
		"EN" : "Input Settings",
		"NL" : "Ingang Settings",
		"FR" : "?Input_settings",
		"DE" : "?Input_settings"
	},
	"Outputs_and_scrolls" :
	{
		"EN" : "Outputs and scrolls",
		"NL" : "Uitgangen en scrolls",
		"FR" : "?Outputs_and_scrolls",
		"DE" : "?Outputs_and_scrolls"
	},
	"Tuners_and_stations" :
	{
		"EN" : "Tuners and stations",
		"NL" : "Tuners en stations",
		"FR" : "?Tuners_and_stations",
		"DE" : "?Tuners_and_stations"
	},
	"Paging_zones" :
	{
		"EN" : "Paging zones",
		"NL" : "Paging zones",
		"FR" : "?Paging_zones",
		"DE" : "?Paging_zones"
	},
	"Room_combi" :
	{
		"EN" : "Room Combining",
		"NL" : "Ruimte koppeling",
		"FR" : "?Room_combi",
		"DE" : "?Room_combi"
	},
	"slave" :
	{
		"EN" : "slave",
		"NL" : "slave",
		"FR" : "?slave",
		"DE" : "?slave"
	},
	"master" :
	{
		"EN" : "master",
		"NL" : "master",
		"FR" : "?master",
		"DE" : "?master"
	},
	"in_active_paging" :
	{
		"EN" : "in paging",
		"NL" : "in paging",
		"FR" : "?in_active_paging",
		"DE" : "?in_active_paging"
	},
	"in_active_combi" :
	{
		"EN" : "in active combi",
		"NL" : "in koppeling",
		"FR" : "?in_active_combi",
		"DE" : "?in_active_combi"
	},
	"in_active_paging_combi" :
	{
		"EN" : "in combi+paging",
		"NL" : "in koppeling+paging",
		"FR" : "?in_active_paging_combi",
		"DE" : "?in_active_paging_combi"
	},
	"State" :
	{
		"EN" : "State",
		"NL" : "Status",
		"FR" : "?State",
		"DE" : "?State"
	},
	"range" :
	{
		"EN" : "range",
		"NL" : "Min.Max",
		"FR" : "?range",
		"DE" : "?range"
	},
	"treb" :
	{
		"EN" : "treb",
		"NL" : "Hoog",
		"FR" : "?treb",
		"DE" : "?treb"
	},
	"page_ofs" :
	{
		"EN" : "Page_ofs",
		"NL" : "Page ofs",
		"FR" : "?page_ofs",
		"DE" : "?page_ofs"
	},
	"Muted" :
	{
		"EN" : "Muted",
		"NL" : "Muted",
		"FR" : "?Muted",
		"DE" : "?Muted"
	},
	"User_balance_allowed" :
	{
		"EN" : "User balance allowed",
		"NL" : "User balance toegestaan",
		"FR" : "?User_balance_allowed",
		"DE" : "?User_balance_allowed"
	},
	"Chimes_allowed" :
	{
		"EN" : "Chimes allowed",
		"NL" : "Dingdong toegestaan",
		"FR" : "?Chimes_allowed",
		"DE" : "?Chimes_allowed"
	},
	"Paging_allowed" :
	{
		"EN" : "Paging_allowed",
		"NL" : "Paging toegestaan",
		"FR" : "?Paging_allowed",
		"DE" : "?Paging_allowed"
	},
	"GPIO" :
	{
		"EN" : "GPIO",
		"NL" : "GPIO",
		"FR" : "?GPIO",
		"DE" : "?GPIO"
	},
	"upload" :
	{
		"EN" : "upload",
		"NL" : "upload",
		"FR" : "?upload",
		"DE" : "?upload"
	},
	"Local_name" :
	{
		"EN" : "Local_name",
		"NL" : "Local naam",
		"FR" : "?Local_name",
		"DE" : "?Local_name"
	},
	"Amplified" :
	{
		"EN" : "Amplified",
		"NL" : "Versterkt",
		"FR" : "?Amplified",
		"DE" : "?Amplified"
	},
	"no_chime" :
	{
		"EN" : "No chime",
		"NL" : "Geen chime",
		"FR" : "?no_chime",
		"DE" : "?no_chime"
	},
	"no_chime_to_play" :
	{
		"EN" : "no_chime_to_play",
		"NL" : "Geen chimes om af te spelen",
		"FR" : "?no_chime_to_play",
		"DE" : "?no_chime_to_play"
	},
	"public" :
	{
		"EN" : "public",
		"NL" : "Publiek",
		"FR" : "?public",
		"DE" : "?public"
	},
	"Paging" :
	{
		"EN" : "Paging",
		"NL" : "Paging",
		"FR" : "?Paging",
		"DE" : "?Paging"
	},
	"PartyMaster" :
	{
		"EN" : "PartyMaster",
		"NL" : "PartyMaster",
		"FR" : "?PartyMaster",
		"DE" : "?PartyMaster"
	},
	"line_out_only" :
	{
		"EN" : "Only line-out",
		"NL" : "Alleen line-out",
		"FR" : "?line_out_only",
		"DE" : "?line_out_only"
	},
	"always_on" :
	{
		"EN" : "(Always aan)",
		"NL" : "(Altijd aan)",
		"FR" : "?always_on",
		"DE" : "?always_on"
	},
	"line_out_internal_amplifier" :
	{
		"EN" : "line_out_internal_amplifier",
		"NL" : "Heeft ook line-out",
		"FR" : "?line_out_internal_amplifier",
		"DE" : "?line_out_internal_amplifier"
	},
	"Help_RDS_on_Wall_Controller" :
	{
		"EN" : "?Help_RDS_on_Wall_Controller",
		"NL" : "?Help_RDS_on_Wall_Controller",
		"FR" : "?Help_RDS_on_Wall_Controller",
		"DE" : "?Help_RDS_on_Wall_Controller"
	},
	"Help_language" :
	{
		"EN" : "?Help_language",
		"NL" : "?Help_language",
		"FR" : "?Help_language",
		"DE" : "?Help_language"
	},
	"Chimes_list" :
	{
		"EN" : "?Chimes_list",
		"NL" : "?Chimes_list",
		"FR" : "?Chimes_list",
		"DE" : "?Chimes_list"
	},
	"delete" :
	{
		"EN" : "?delete",
		"NL" : "?delete",
		"FR" : "?delete",
		"DE" : "?delete"
	},
	"wait_restart" :
	{
		"EN" : "?wait_restart",
		"NL" : "?wait_restart",
		"FR" : "?wait_restart",
		"DE" : "?wait_restart"
	},
	"language_after_refresh" :
	{
		"EN" : "?language_after_refresh",
		"NL" : "?language_after_refresh",
		"FR" : "?language_after_refresh",
		"DE" : "?language_after_refresh"
	},
	"Help_show_tone_setup_on_Wall_Controller" :
	{
		"EN" : "?Help_show_tone_setup_on_Wall_Controller",
		"NL" : "?Help_show_tone_setup_on_Wall_Controller",
		"FR" : "?Help_show_tone_setup_on_Wall_Controller",
		"DE" : "?Help_show_tone_setup_on_Wall_Controller"
	},
	"Show_tone_setup_on_Wall_Controller" :
	{
		"EN" : "?Show_tone_setup_on_Wall_Controller",
		"NL" : "?Show_tone_setup_on_Wall_Controller",
		"FR" : "?Show_tone_setup_on_Wall_Controller",
		"DE" : "?Show_tone_setup_on_Wall_Controller"
	},
	"Hide_tone_setup_on_Wall_Controller" :
	{
		"obsolete" : "*** not found in websources ***",
		"EN" : "Hide tone setup on Wall Controller",
		"NL" : "Verberg toon setup op Wand controllers",
		"FR" : "?Hide_tone_setup_on_Wall_Controller",
		"DE" : "?Hide_tone_setup_on_Wall_Controller"
	},
	"Help_hide_tone_setup_on_Wall_Controller" :
	{
		"obsolete" : "*** not found in websources ***",
		"EN" : "?Help_hide_tone_setup_on_Wall_Controller",
		"NL" : "?Help_hide_tone_setup_on_Wall_Controller",
		"FR" : "?Help_hide_tone_setup_on_Wall_Controller",
		"DE" : "?Help_hide_tone_setup_on_Wall_Controller"
	}
};
