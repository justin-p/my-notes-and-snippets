These images are useful for testing the display(1) program from
contrib/applications/ImageMagick/ImageMagick-3.2.tar.gz on ftp.x.org.
Display(1) is a program that can display an image on any X server.  Type

  make
  display *.miff

The aquarium image was rendered with rayshade from a script written by
kilian@cray.com and Jerome A. Farm.

The aquarium and other images are available from anonymous FTP at
ftp.x.org, file contrib/applications/ImageMagick/ImageMagick.images.tar.gz.
