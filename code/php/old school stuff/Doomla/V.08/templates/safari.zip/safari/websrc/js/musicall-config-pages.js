mom.pages = new Array();
mom.changed.pages = new notifier();

function parsePages (data) {
	var pageArr = data.split('&');
	for (var p in pageArr) {
		if (pageArr[p] != '') {
			var arg = pageArr[p].split('=');	
			switch (arg[0]) {
				case 'page' 		: var n = parseInt(arg[1]); break;
				case 'channel' : mom.pages[n].channel = parseInt(arg[1]); break;
			}
		}	
	}		
	if (typeof busyData2 == 'undefined' || busyData2 != busyData) {
		mom.changed.pages.notify();
	}
}

function urlPages(){
	var query = '';
	for (p = 1; p <= mom.config.max_pages; p++){
		if (!mom.pages[p]) mom.pages[p] = new Object();
		if (query > '') query += '&&';
		query += 'page='+p.toString()+'&channel=?';
	}
	return query;
}

function getPages () {
	balancedAjax({
		url			: urlPages(),
		async		: false,
		success	: parsePages
	}); 
}

function setPageChannel (pageNr){
	balancedAjax({
		url: 'page='+pageNr.toString()+'&_channel='+mom.pages[pageNr].channel.toString(),
	}); 
}
