var scrollRoomScrollRegion = 0;
var scrollChannelsScrollRegion = 0;
var scrollInputsScrollRegion = 0;
var scrollStationsScrollRegion = 0;
var busyS = false;

function inputInScrollList(input) {
	for (var c in mom.scrollChannels) {
		if (mom.scrollChannels[c].channel == input) return true;
	}
	return false;
}

function displayScrollInputsList(){
	var view = '';
	for (var n = 1; n <= maxChannels(); n++){
		var i = channel2Input(n);
		if (!inputInScrollList(i) && (inputOwner(i) == 0)) {
			view += '<div class="scroll-input" id="scroll-input'+i.toString()+'">'+inputName(i)+'</div>';
		}
	}
	$('#scroll-inputs-selection').html(view);
	activateScrollInputsBehavior();	
}

function freqInScrollList(freq){
	for (var c in mom.scrollChannels) {
		if (mom.scrollChannels[c].freq == freq) return true;
	}
	return false;
}

function displayScrollStationsList(){
	var view = ''; 
	if (roomTunerChannel(scrollRoomNr()) > 0) {
		//if (stations.length == 0) getStations(false);
		for (var n in mom.stations){
			if (!freqInScrollList(mom.stations[n].freq)) {
				view += '<div class="scroll-station" id="scroll-station'+n.toString()+'">'+mom.stations[n].name+'</div>';
			}
		}
	}	
	$('#scroll-stations-selection').html(view);
	scrollStationsScrollRegion.update();
	activateScrollStationsBehavior();
}

function blurScrollTab() {
	setScrollList(scrollRoomNr());
}

function displayScrollList() {
	var view = '';
	for (var c in mom.scrollChannels) {
		view += '<div class="scroll-channel draggable" id="scroll-channel'+mom.scrollChannels[c].channel+'-'+mom.scrollChannels[c].freq+'">'+mom.scrollChannels[c].name+'</div>';
	}
	view += '<div class="scroll-channel" id="scroll-channel">. . . . . . . .</div>';
	$('#scroll-channels-selection').html(view);
	scrollChannelsScrollRegion.update();
	activateScrollChannelsBehavior();
	displayScrollInputsList();
	displayScrollStationsList();
	 $('body').css('cursor','default');
}

var lastScrollOutputNr = -1;
function parseScrollList(data) {
	var outputNr = parseInt(data.split('&')[0].split('=')[1]);
	if (dataChanged('scrollChannels',data) || lastScrollOutputNr != outputNr) {
		mom.scrollChannels = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		lastScrollOutputNr = outputNr;
		displayScrollList();
	}	
}

function urlScrollList(){
	var o = scrollRoomNr();
	if (o <= 0) return '';
	return 'output='+room2Output(o)+'&chn_list=?'
}

function getScrollList(scrollRoomNr) {
	if (busyS) return;
	balancedAjax({
		url: 'output='+room2Output(scrollRoomNr)+'&chn_list=?',
		success: parseScrollList
	});
}

function setScrollList(scrollRoomNr) {
	balancedAjax({
		url: 'output='+room2Output(scrollRoomNr)+'&chn_list=' + encodeURIComponent($.toJSON(mom.scrollChannels))
	});
}

function displayScrollRoom(scrollRoomNr) {
// bouw scrolllijst, inputslijst en stationslijst op.
	getScrollList(scrollRoomNr);
}

// selected room 	get/set
function scrollRoomNr(setNr) {
	var actNr = 0;
	if ($.exists('.scroll-room.selected')) {
		actNr = parseInt($('.scroll-room.selected').attr('id').replace('scroll-room',''));
	} 
	if  (setNr > 0 && setNr != actNr) { //set
		actNr = setNr;
		$('.scroll-room.selected').removeClass('selected');
		$('#scroll-room'+setNr).addClass('selected');
		displayScrollRoom(setNr);
	}
	return actNr;
}

function initScrollRoomScrollRegion(){
	if ( typeof scrollRoomScrollRegion.updated == 'undefined' ) {
		scrollRoomScrollRegion.update();
		scrollChannelsScrollRegion.update();
		scrollInputsScrollRegion.update();
		scrollStationsScrollRegion.update();
	} 
}

function focusScrollsTab() {
	initScrollRoomScrollRegion();
	displayScrollRoom(scrollRoomNr());
}

function activateScrollRooms(){
	$('.scroll-room').mousedown(function (){$(this).click();});
	$('.scroll-room').click(function (){
		scrollRoomNr(parseInt($(this).attr('id').replace('scroll-room','')));
	});
}

function displayScrollRoomlist() {
	r = scrollRoomNr(); if (r > maxRooms()) r = maxRooms();
	if (r == 0) r = 1;
	var view = '';
	for (var n = 1; n <= maxRooms(); n++){
		view += '<div class="scroll-room" id="scroll-room'+n+'">'+outputName(room2Output(n))+'</div>';
	}
	$('#scroll-room-selection').html(view);
	scrollRoomScrollRegion.update();
	activateScrollRooms();
	scrollRoomNr(r);
}

function removeScrollChannel(id) {
	chan_freq = id.replace('scroll-channel','');
	var cFound = -1;
	for (var c in mom.scrollChannels) 
		if (mom.scrollChannels[c].channel.toString() + '-' + mom.scrollChannels[c].freq.toString()== chan_freq) cFound = c;
	if (cFound > -1) {
		if ((inputOwner(mom.scrollChannels[cFound].channel) != room2Output(scrollRoomNr())) || mom.scrollChannels[cFound].freq > 0) {
			mom.scrollChannels.splice(cFound,1); 	
			return true;
		} else {
			alert (xLateText('{cannot_remove_owned_input_from_scroll}'));
		}
	}
	return false;
}

function id2RoomChannelOld (id) {
	var target = 0;
	var c = 0;
	$('.scroll-channel').each(function(){
		var id2 = $(this).attr('id');
		if (($(this).attr('id') == id) && (!$(this).hasClass('ui-draggable-dragging'))) target = c;
		c++;
	});
	return target;
}

function id2RoomChannel (id) {
	id = id.replace('scroll-channel','');
	var c = id.split('-')[0];
	var f = id.split('-')[1];
	for (var v in mom.scrollChannels) {
		if ((c == mom.scrollChannels[v].channel) && (f == mom.scrollChannels[v].freq)) return v;
	}
	return mom.scrollChannels.length;
}

function addScrollInput(id, targetId){
	var i = Number(id.replace('scroll-input',''));
	if (targetId == '') {
		type = inputType(i);
		var c = 0;
		switch (type) {
			case 'AUX'	: while ((c < mom.scrollChannels.length) && (inputType(mom.scrollChannels[c].channel) == 'AUX') && (i > mom.scrollChannels[c].channel )) c++; break;
			case 'LOCAL': while ((c < mom.scrollChannels.length) && (inputType(mom.scrollChannels[c].channel) == 'LOCAL') && (i > mom.scrollChannels[c].channel )) c++; break;
			case 'MP3'	:	while ((c < mom.scrollChannels.length) && (inputType(mom.scrollChannels[c].channel) == 'AUX')) c++; break;
			case 'TUNER':	while ((c < mom.scrollChannels.length) && (inputType(mom.scrollChannels[c].channel) != 'TUNER')) c++; 
										while ((c < mom.scrollChannels.length) && (i > mom.scrollChannels[c].channel ) && (mom.scrollChannels[c].freq == 0)) c++;
										break;
		}
	} else c = id2RoomChannel(targetId);
	var chan = new Object;
	chan.channel = i;
	chan.name = inputName(i);
	chan.freq = 0;
	mom.scrollChannels.splice(c,0,chan); 	
	return true;
}

function addScrollStation (id, targetId) {
	var s = Number(id.replace('scroll-station',''));
	if (targetId == '') {	
		var c = 0;
		while ((c < mom.scrollChannels.length) && (mom.scrollChannels[c].freq < mom.stations[s].freq)) c++;
	} else c = id2RoomChannel(targetId);
	var chan = new Object;
	chan.channel = roomTunerChannel(scrollRoomNr());
	chan.name = mom.stations[s].name;
	chan.freq = mom.stations[s].freq;
	mom.scrollChannels.splice(c,0,chan); 	
}

function changeScroll() {
	$('.scroll-channel.selected').each(function(){	removeScrollChannel($(this).attr('id'));});
	$('.scroll-input.selected').each(function(){	addScrollInput($(this).attr('id'),'');});
	$('.scroll-station.selected').each(function(){ addScrollStation($(this).attr('id'),'');});
	displayScrollList();
	setScrollList(scrollRoomNr());
}

function channelSort(id, targetId){
	c = id2RoomChannel(id);
	chan = mom.scrollChannels[c];
	mom.scrollChannels.splice(c,1); 
	c = id2RoomChannel(targetId);
	mom.scrollChannels.splice(c,0,chan); 
	setScrollList(scrollRoomNr());
}

function inputMove(id, targetId){
	if (id.indexOf('scroll-station') == 0) addScrollStation(id, targetId);
	if (id.indexOf('scroll-input') == 0) addScrollInput(id, targetId);
	if (id.indexOf('scroll-channel') == 0) channelSort(id, targetId);
	setTimeout(displayScrollList,10);
	setScrollList(scrollRoomNr());
}

function inputDrop(event,ui){
	inputMove(ui.draggable.attr('id'), $(this).attr('id'));
	busyS = false;
}

function channelMove(id){
	removeScrollChannel(id);
	setTimeout(displayScrollList,10); //time to cleanup draggable
	setScrollList(scrollRoomNr());
}

function channelDrop(event,ui){
	channelMove(ui.draggable.attr('id'));
	busyS = false;
}

function activateScrollChannelsBehavior() {
	$('.scroll-channel.draggable').click(function(){
		if ($(this).hasClass('selected')) $(this).removeClass('selected'); else $(this).addClass('selected');
	});

	$('.scroll-channel.draggable').dblclick(function(){
		channelMove($(this).attr('id')); 
	});

	$(".scroll-channel.draggable").draggable({
		opacity: 0.50,
		helper:'clone',
		appendTo: '#config-scrolls',
		distance : 5,
		cursor : 'move',
		start : function() {busyS = true;},
		stop : function() {busyS = false;}
	});
  
	$(".scroll-channel").droppable({
		hoverClass	: "station-hit",
		accept			: ".scroll-input, .scroll-station, .scroll-channel",
		drop				: inputDrop
	 });
}

function activateScrollInputsBehavior() {
	$('.scroll-input').click(function(){
		if ($(this).hasClass('selected')) $(this).removeClass('selected'); else $(this).addClass('selected');
	});
	
	$('.scroll-input').dblclick(function(){
		inputMove($(this).attr('id'), ''); 
	});
	
	$(".scroll-input").draggable({
		opacity: 0.50,
		helper:'clone',
		appendTo: '#config-scrolls',
		distance : 5,
		cursor : 'move',
		start : function() {busyS = true;},
		stop : function() {busyS = false;}
	}); 
	
  $("#scroll-inputs").droppable({
		hoverClass	: "station-hit",
		accept			: ".scroll-channel",
		drop				: channelDrop
	 });
}

function activateScrollStationsBehavior() {
	$('.scroll-station').click(function(){
		if ($(this).hasClass('selected')) $(this).removeClass('selected'); else $(this).addClass('selected');
	});

	$('.scroll-station').dblclick(function(){	
		inputMove($(this).attr('id'), '');
	});

	$(".scroll-station").draggable({
		opacity: 0.50,
		helper:'clone',
		appendTo: '#config-scrolls',
		distance : 5,
		cursor : 'move',
		start : function() {busyS = true;},
		stop : function() {busyS = false;}
	});  

	$("#scroll-stations").droppable({
		hoverClass	: "station-hit",
		accept			: ".scroll-channel",
		drop				: channelDrop
	 });	 
}


function configScrollView(){
	document.write(getHTML('html/config-scroll-view.html'));	
	
	$('#button-scroll').click(changeScroll);
	
	scrollRoomScrollRegion = $('#scroll-roomsregion');
	scrollRoomScrollRegion.tinyscrollbar();
	scrollChannelsScrollRegion = $('#scroll-channelsregion');
	scrollChannelsScrollRegion.tinyscrollbar();
	scrollInputsScrollRegion = $('#scroll-inputsregion');
	scrollInputsScrollRegion.tinyscrollbar();
	scrollStationsScrollRegion = $('#scroll-stationsregion');
	scrollStationsScrollRegion.tinyscrollbar();
	mom.changed.output.register(displayScrollRoomlist);
	mom.changed.stations.register(displayScrollStationsList);
	mom.changed.input.register(displayScrollInputsList);
}
