
var fact = {
			"monitor" : {
				"value" : 1,
				"settings" : {"confirm":false,"output":0}
			},
			"firm" 		: {
				"temp"		: 46.00,
				"config" : {"product":"mac808","version":"2.31S","mac":"00:60:35:0E:68:24","ip":"192.168.2.107"}
			},
			"cfg"			: {
				"lang"		: "NL",
				"config" 	: {"in_mono":15,"max_inputs":18,"max_outputs":8,"max_tuners":4,"first_tuner":9,"volume_ofs":0,"volume_range":51,"min_ofs":-95,"min_range":51,"max_ofs":-29,"max_range":61,"page_ofs_ofs":-10,"page_ofs_range":17,"bass_ofs":-12,"bass_range":25,"mid_ofs":-12,"mid_range":25,"treble_ofs":-12,"treble_range":25,"balance_ofs":-30,"balance_range":61,"gain_ofs":-32,"gain_range":45,"max_presets":50,"max_zones":1,"max_combies":1,"max_gpio_in":2,"max_gpio_out":0,"max_pages":1},
				"radio"		:	{"min_freq":8750,"max_freq":10800,"step":10},
				"wc"			: {"wc_hide_setup":0,"wc_show_rds":0},
				"output"	: {"stereo":15,"outputs":[{"type":"ROOM","name":"Output%201"},{"type":"ROOM","name":"Output%201"},{"type":"ROOM","name":"Output%202"},{"type":"ROOM","name":"Output%202"},{"type":"ROOM","name":"Output%203"},{"type":"ROOM","name":"Output%203"},{"type":"ROOM","name":"Output%204","headphone":1},{"type":"ROOM","name":"Output%204","headphone":1}]},
				"input"		: {"stereo":511,"inputs":[{"type":"AUX","name":"Aux-1","owner":0,"public":1,"gain":32},{"type":"AUX","name":"Aux-1B","owner":0,"public":1,"gain":32},{"type":"AUX","name":"Aux-2","owner":0,"public":1,"gain":32},{"type":"AUX","name":"Aux-2B","owner":0,"public":1,"gain":32},{"type":"AUX","name":"Aux-3","owner":0,"public":1,"gain":32},{"type":"AUX","name":"Aux-3B","owner":0,"public":1,"gain":32},{"type":"AUX","name":"Aux-4","owner":0,"public":1,"gain":32},{"type":"AUX","name":"Aux-4B","owner":0,"public":1,"gain":32},{"type":"TUNER","name":"Tuner-1","owner":1,"public":0,"gain":32},{"type":"TUNER","name":"Tuner-1%20%28R%29","owner":1,"public":0,"gain":32},{"type":"TUNER","name":"Tuner-2","owner":3,"public":0,"gain":32},{"type":"TUNER","name":"Tuner-2%20%28R%29","owner":3,"public":0,"gain":32},{"type":"TUNER","name":"Tuner-3","owner":5,"public":0,"gain":32},{"type":"TUNER","name":"Tuner-3%20%28R%29","owner":5,"public":0,"gain":32},{"type":"TUNER","name":"Tuner-4","owner":7,"public":0,"gain":32},{"type":"TUNER","name":"Tuner-4%20%28R%29","owner":7,"public":0,"gain":32},{"type":"MP3","name":"Streaming","owner":-1,"public":1,"gain":32},{"type":"MP3","name":"Stream%20%28R%29","owner":-1,"public":1,"gain":32}]},
				"combies"	: [{"name":"combi_01","master":0,"active":0,"multi":0,"outputs":"0x0"}],
				"gpio_in_f": [{"action":0,"chime":"alarm2.Mp3","zones":"0x0"},{"action":0,"chime":"","zones":"0x0"},{"action":0,"chime":"","zones":"0x0"}],
				"zones"	: [{"name":"zone_01","outputs":"0xFF"},{"name":"zone_02","outputs":"0x1"}],
				"preset_list": [{"name":"87.90","freq":8790,"rssi":33},
			 {"name":"88.80","freq":8880,"rssi":33},
				{"name":"90.40","freq":9040,"rssi":27},
			{"name":"90.70","freq":9070,"rssi":29},
				{"name":"92.60","freq":9260,"rssi":28},
			 {"name":"98.20","freq":9820,"rssi":30},
			{"name":"89.20","freq":8920,"rssi":30},
				{"name":"89.50","freq":8950,"rssi":30},
			{"name":"91.40","freq":9140,"rssi":30},
			 {"name":"92.30","freq":9230,"rssi":30},
			 {"name":"92.90","freq":9290,"rssi":29},
				{"name":"96.30","freq":9630,"rssi":29},
			{"name":"93.60","freq":9360,"rssi":15}
				],
				"setup_list" : [{"name": "mysetup.xml"},{"name":"mybackup.xml"}],
				"page_rel_volume" : 1
			},
			"net"			: {
				"names"	: [{"type":"CC","ip":"192.168.2.107","mac":"00:60:35:0E:68:24","name":"minicall2","firmware":"2.31","dhcp":0}]
			},
			"page"		: {
				"channel" : 0
			},
			"chimes"	: {
				"list" 	: [{"name":"alarm2.Mp3"},{"name":"alarm2.wav"},{"name":"alarm3.wav"},{"name":"alarm4.wav"},{"name":"dingdong 2.mp3"},{"name":"dingdong 3.mp3"},{"name":"dingdong 4.wav"},
										{"name":"dingdong 7.wav"},{"name":"doorbell.wav"},{"name":"doorbell2.mp3"},{"name":"doorbell3.wav"},{"name":"doorbell4.mp3"},{"name":"phone1.wav"}]
			},
			"output"	: [],
			"input"		: [],
			"radio"		: []
		}

function initFact(){
		for (var o = 0; o < fact.cfg.config.max_outputs; o++){
			fact.output[o] = {};
			fact.output[o].settings = {"channel":1,"vchan":1,"volume":10,"muted":0,"balance":30,"min":35,"max":36,"bass":10,"mid":10,"treble":14,"amp":1,"page_chn":0,"page_ofs":10,"combi_nr":0};
			fact.output[o].chn_list =  [{"name":"Aux-1","channel":1,"freq":0}, 
																 {"name":"Aux-2","channel":3,"freq":0}, 
																 {"name":"Aux-3","channel":5,"freq":0},
																 {"name":"Aux-4","channel":7,"freq":0},
																 {"name":"Streaming","channel":17,"freq":0}];
		}
		for (var i = 0; i < fact.cfg.config.max_inputs; i++){
			fact.input[i] = {};
			fact.input[i].settings = {"owner":0,"gain":32};
		
		}
		for (var r = 0; r < fact.cfg.config.max_tuners; r++){
			fact.radio[r] = {};
			fact.radio[r].fmchannel = 8790;
			fact.radio[r].rds_info = {"freq":8790,"rds":"87.90","pi":0x0000,"rssi":24,"afcrl":0,"stereo":0,"stc":1,"ps":"0x000"};
		}
}
initFact();
		
var rom = {};
var musicallId = 'mac808';
var musicallProp=['cfg','monitor','firm','net','page','chimes','output','input','radio'];

var _ajax = $.ajax;
var _ajaxFileUpload = $.ajaxFileUpload;


function clone(obj) {
    // Handle the 3 simple types, and null or undefined
    if (null == obj || "object" != typeof obj) return obj;

    // Handle Date
    if (obj instanceof Date) {
        var copy = new Date();
        copy.setTime(obj.getTime());
        return copy;
    }

    // Handle Array
    if (obj instanceof Array) {
        var copy = [];
        for (var i = 0; i < obj.length; ++i) {
            copy[i] = clone(obj[i]);
        }
        return copy;
    }

    // Handle Object
    if (obj instanceof Object) {
        var copy = {};
        for (var attr in obj) {
            if (obj.hasOwnProperty(attr)) copy[attr] = clone(obj[attr]);
        }
        return copy;
    }

    throw new Error("Unable to copy obj! Its type isn't supported.");
}

function saveROM(){
	var data = $.toJSON(rom);
		_ajax({
				type : 'POST',
				async : false,
				dataType : 'html',
				url : '/audio_set?action=save',
				data : 'rom='+data,
				success : function(data){
										if (data.indexOf('error') == 0) alert(data);
									},
				complete : function(){}
		});

}

function loadROM(){
		_ajax({
				async : false,
				dataType : 'html',
				url : '/audio_set?action=load',
				success : function(data){
										if (data.indexOf('error') == 0) alert(data);
										if (data != ''){ rom = jQuery.parseJSON(data);};
									},
				complete : function(){}
		});
}

function initROM(){
	loadROM()
	// verder uit te werken afhankelijk van bestaan en factoryRestore
	if (!rom.firm) rom = clone(fact);
}
initROM();

function  restoreROM(scope){
	if (scope == 0) return;
	if (1 & scope) {
		rom.cfg.input = clone(fact.cfg.input);
		rom.input = clone(fact.input);
	}
	if (2 & scope) {
		rom.cfg.output = clone(fact.cfg.output);
		rom.output = clone(fact.output);
	}
	if (4 & scope) {
		rom.cfg.radio = clone(fact.cfg.radio);
		rom.cfg.preset_list = clone(fact.cfg.preset_list);
		rom.radio = clone(fact.radio);
	}
	if (8 & scope) {
		rom.cfg.zones = clone(fact.cfg.zones);
		rom.cfg.gpio_in_f = clone(fact.cfg.gpio_in_f);
		rom.chimes = clone(fact.chimes);
		rom.page = clone(fact.page);
	}
	if (16 & scope) {
		rom.cfg.combies = clone(fact.cfg.combies);
	}
	saveROM();
}

function respondBusy(){
	var busy = {};
	//calculate busy
	busy = {"pages":"0x0","zones_active":"0x0","zones_busy":"0x0","combies_active":"0x0","combies_busy":"0x0",
   "page_outputs":"0x0","combi_outputs":"0x0","slave_outputs":"0x0","config":1};

	return busy;
}

function romStationsList(){
	var result = clone(rom.cfg.preset_list);
	result.sort(function(a,b){return a.freq > b.freq});
	return result;
}

function seekROMStation(radio, dir){
	var stations = romStationsList();
	var s, station;
	var found = false;
	if (dir == "+1"){
		station = 0;
		while (!found && station < stations.length){
			found =(rom.radio[radio-1].fmchannel < stations[station].freq)
			if (!found) station++;
		}
		if (station == stations.length) station = 0;
	} else {
		station = stations.length -1;
		while (!found && station >=0){
			found = (rom.radio[radio-1].fmchannel > stations[station].freq);
			if (!found) station--;
		}
		if (station == -1) station = stations.length-1;
	}
	rom.radio[radio-1].fmchannel = stations[station].freq;
	rom.radio[radio-1].rds_info.freq = stations[station].freq;
	rom.radio[radio-1].rds_info.rds = (stations[station].freq/100).toString();
}

function matchROMStation(radio, value){
	rom.radio[radio-1]["fmchannel"] = value;
	rds = (Math.round(value)).toString();
	rds = rds.substr(0,rds.length-2)+'.'+rds.substr(rds.length-2,2);
	rom.radio[radio-1]["rds_info"] = {"freq":value,"rds": rds,"pi":0x0000,"rssi":24,"afcrl":0,"stereo":0,"stc":1,"ps":"0x000"};
}

function addNetDevice(device){
	var act = -1;
	for (var n in rom.net.names){
		if (device.mac == rom.net.names[n].mac) act = n;
	}
	if (act == -1) act = rom.net.names.length;
	rom.net.names[act].ip = device.ip;
	if (device.dhcp) rom.net.names[act].dhcp = device.dhcp;
	rom.net.names[act].name = device.name;
	rom.net.names[act].firmware = "2.31";
	rom.net.names[act].type = "CC";
}

var ajaxEmulator = function (args){
	if (args.url.search('/audio_set?') == -1)
		_ajax(args);
	else {
		var error = false;
		args.url = args.url.replace('/audio_set?','');
		var groups = args.url.split('&&');
		var response;
		var data= '';
		for (var g in groups)
		{
			response = audioTagValues(groups[g]);
			error = error || response.error;
			data += ((data > '')?'&&':'') + response.data;
		}
		data = '/audio_set?' + data;
		if (args.success && !error) args.success(data);
		if (args.error && error) args.error();
		if (args.complete) args.complete();
	}
}	

function audioTagValues(url){
	var error = false;
	var data = '';
	var tagValue = url.split('&');

	for (var t = 1; t < tagValue.length; t++){
		if (tagValue[t].split('=')[1] == "?") 
			response = audioGet(tagValue[0],tagValue[t]);
		else
			response = audioSet(tagValue[0],tagValue[t]);
		error = error || response.error;
		data += '&'+response.data;
	}
	data = tagValue[0]+data;
	return {data : data, error : error}
}

function audioGet(contextTagValue,tagValue){
	var contextTag = contextTagValue.split('=')[0];
	var contextValue = contextTagValue.split('=')[1];

	var error = false;
	var tag = tagValue.split('=')[0];
	var data = tag + '=';
	if (tag[0] == '_') tag = tag.substr(1);	
	
	switch (contextTag){	
		case "cfg" :	
			switch (tag){
				case "lang" 		:;
				case "page_rel_volume":;
				case "config" 	:;
				case "radio"		:;
				case "wc"				:;
				case "combies" :;
				case "zones" 	:;
				case "gpio_in_f" :;
				case "setup_list":;
				case "preset_list": data += $.toJSON(rom.cfg[tag]); break;
				case "in_stereo" : data += $.toJSON(rom.cfg.input.stereo); break;;
				case "out_stereo" : data += $.toJSON(rom.cfg.output.stereo); break;;
				case "inputs" : data += $.toJSON(rom.cfg.input.inputs); break;;
				case "outputs" : data += $.toJSON(rom.cfg.output.outputs); break;;
				case "busy" : data += $.toJSON(respondBusy()); break;
			}; break;
		case "firm"	:
			switch (tag) {
				case "temp"		:;
				case "config"	:		data += $.toJSON(rom.firm[tag]); break;;	
			}; break;
		case "output"	:
			var output = parseInt(contextValue);
			switch (tag) {
				case "settings": ;
				case "chn_list" : data += $.toJSON(rom.output[output-1][tag]); break;;	
			}; break;
		case "input"	:
			var input = parseInt(contextValue);
			switch (tag) {
				case "settings": ;
				case "settings"	: data += $.toJSON(rom.input[input-1][tag]); break;;	
			}; break;
		case "radio"	:
			var radio = parseInt(contextValue);
			switch (tag) {
				case "fmchannel"	:;
				case "rds_info" 	:	data += $.toJSON(rom.radio[radio-1][tag]); break;;	
			}; break;
		case "net"	:
			switch (tag) {
				case "names": data += $.toJSON(rom.net[tag]); break;;	
			}; break;
		case "page" :
			var page = parseInt(contextValue);
			switch (tag) {
				case "channel":  data += $.toJSON(rom.page[tag]); break;;	
			}	break;
		case "chimes" :
			switch (tag) {
				case "list":  data += $.toJSON(rom.chimes[tag]); break;;	
			}	break;
	}
	return {data : data, error : error}
}

function audioSet(contextTagValue,tagValue){
	var contextTag = contextTagValue.split('=')[0];
	var contextValue = contextTagValue.split('=')[1];

	var error = false;
	var tag = tagValue.split('=')[0];
	var value = tagValue.split('=')[1]
	var data = tag + '=' + value;;
	if (tag[0] == '_') tag = tag.substr(1);	
	switch (contextTag){
		case "monitor" :
			var newMon = jQuery.parseJSON(value.replace('confirm','"confirm"'));
			if (!newMon.output){
				data = 'monitor=' + rom.monitor.value.toString() + '&settings=';
				if (rom.monitor.settings.output != 0)
					data += $.toJSON(rom.monitor.settings); 
				else
					data += '?';
			}		
			else {
				rom.monitor.settings = newMon;
			}; break;
		case "cfg" :	
			switch (tag){
				case "lang"					: 	rom.cfg.lang = value; saveROM(); break;
				case "out_stereo" 	: 	rom.cfg.output.stereo = parseInt(value); break;
				case "in_stereo" 		: 	rom.cfg.input.stereo = parseInt(value); break;
				case "combies"			:;
				case "wc"						:; 	
				case "zones"				: 	rom.cfg[tag] = jQuery.parseJSON(decodeURIComponent(value)); break;
				case "save" 				:		alert(xLateKey('You_cannot_save_your_settings_in_xml_in_demo')); error = true; break;
				case "load" 				:		alert(xLateKey('You_cannot_load_your_settings_in_xml_in_demo')); error = true; break;
				case "restore"			: 	restoreROM(parseInt(value));
			}; break;
		case 'output'	:
			var output = parseInt(contextValue);
			switch (tag) {
				case "muted"			:;
				case "amp"		:		;
				case "vchan"			:;
				case "volume" 		:;
				case "bass"				:;
				case "min"				:;
				case "max"				:;
				case "treble"			:;
				case "mid"				:;
				case "balance"		:;
				case "page_ofs" 	: rom.output[output-1].settings[tag] = parseInt(value); break;
				case "name"				: rom['cfg'].output.outputs[output-1].name = value; break;
				case "chn_list"		: rom.output[output-1].chn_list = jQuery.parseJSON(decodeURIComponent(value)); break;
			}; break;
		case 'input'	:
			var input = parseInt(contextValue);
			switch (tag) {
				case "owner" 	:;
				case "gain"				: rom['input'][input-1].settings[tag] = parseInt(value); break;
				case "name"				: rom['cfg'].input.inputs[input-1].name = value; break;
			}; break;
		case "page" :
			var page = parseInt(contextValue);
			switch (tag) {
				case "channel":  rom.page[tag] = jQuery.parseJSON(decodeURIComponent(value)); break;
			}	break;
		case "gpio_in_f":
			var gpio = parseInt(contextValue);
			switch (tag){
				case "settings": rom.cfg.gpio_in_f[gpio-1] = jQuery.parseJSON(decodeURIComponent(value)); break;
			}	break;
		case "net"	:
			switch (tag) {
				case "names": addNetDevice(jQuery.parseJSON(decodeURIComponent(value))); break;
			}; break;
		case "radio"	:
			var radio = parseInt(contextValue);
			switch (tag) {
				case "seek"				: seekROMStation(radio,value); break;
				case "fmchannel"	: matchROMStation(radio,parseFloat(value)); break;
				case "rds_info" 	:	rom.radio[radio-1][tag] = value; break;;	
			}; break;
	}
	return {data : data, error : error};
}
	
$.ajax = ajaxEmulator;

function ajaxFileUploadEmulator(args){
	alert(xLateKey('You_cannot_upload_in_demo'));
}
$.ajaxFileUpload = ajaxFileUploadEmulator;

function demoSaveTabs(){
	var id;
	$('.tabContent').each(function(){
		id = $(this).attr('id');
		registerTabHandler(id,saveROM,'blur');
	});
}

$(function(){
	$(window).unload(function() {saveROM();});
	demoSaveTabs();
	srtt = 100;
	pollConfigCycle = 300;
	pollUserCycle = 300;
});
