/*	no demo, no emulation 
		redirected by apache and .htaccess to demo/musicall-demo.js
*/

