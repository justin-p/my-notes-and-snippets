contextHelp = false;

showHelp = function(event){
	if (!contextHelp) return;
	$('.help[helpselector="'+event.data.helpselector+'"]').addClass('showhelp');
}

hideHelp = function(event){
	$('.showhelp').removeClass('showhelp');
}

function activateHelp(me){
	var helpselector = $(me).attr('helpselector');
	if (helpselector){
		$(helpselector.replace(/''/g,'"'))
			.mouseover({helpselector : helpselector},showHelp)
			.mouseleave(hideHelp);
	}
}

function deactivateHelp(me){
	var helpselector = $(me).attr('helpselector');
	if (helpselector){
		$(helpselector.replace(/''/g,'"'))
			.unbind('mouseover',showHelp)
			.unbind('mouseleave',hideHelp);
	}
}

function deactivateAllHelp(){
	$('.help').each(function(){deactivateHelp(this)});
}

function activateAllHelp(){
	$('.help').each(function(){activateHelp(this)}); 
}

function reactivateAllHelp(){
	deactivateAllHelp();
	activateAllHelp();
}

helpResizing = false;

function stopHelpResizing(e){
	if (!helpResizing) return true;
	helpResizing = false;
	e.preventDefault();
}

function helpView(){
	document.write(getHTML('html/help-general.html').replace('<help-specific>',getHTML('html/board/help-specific.html')));
	$('#help').bind("dragstart", function() {
     return false;
	});
	
	$('#help').mousemove(function(e){
		if (!contextHelp || helpResizing) return;
		var y = e.pageY - this.offsetTop;	
				
		if (y < 4) 
			$('#help').css('cursor','N-resize');
		else
			$('#help').css('cursor','');
	});
	
	$('#help').mousedown(function(e){
		if (!contextHelp) return true;
		var y = e.pageY - this.offsetTop;	
		if (y < 4) 
			helpResizing = true;
		else
			helpResizing = false;
	});
	
	$('#bg').mouseup(stopHelpResizing);
	
	$('#bg').mousemove(function(e){
		if (!(contextHelp && helpResizing)) return true;
		e.preventDefault();
		var h = document.getElementById('help');
		var newHeight = $('#help').height() + h.offsetTop - e.pageY;
		if (newHeight > 24 && newHeight < 200) {
			$('#help').height(newHeight);
			$('#help').css('cursor','N-resize');
		} 
		return false;
	});
	
	$('#toggle-help').click(
		function(){
			contextHelp = !contextHelp;
			if (contextHelp)
				$('#help').addClass('help-on');
			else {
				hideHelp();
				$('#help').height(32);
				$('#help').removeClass('help-on');
			}	
		}
	);
	$('#manual').click(
		function(){
			window.open('manual/board/manual_'+mom.lang+'.pdf','manual','width=400,height=200'); 
		}
	);
}