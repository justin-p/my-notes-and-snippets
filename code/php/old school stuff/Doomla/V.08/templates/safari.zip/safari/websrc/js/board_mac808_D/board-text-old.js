var uiText = {
	"Language" :
	{
		"UK" : "Language",
		"NL" : "Taal",
		"FR" : "Langue"
	},
	"language_option" :
	{
		"UK" : "English",
		"NL" : "Nederlands",
		"FR" : "Fran&ccedil;ais"
	},
	"General" :
	{
		"UK" : "General",
		"NL" : "General"
	},
	"Inputs" :
	{
		"UK" : "Inputs",
		"NL" : "Ingangen"
	},
	"Outputs" :
	{
		"UK" : "Outputs",
		"NL" : "Uitgangen"
	},
	"Scrolls" :
	{
		"UK" : "Scrolls",
		"NL" : "Scrolls"
	},
	"PagingParty" :
	{
		"UK" : "Paging/Party",
		"NL" : "Paging/Party"
	},
	"Stations" :
	{
		"UK" : "Radio stations",
		"NL" : "Radio stations"
	},
	"Racks" :
	{
		"UK" : "Racks",
		"NL" : "Racks"
	},
	"Monitor" :
	{
		"UK" : "Headphone",
		"NL" : "Koptelefoon"
	},
	"not_active" :
	{
		"UK" : "Not active",
		"NL" : "Niet aktief"
	},
	"Connect" :
	{
		"UK" : "Connect",
		"NL" : "Connect"
	},
	"ST" :
	{
		"UK" : "ST",
		"NL" : "ST"
	},
	"Name" :
	{
		"UK" : "Name",
		"NL" : "Naam"
	},
	"Default" :
	{
		"UK" : "Default",
		"NL" : "Default"
	},
	"gain" :
	{
		"UK" : "Gain",
		"NL" : "Gain"
	},
	"Owner" :
	{
		"UK" : "Owner",
		"NL" : "Eigenaar"
	},
	"Station" :
	{
		"UK" : "Station",
		"NL" : "Station"
	},
	"Tuner" :
	{
		"UK" : "Tuner",
		"NL" : "Tuner"
	},
	"Output" :
	{
		"UK" : "Output",
		"NL" : "Uitgang"
	},
	"open" :
	{
		"UK" : "Open",
		"NL" : "Open"
	},
	"Scroll" :
	{
		"UK" : "Scroll",
		"NL" : "Scroll"
	},
	"Inputs_available" :
	{
		"UK" : "Inputs Available",
		"NL" : "Ingangen"
	},
	"Stations_available" :
	{
		"UK" : "Stations Available",
		"NL" : "Radio stations"
	},
	"move_selected_channels" :
	{
		"UK" : "Move selected channels",
		"NL" : "Verplaats geselecteerde scrolls"
	},
	"Nr" :
	{
		"UK" : "Nr",
		"NL" : "Nr"
	},
	"Freq" :
	{
		"UK" : "Freq",
		"NL" : "Freq"
	},
	"create_new_list_radio_presets" :
	{
		"UK" : "Sure to re-scan all stations?",
		"NL" : "Wilt U opnieuw de zenders scannen?"
	},
	"drop_preset_here_to_remove" :
	{
		"UK" : "Drop preset here to remove",
		"NL" : "Hier presets verwijderen"
	},
	"New_list" :
	{
		"UK" : "New_list",
		"NL" : "Maak nieuwe lijst"
	},
	"previous_station" :
	{
		"UK" : "Prev station",
		"NL" : "Vorig station"
	},
	"double_click_to_edit" :
	{
		"UK" : "Double-click to edit",
		"NL" : "Double-click om te wijzigen"
	},
	"press_Enter_to_submit" :
	{
		"UK" : "Press Enter to submit",
		"NL" : "Druk op Enter om toe te passen"
	},
	"next_station" :
	{
		"UK" : "Next Station",
		"NL" : "Volgend station"
	},
	"add_to_preset_stations" :
	{
		"UK" : "Add to preset stations",
		"NL" : "Voeg toe aan lijst"
	},
	"preset" :
	{
		"UK" : "Preset",
		"NL" : "Preset"
	},
	"Pi_code" :
	{
		"UK" : "Pi-code",
		"NL" : "Pi-code"
	},
	"RDS" :
	{
		"UK" : "RDS",
		"NL" : "RDS"
	},
	"RSSI" :
	{
		"UK" : "RSSI",
		"NL" : "RSSI"
	},
	"Room" :
	{
		"UK" : "Room",
		"NL" : "Ruimte"
	},
	"Input" :
	{
		"UK" : "Input",
		"NL" : "Ingang"
	},
	"volume" :
	{
		"UK" : "Volume",
		"NL" : "Volume"
	},
	"bass" :
	{
		"UK" : "bass",
		"NL" : "Bass"
	},
	"mid" :
	{
		"UK" : "Mid",
		"NL" : "Mid"
	},
	"treble" :
	{
		"UK" : "Treble",
		"NL" : "Treble"
	},
	"balance" :
	{
		"UK" : "Balance",
		"NL" : "Balance"
	},
	"muted" :
	{
		"UK" : "Muted",
		"NL" : "Muted"
	},
	"amplified" :
	{
		"UK" : "Amplified",
		"NL" : "Versterkt"
	},
	"info" :
	{
		"UK" : "Info",
		"NL" : "Info"
	},
	"RDS_on_Wall_Controller" :
	{
		"UK" : "RDS on Wall Controller",
		"NL" : "RDS zichtbaar op Wand controller"
	},
	"Hide_tone_setup_on_Wall_Controller" :
	{
		"UK" : "Hide tone setup on Wall Controller",
		"NL" : "Verberg toon setup op Wand controllers"
	},
	"Outputs_Stereo_Mono" :
	{
		"UK" : "Outputs Stereo/Mono",
		"NL" : "Uitgangen Stereo/Mono"
	},
	"All_outputs_Stereo" :
	{
		"UK" : "All outputs Stereo",
		"NL" : "Alle uitgangen Stereo"
	},
	"All_outputs_Mono" :
	{
		"UK" : "All outputs Mono",
		"NL" : "Alle uitgangen Mono"
	},
	"Output_1_3_Stereo" :
	{
		"UK" : "Output 1 to 3 Stereo",
		"NL" : "Uitg 1 t/m 3 Stereo"
	},
	"Output_1_2_Stereo" :
	{
		"UK" : "Output 1 and 2 Stereo",
		"NL" : "Uitg 1 en 2 Stereo"
	},
	"Output_1_Stereo" :
	{
		"UK" : "Output 1 Stereo",
		"NL" : "Uitg 1 Stereo"
	},
	"Output_2_4_Stereo" :
	{
		"UK" : "Output 2 to 4 Stereo",
		"NL" : "Uitg 2 t/m 4 Stereo"
	},
	"Output_3_4_Stereo" :
	{
		"UK" : "Output 3 and 4 Stereo",
		"NL" : "Uitg 3 en 4 Stereo"
	},
	"Output_4_Stereo" :
	{
		"UK" : "Output 4 Stereo",
		"NL" : "Uitg 4 Stereo"
	},
	"Internal_amplifiers" :
	{
		"UK" : "Internal Amplifiers",
		"NL" : "Interne versterkers"
	},
	"Chime" :
	{
		"UK" : "Chime",
		"NL" : "Dingdong"
	},
	"play" :
	{
		"UK" : "Play",
		"NL" : "Afspelen"
	},
	"My_settings" :
	{
		"UK" : "My Settings",
		"NL" : "Mijn Settings"
	},
	"My_settings_file" :
	{
		"UK" : "Settings file",
		"NL" : "Settings bestand"
	},
	"Load" :
	{
		"UK" : "Load",
		"NL" : "Laden"
	},
	"Save" :
	{
		"UK" : "Save",
		"NL" : "Opslaan"
	},
	"Restore" :
	{
		"UK" : "Restore",
		"NL" : "Herstellen"
	},
	"My_Settings_saved_in" :
	{
		"UK" : "Settings now saved in",
		"NL" : "Settings zijn opgeslagen in"
	},
	"Factory_settings" :
	{
		"UK" : "Factory Settings",
		"NL" : "Fabriek Settings"
	},
	"Input_settings" :
	{
		"UK" : "Input Settings",
		"NL" : "Ingang Settings"
	},
	"Outputs_and_scrolls" :
	{
		"UK" : "Outputs and scrolls",
		"NL" : "Uitgangen en scrolls"
	},
	"Tuners_and_stations" :
	{
		"UK" : "Tuners and stations",
		"NL" : "Tuners en stations"
	},
	"Paging_zones" :
	{
		"UK" : "Paging zones",
		"NL" : "Paging zones"
	},
	"Room_combi" :
	{
		"UK" : "Room Combining",
		"NL" : "Ruimte koppeling"
	},
	"slave" :
	{
		"UK" : "slave",
		"NL" : "slave"
	},
	"master" :
	{
		"UK" : "master",
		"NL" : "master"
	},
	"in_active_paging" :
	{
		"UK" : "in paging",
		"NL" : "in paging"
	},
	"in_active_combi" :
	{
		"UK" : "in active combi",
		"NL" : "in koppeling"
	},
	"in_active_paging_combi" :
	{
		"UK" : "in combi+paging",
		"NL" : "in koppeling+paging"
	},
	"State" :
	{
		"UK" : "State",
		"NL" : "Status"
	},
	"range" :
	{
		"UK" : "range",
		"NL" : "Min.Max"
	},
	"treb" :
	{
		"UK" : "treb",
		"NL" : "Hoog"
	},
	"page_ofs" :
	{
		"UK" : "Page_ofs",
		"NL" : "Page ofs"
	},
	"Muted" :
	{
		"UK" : "Muted",
		"NL" : "Muted"
	},
	"User_balance_allowed" :
	{
		"UK" : "User balance allowed",
		"NL" : "User balance toegestaan"
	},
	"Chimes_allowed" :
	{
		"UK" : "Chimes allowed",
		"NL" : "Dingdong toegestaan"
	},
	"Paging_allowed" :
	{
		"UK" : "Paging_allowed",
		"NL" : "Paging toegestaan"
	},
	"GPIO" :
	{
		"UK" : "GPIO",
		"NL" : "GPIO"
	},
	"upload" :
	{
		"UK" : "upload",
		"NL" : "upload"
	},
	"Local_name" :
	{
		"UK" : "Local_name",
		"NL" : "Local naam"
	},
	"Amplified" :
	{
		"UK" : "Amplified",
		"NL" : "Versterkt"
	},
	"no_chime" :
	{
		"UK" : "No chime",
		"NL" : "Geen chime"
	},
	"no_chime_to_play" :
	{
		"UK" : "no_chime_to_play",
		"NL" : "Geen chimes om af te spelen"
	},
	"public" :
	{
		"UK" : "public",
		"NL" : "Publiek"
	},
	"Paging" :
	{
		"UK" : "Paging",
		"NL" : "Paging"
	},
	"PartyMaster" :
	{
		"UK" : "PartyMaster",
		"NL" : "PartyMaster"
	},
	"line_out_only" :
	{
		"UK" : "Only line-out",
		"NL" : "Alleen line-out"
	},
	"always_on" :
	{
		"UK" : "(Always aan)",
		"NL" : "(Altijd aan)"
	},
	"line_out_internal_amplifier" :
	{
		"UK" : "line_out_internal_amplifier",
		"NL" : "Heeft ook line-out"
	},
	"" :
	{
		"UK" : "",
		"NL" : ""
	},
};
