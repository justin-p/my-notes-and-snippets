mom.changed.radio = new notifier();
mom.changed.output = new notifier();
mom.changed.input = new notifier();
mom.output = {};
mom.input = {}; 
mom.busy = {config : 1};
firm = {};
hasTemp = true;
curTemp = "22.0";
var test = 0;
var connectionStreaming = 'MP3';

function outputConnection(n) {
	var a = (isStereo(n,mom.output.stereo))?'':((n%2==1)?'L':'R');
	return Math.ceil((n)/2) + a;
}

function inputType(n) {
	if (!n || n > mom.input.inputs.length)
		return "AUX";
	return mom.input.inputs[n-1].type;
}

function inputConnection(n) {
	var a = (isStereo(n,mom.input.stereo))?'':((n%2==1)?'L':'R');
	var la = (isStereo(n,mom.input.stereo))?'':((n%2==1)?'A':'B');
	if (inputType(n)  == 'AUX') return inputType(n)  + '-' + Math.ceil((n)/2) + a;
	if (inputType(n)  == connectionStreaming) return inputType(n)  + ((a > '')?'-':'') + a;
	if (inputType(n)  == 'LOCAL') return inputType(n)  + '-' + Math.ceil((n)/2) + la;
	if (inputType(n)  == 'TUNER') return inputType(n)  + '-' + input2Tuner(n) + a;
}

function outputName(n) {
	return mom.output.outputs[n-1].name;
}

function inputName(n) {
	return mom.input.inputs[n-1].name;
}

function inputOwner(n) {
	return mom.input.inputs[n-1].owner;
}

function inputGain(n) {
	return mom.input.inputs[n-1].gain;
}

function setConfig (query) {
	balancedAjax({
		url: query
	});
}

function stereoBit(i) {
	return (1 << ((i - 1)  / 2));
}

function isStereo(i, stereoMask){
	return (stereoBit(i) & stereoMask) != 0; 
}

function flipStereo(i, stereoMask) {
	if (isStereo(i, stereoMask)) { 
		return stereoMask - stereoBit(i);
	} else {
		return stereoMask + stereoBit(i);
	}
}

function changeOutputName(n, name) {
	var encodedurl = encodeURIComponent(name);
	var query = 'output='+n+'&_name='+encodedurl;
	setConfig(query);
}

function changeInputName(n, name) {
	var encodedurl = encodeURIComponent(name);
	var query = 'input='+n+'&_name='+encodedurl;
	setConfig(query);
}

function flipOutStereo(i) {
	setConfig('cfg=*&_out_stereo='+flipStereo(i,mom.output.stereo).toString(10));
}

function flipInStereo(i) {
	setConfig('cfg=*&_in_stereo='+flipStereo(i,mom.input.stereo).toString(10));
}

function room2Output(rnr) {
	var i = 0;
	var n = 0;
	while  ((n < rnr) && (i <= mom.output.outputs.length)) { //
		i++;
		if ((i%2 == 1) || !isStereo(i,mom.output.stereo)) n++;	
	}
	return i;
}

function room2Output2(rnr) {
	var i = room2Output(rnr);
	if ((i > 0) && isStereo(i,mom.output.stereo)) i++;
	return i;
}

function output2Room(onr){
	var n = 0;
	for (o = 1; o <= onr; o++) {
		if ((o%2 == 1) || !isStereo(o,mom.output.stereo)) n++;
	}
	return n;
}

function maxRooms(){
	return output2Room(mom.config.max_outputs);
}

function channel2Input(cnr) {
	var i = 0;
	var n = 0;
	while  ((n < cnr) && (i < mom.input.inputs.length)) {
		i++;
		if ((i%2 == 1) || !isStereo(i,mom.input.stereo)) n++;
	}
	return i;
}

function input2Channel(inr){
	var n = 0;
	for (i = 1; i <= inr; i++) {
		if ((i%2 == 1)|| !isStereo(i,mom.input.stereo)) n++;
	}
	return n;
}

function maxChannels() {
	return input2Channel(mom.config.max_inputs);
}

function tuner2Input(tnr) {
	var t = 0;
	for (var c = 1; c <= maxChannels(); c++) {
		i = channel2Input(c);
		if (inputType(i) == 'TUNER') {
			t++;
			if (t == tnr) return i;
		}
	}
	return 0;
}	

function input2Tuner(inr){
	var t = 0;
	for (var i = 1; i <= inr; i++) {
		if ((inputType(i) == 'TUNER') && ((i%2 == 1) || (!isStereo(i,mom.input.stereo)))) t++
	}
	return (inputType(i) == 'TUNER')?t:0;
}

function channelTuner(i) {
	for (var t = 1; t <= mom.config.max_tuners; t++)
		if (tuner2Input(t) == i) return t; 
	return 0;
}

function roomTunerChannel (roomNr) {
    var outputNr = room2Output(roomNr);
    var outputNr2 = room2Output2(roomNr);
    for (var t = 1; t <= mom.config.max_tuners; t++) {
        var inputNr = tuner2Input(t)-1;
        if (inputNr >= 0 && inputNr < mom.input.inputs.length) {
            if ((mom.input.inputs[inputNr].owner == outputNr)||
                    (mom.input.inputs[inputNr].owner == outputNr2)) return tuner2Input(t);
        }
    }
    return 0;
}

function roomTuner(roomNr) {
	for (var t = 1; t <= mom.config.max_tuners; t++) {
		if ((mom.input.inputs[tuner2Input(t)-1].owner == room2Output(roomNr))||
				(mom.input.inputs[tuner2Input(t)-1].owner == room2Output2(roomNr))) return Number(t);
	}
	return 0;
}

function parseConfig(data) {
	mom.config = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]) );
}

function getConfig () {
	balancedAjax({
		url			: 'cfg=1&config=?',
		async		: false,
		success	: parseConfig,
	});
}
function parseLang(data) {
	mom.lang = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]) );
}

function getLang () {
	balancedAjax({
		url			: 'cfg=*&lang=?',
		async		: false,
		success	: parseLang
	});
}

// cfg=1&page_rel_volume=0
function parsePageRelVolume(data) {
	mom.page_rel_volume = decodeURIComponent(data.slice(data.indexOf('?')+1).split('&')[1].split('=')[1]) - 0;
	displayPageRelVolume();
}

function getPageRelVolume () {
	balancedAjax({
		url: 'cfg=*&page_rel_volume=?',
		async : false,
		success: parsePageRelVolume
	});
}

function parseRadio(data) {
	if (dataChanged('radio',data)){
		mom.radio = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]).replace(/=/g,':')); // verwijder replace?????
		mom.changed.radio.notify();
	}
}

function getRadio () {
	balancedAjax({
		url			: 'cfg=1&radio=?',
		async		: false,
		success	: parseRadio
	});
}

function parseOutputs(data) {
	if (dataChanged('output',data)){
		mom.output.stereo = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		mom.output.outputs = jQuery.parseJSON(decodeURIComponent(data.split('&')[2].split('=')[1]));
		mom.changed.output.notify();
	}
}	

function urlOutputs(){
	if (mom.busy.config == 1)
		return 'cfg=1&_out_stereo=?&_outputs=?'; 
	else
		return '';
}

function getOutputs () {
	balancedAjax({
		url			: urlOutputs(),
		async		: false,
		success	: parseOutputs
	});
}

function parseInputs(data) {
	if (dataChanged('input',data)){
		mom.input.stereo = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		mom.input.inputs = jQuery.parseJSON(decodeURIComponent(data.split('&')[2].split('=')[1]));
		mom.changed.input.notify();
	}	
}	

function urlInputs (){
	if (mom.busy.config == 1)
		return 'cfg=1&_in_stereo=?&_inputs=?';
	else
		return '';
}

function getInputs () {
	balancedAjax({
		url			: urlInputs(),
		async		: false,
		success	: parseInputs
	});
}

function parseTemperature(data) {
	var newTemp = decodeURIComponent(data.split('&')[1].split('=')[1]);
	if (newTemp == '?') {
		hasTemp = false;
	} else if (curTemp != newTemp) {
		curTemp = newTemp;
		$('.temperature').text(curTemp + ' Celcius');
	}
}	

function urlTemperature(){
	return 'firm=1&temp=?'; 
}

function version() {
	balancedAjax({
		async : false,
		url: 'firm=*&config=?',
		success : function(data){firm = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1])); }
	});	
	return 'rack ' + firm.version + ' - web ' + websrcVersion ;
}

function getScheme(){
		getLang();
		getConfig();
		getRadio();
		getInputs();
		getOutputs();
}
