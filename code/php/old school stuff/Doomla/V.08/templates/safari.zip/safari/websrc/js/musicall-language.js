function xLateLanguages(){
	var key = '{language_option}'.replace(/[\{\}]/g,''); //force extractor to find this key
	if (uiText[key])
		return uiText[key];
	else
		return {"NL" : "Nederlands", "EN" : 'English'};
}

function xLateText(text){
	do {
		var keys = text.match(/\{\w+\}/);
		if (keys != null) {
			text = text.replace(keys[0],xLateKey(keys[0]));
		}	
	} while (keys != null);
	return text;
}

function xLateKey(key){
	key = key.replace(/[\{\}]/g,'');
	var aText;
	var translator;
	if (uiText[key])
		translator = uiText[key];
	else
		return '?'+key;
	
	aText = translator[mom.lang];
	if (typeof aText == 'undefined') aText = '?'+translator.EN;
	if (typeof aText == 'undefined') aText = '?'+key;
	var limit = parseInt(translator.limit);
	if (limit > 0) aText = aText.substr(0,limit);
	return aText;
}