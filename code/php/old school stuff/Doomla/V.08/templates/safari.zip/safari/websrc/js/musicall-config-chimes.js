var chimeScrollRegion = 0;
var maxChimesB = 8; // Belgium limited
mom.changed.chimes = new notifier();
mom.changed.gpio = new notifier();

function parseChimes (data) {
	if (dataChanged('chimes',data)){
		mom.chimes = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		mom.changed.chimes.notify();
	}	
}

function urlChimes(){
	return 'chimes=1&list=?';
}

function getChimes(){
	balancedAjax({
		url			: urlChimes(),
		async		: false,
		success	: parseChimes
	}); 
}

function deleteChime(filename){
	balancedAjax({
		forced : true,
		url: 'chimes=*&remove='+filename+''
	});
	for (var c = 0; c < mom.chimes.length; c++){
		if (filename == mom.chimes[c].name) {
			mom.chimes.splice(c,1);
		}	
	}
	mom.changed.chimes.notify();
}

function activateChimesList(){
	$('.delete-chime').click(function(){
		deleteChime($(this).attr('element'));
	});
}

function displayChimesList(){
	var view = '';
	for (var c = 0; c < mom.chimes.length; c++){
		view += '<li><span class="list-chime">'+mom.chimes[c].name +'</span>'+ 
						'<a target="_blank" href="http://'+myRackName()+'/audio/chimes/'+mom.chimes[c].name+'"><img title="'+xLateText('{play}')+' '+mom.chimes[c].name+'" src="css/images/play.png"/></a>'+
						'<span class="delete-chime" title="'+xLateText('{delete}')+' '+mom.chimes[c].name+'" element="'+mom.chimes[c].name+'"><img src="css/images/delete.png"/></span></li>';
	}
	$('#chimes-list').html(view);
	chimeScrollRegion.update();
	activateChimesList();
}

function displayGPIOChimes(){
	if (board=='mac808_B'){
		var maxChimes = mom.chimes.length;
		if (maxChimes > 8) maxChimes = 8;
		for (var c = 0; c < maxChimes; c++){
			if (!$.exists('#chime'+(c+1).toString())){
				var thisRow = '<li id="chime'+(c+1).toString()+'" title=""><label>'+(c+1).toString()+'</label><input type="radio" name="chime"></li>';
				$('#gpio ul').append(thisRow);
			}
			$('#chime'+(c+1).toString()+' input').val(mom.chimes[c].name);
			$('#chime'+(c+1).toString()).attr('title',mom.chimes[c].name);
		}
		var l = $('#chime li').length;
		for (var obs = c; obs < l; obs++){
			$('#chime'+obs.toString()).remove();
		}
	} else {
		var thisList = '<option value="">{no_chime}</option>';
		for (var c = 0; c < mom.chimes.length; c++){
			thisList += '<option value="'+mom.chimes[c].name+'">'+mom.chimes[c].name+'</option>';
		} 
		thisList = xLateText(thisList);
		for (var g = 1; g <= mom.config.max_gpio_in; g++){
			if (!$.exists('#gpio'+g.toString())){
				var thisRow = '<li id="gpio'+g.toString()+'"><select name="gpio'+g.toString()+'">'+thisList+'</select>'+
											'<a target="_blank" ><img title="'+xLateText('{play}')+'" src="css/images/play.png"/></a>';
				$('#gpio ul.gpio').append(xLateText(thisRow));
			} else {
				$('#gpio'+g.toString()+' select').html(thisList);
			}
		}
	}
	activateGPIOChime();
	displayGPIO2();
	if (board!='mac808_B'){		
		displayChimesList();		
	}
}

function displayGPIO2(){
	if (!mom.gpio) return;
	if (board=='mac808_B'){
		$('#gpio input:checked').removeAttr('checked');
		$('#gpio input[value="'+mom.gpio[0].chime+'"]').attr('checked','checked');
		if (mom.gpio[0].chime) {
			$('#gpio a').attr('href','http://'+myRackName()+'/audio/chimes/'+mom.gpio[0].chime);
			$('#gpio a').attr('title',mom.gpio[0].chime);
		} else {
			$('#gpio a').removeAttr('href');
			$('#gpio a').attr('title',xLateText('{no_chime_to_play}'));
		}
	}	else {
		for (var g = 1; g <= mom.config.max_gpio_in; g++){
			$('#gpio'+g.toString()+' select').val(mom.gpio[g-1].chime);
			if (mom.gpio[g-1].chime) {
				$('#gpio'+g.toString()+' a').attr('href','http://'+myRackName()+'/audio/chimes/'+mom.gpio[g-1].chime);
				$('#gpio'+g.toString()+' a').show();
			}	
			else {
				$('#gpio'+g.toString()+' a').attr('href','');
				$('#gpio'+g.toString()+' a').hide();
			}	
		}		
	}
}	

function displayGPIO(){
	displayGPIO2();
}

function parseGPIO (data) {
	mom.gpio = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
	mom.changed.gpio.notify();
}

function urlGPIO(){
	return 'cfg=1&_gpio_in_f=?';
}

function getGPIO(){
	balancedAjax({
		url			: urlGPIO(),
		async		: false,
		success	: parseGPIO
	}); 
}

function changeGPIOChime(g){
	if (board=='mac808_B'){
		mom.gpio[0].chime = $('#gpio input:checked').val();
	}	else {
			mom.gpio[g-1].chime = $('#gpio'+g.toString()+' select').val();
	}	
	balancedAjax({
		url: 'gpio_in_f='+g.toString()+'&_settings='+$.toJSON(mom.gpio[g-1])
	});
	displayGPIO2();
}

function activateGPIOChime(){
	if (board=='mac808_B'){
		$('#gpio input').click(function(){changeGPIOChime(1);});
	}	else {
		for (var g = 1; g <= mom.config.max_gpio_in; g++){
			$('#gpio'+g.toString()+' select').change(function(){
				var i = parseInt($(this).parent().attr('id').replace('gpio',''));
				changeGPIOChime(i);
			});
		}	
	}
}
