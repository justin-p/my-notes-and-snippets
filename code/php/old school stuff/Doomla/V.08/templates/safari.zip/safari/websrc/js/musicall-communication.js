commHistory = '';
commHistoryMax = 10;
commErrorsOrange = 2;
commErrorsRed = 8;
lampHandlers = new Array();
srtt = 1000;  // Start off with 2 * 1000 ms timout
pollCycle = 250; // to be tuned to srtt

requestsBusy = 0;
maxRequestsBusy = 2;
maxMaxRequestsBusy = 5;
minMaxRequestsBusy = 1;
requestsBusyRetryTime = 50;
sequenceProp = '';
sequencePostponedRequest = false;

// ####### deze kan worden verbeterd!!~!!!  #########
function tripTimeGet (minTime) {
	var tmout = srtt < 50 ? 100 : (2 * srtt);
	return tmout > minTime ? tmout : minTime;
}

function tripTimeCalc (queryTime) {
	var current = jQuery.now() - queryTime;
	// Only use reasonable numbers, between 1 ms and 10 secs
	if (current >= 1 && current < 10000) {
		if (srtt >= current)  // RTT becomes smaller: adapt slowly
			srtt = Math.round ((7 * srtt + 1 * current) / 8);
		else                  // RTT becomes larger: adapt quicker
			srtt = Math.round ((6 * srtt + 2 * current) / 8);
		
		// tolerate less busy requests when higher srtt	
		maxRequestsBusy =  Math.ceil((maxMaxRequestsBusy * 50 - current)/50);
		maxRequestsBusy = (maxRequestsBusy > minMaxRequestsBusy)?maxRequestsBusy:minMaxRequestsBusy;
		
		message('current '+ current +' srtt ' + srtt + ' max busy requests ' + maxRequestsBusy);
		$.ajaxSetup({
			timeout		: tripTimeGet (pollCycle-50)
		});
	}
}
// identify slider-request sequences
sequenceRequestTag = [{context : 'output', property : ['min','max','volume','bass','mid','treble','balance','page_ofs']},{context : 'input', property : ['gain']}];
function getRequestSequenceProp(url){
	for (var c in sequenceRequestTag){
		for (var p in sequenceRequestTag[c].property)
			if ((url.indexOf(sequenceRequestTag[c].context+'=') > -1) && 
					((url.indexOf('&'+sequenceRequestTag[c].property[p]+'=') > -1)||
						(url.indexOf('&_'+sequenceRequestTag[c].property[p]+'=') > -1))) return sequenceRequestTag[c].property[p];				
	}
	return '';
}

function ajaxHistory(stat, startTime){
    if (stat == 's')
        tripTimeCalc (startTime);
    else
        tripTimeCalc (jQuery.now() - 2000); //was 5000
	if (commHistory.length >= commHistoryMax)commHistory = commHistory.substr(1,commHistoryMax-1);
	commHistory += stat;
}

ajaxErrorMessage = function(XMLHttpRequest, textStatus, errorThrown) {
	message('MAC808 no response (' + tripTimeGet (pollCycle) + ' ms): ' + textStatus + ((errorThrown)?' (error: ' + errorThrown + ')':''), true);
}

function clearSequence(){
	if (requestsBusy == 0) { 
		sequenceProp = "";
		if (typeof(sequencePostponedRequest) == 'object'){ //now we fire last postponed sequence request
			sequencePostponedRequest.isSequence = false; // jump out of sequence
			$$ajax(sequencePostponedRequest);
			sequencePostponedRequest = false;
		}
	}
}

$$ajax = function(args){
	var startTime = jQuery.now();
	
	
	args.url = audioPrefix + args.url;
	if (args.isSequence || args.isUIGet) { /*logPrintf('busy+ '+args.url);*/ requestsBusy++;}
	//redirect success callback
	var success = (args.success)?args.success:false;
	args.success = function(data){
		ajaxHistory('s',startTime);
		//logPrinf(data.substring(0,30));
		if (typeof data != 'undefined'){ 
			data = data.slice(data.indexOf('?')+1).replace(/\n/g,''); // remove audioPrefix and linefeeds
			if (success) success(data);
		} else logPrintf('no reply for '+args.url);
	}
	
	//redirect error callback
	var error = (args.error)?args.error:false;
	args.error = function (XMLHttpRequest, textStatus, errorThrown) {
		ajaxHistory('f',startTime);
		ajaxErrorMessage(XMLHttpRequest, textStatus, errorThrown);
		if (error) error(XMLHttpRequest, textStatus, errorThrown);
	}
	
	// redirect complete callback
	var complete = (args.complete)?args.complete:false;
	args.complete = function(){
		if (args.isSequence || args.isUIGet) { requestsBusy--; /*logPrintf('busy- '+args.url +(requestsBusy>0?'**BUSY**':'')); */}
		if (args.isSequence) clearSequence();
		if (complete) complete();
	}
//		if (args.isSequence) {
			//args.async = false;
//			setTimeout(function(){$.ajax(args);},1);
//		} else 
			$.ajax(args);
}

function postponedPollRequest(args){
	if (requestsBusy > 0)
		setTimeout(function(){postponedPollRequest(args);},requestsBusyRetryTime);
	else 
		$$ajax(args);
}

// redefine/redirect $.ajax
balancedAjax = function (args){
	if (args.url == '') return false;
	args.isGet = args.url.indexOf('=?') != -1;
	var nextRequestProp = getRequestSequenceProp(args.url);
	
	args.isSequence = !args.isGet && (nextRequestProp != '');
	args.async = typeof(args.async)=='boolean'?args.async:true;
	args.isPoll = typeof(args.isPoll)=='boolean'?args.isPoll:false;
	args.isUIGet = args.isGet && args.async && !args.isPoll;
	
	if (args.isSequence){
		if ((nextRequestProp != sequenceProp) || (requestsBusy < maxRequestsBusy) || args.forced){
			sequenceProp = nextRequestProp;
			$$ajax(args); 
		} else {
			//logPrintf('****** CANCELED ******');
			sequencePostponedRequest = args; // keep last postponed sequence request, to be executed when no more requests busy
		}
	} 
	else if (args.isUIGet){ // ui-triggered get with urgence
		$$ajax(args);
	}
	else if (args.isPoll){ // lets prevent this from firing while busy requests
		if (requestsBusy > 0)
			return false;
		else
			$$ajax(args);
	} else 
			$$ajax(args);
	return true;
}

function getHTML(query) {
	var returnValue = '';
	$.ajax({
		async : false,
		url: query,
		success: function(data){
			returnValue = xLateText(data);
		}
	});
	return returnValue
}

function checkCommunication() {
	var e = commHistory.replace(/s/g,'');
	var lampStatus = 0;
	if (e.length >= commErrorsRed) lampStatus = 2;
	else if (e.length >= commErrorsOrange) lampStatus = 1;
	for (var h in lampHandlers) lampHandlers[h](lampStatus);
}

function registerLampHandler(handler) {
	lampHandlers[lampHandlers.length] =  handler;
}

window.setInterval(checkCommunication, 1000);

$.ajaxSetup({
		dataType	: 'text',
});
