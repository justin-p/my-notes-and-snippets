var myRoomUpdate = false;
var roomScrollRegion = 0;
var channelScrollRegion = 0;
var actChannel = new Object();
var fixedOutputs;
var busyU = {vchan : false, volume : false, bass : false, mid : false, treble : false, balance : false};

function info(info) {
	$('.info .info-box').html(info);
}

function channelInfo() {
	var i = '';
	if (actChannel.ps > '') i += 'Station: ' + actChannel.ps + '<br/>';
	if (actChannel.freq > 0) i += 'Freq: ' + (actChannel.freq/100).toFixed(2) + 'Hz<br/>';
	if (actChannel.rds > '') i += 'Rds: ' + actChannel.rds + '<br/>';
	info(i);
}

function clearActChannel() {
	actChannel.ps = '';
	actChannel.freq = 0;
	actChannel.rds = '';
	actChannel.rssi = '';
}

function displayRoom(roomNr){
	$('.balance').css('visibility',((isStereo(room2Output(roomNr),mom.output.stereo))?'visible':'hidden'));
	getRoomChannels(roomNr);
	getRoomSettings(roomNr);
	displayOutputBusy(roomNr,'.busy');
}

// selected room 	get/set
function roomNr(setNr) {
	var actNr = 0;
	if ($.exists('#room-selection .selected')) 
		actNr = parseInt($('#room-selection .selected').attr('id').replace('room',''));
	if  (setNr > 0 && setNr != actNr) { //set
		actNr = setNr;
		$('#room-selection .selected').removeClass('selected');
		$('#room'+actNr).addClass('selected');
		displayRoom(actNr);
	}
	return actNr;
}

// selected channel get/set
function chanNr(setNr) {
	var actNr = -1;	
	if ($.exists('#channel-selection .selected'))
		var actNr = parseInt($('#channel-selection .selected').attr('id').replace('channel',''));
	if (setNr != null && setNr != actNr) {
		actNr = setNr;	
		$('#channel-selection .selected').removeClass('selected');
		$('#channel'+setNr).addClass('selected');
	}
	return actNr;	
}

function displaySlider(id, setNr) {
	if ((setNr != null) && ($('#'+id).slider('value') != setNr)){
			$('#'+id).slider('value', setNr);
			$('#x_'+id).text(mom.config[id+'_ofs']+setNr);
	}
}

function outputsFixed(){
	for (var o in fixedOutputs)
		if (fixedOutputs[o] != 0) return true;
	return false;	
}

function hideNonFixedRooms(){
	for (var n = 1; n <= maxRooms(); n++){
		var o = room2Output(n);
		if (fixedOutputs[64-o] == 0) 
			$('#room'+n).addClass('non-fixed');
		else	
			$('#room'+n).removeClass('non-fixed');
	}
}

function firstFixedRoomNr(){
	if (outputsFixed()) {
		for (var n = 1; n <= maxRooms(); n++){
			var o = room2Output(n);
			if (fixedOutputs[64-o] == 1) return n;
		}
	}	
	else return 1;
}

function activateRooms() {
	$('.room-selector').mousedown(function (){$(this).click();});
	$('.room-selector').click(function (){
		roomNr(parseInt($(this).attr('id').replace('room','')));
	});
}

function displayRoomList() {
	for (var n = 1; n <= maxRooms(); n++){
		if ($.exists('#room' + n))
			$('#room' + n).html(outputName(room2Output(n))+'<span class="room-busy" id="room-busy'+n.toString()+'"></span>');
		else {
			$('#room-selection').append('<span class="room-selector" id="room'+n.toString()+'">'+outputName(room2Output(n))+'<span class="room-busy" id="room-busy'+n.toString()+'"></span></span>');
		}	
	}
	for (var n = maxRooms() + 1; n <= mom.config.max_outputs; n++){
		$('#room' + n).remove();
	}
	if (outputsFixed()) hideNonFixedRooms();
	roomNr(firstFixedRoomNr());
	displayListBusy('#room-busy');
	activateRooms();
	roomScrollRegion.update();
}

function changeRoomChannel(chanNr){
	setRoomSettings(roomNr(), 'vchan', chanNr+1);
}

function parseTunerSettings(data){
	mom.tunerSettings = jQuery.parseJSON(data.split('&')[1].split('=')[1]); 
	for (var s in mom.tunerSettings) {
		switch (s){
			case 'freq'	: actChannel.freq = Number(mom.tunerSettings[s]); break;
			case 'rds'	: actChannel.rds = decodeURIComponent(mom.tunerSettings[s]); break;
			case 'rssi'	: actChannel.rssi = decodeURIComponent(mom.tunerSettings[s]); break;
			case 'ps'		: actChannel.ps = (mom.tunerSettings.pi != '0x0000')?decodeURIComponent(mom.tunerSettings[s]):''; break;
		}
	}
	channelInfo();
}

function getTunerSettings(tunerNr) {
	balancedAjax({
		url: 'radio='+ tunerNr+'&rds_info=?',
		isPoll : true,
		success: parseTunerSettings
	});
}

function getChannelinfo(chanNr) {
	if (typeof mom.roomChannels[chanNr] == 'undefined') return; // not fetched yet
	clearActChannel();
	var aTuner = input2Tuner(mom.roomChannels[chanNr].channel);
	if (aTuner > 0) getTunerSettings(aTuner); else channelInfo();
}

function displayMuted(muted) {
	if (muted) 
		$('.muted input').attr('checked','checked');
	else
		$('.muted input').removeAttr('checked');
}

function displayAmplified(amplified) {
	$('#ampli-lamp0').css('visibility',(amplified)?'hidden':'visible');
	$('#ampli-lamp1').css('visibility',(amplified)?'visible':'hidden');
}

function parseRoomSettings(data){
	if (myRoomUpdate) return;
	mom.roomSettings = jQuery.parseJSON(data.split('&')[1].split('=')[1] );
	for (var s in mom.roomSettings) {
		switch (s){
			case 'vchan'		: if (!busyU[s]) chanNr(mom.roomSettings[s]-1); getChannelinfo(chanNr()); break;
			case 'volume'		: ;
			case 'bass'			: ;
			case 'mid'			: ;
			case 'treble'		: ;
			case 'balance'	: if (!busyU[s]) displaySlider(s,mom.roomSettings[s]); break;
			case 'muted'		: displayMuted(mom.roomSettings[s]==1); break;
			case 'amp'			: displayAmplified(mom.roomSettings[s]==1); break;
		}	
	}
}

function urlRoomSettings(){
	var r = roomNr();
	if (r <= 0) return '';
return 'output='+room2Output(r)+'&settings=?';
}

function getRoomSettings(roomNr) {
	if (roomNr <= 0) return;
	balancedAjax({
		url: 'output='+room2Output(roomNr)+'&settings=?',
		success: parseRoomSettings
	});
}

function setRoomSettings(roomNr, property, value, forced) {
	myRoomUpdate = true; // block interference from polls en echo's
	var cmd = property + '=' + value;
	balancedAjax({
		url: 'output='+room2Output(roomNr)+'&'+ cmd,
		forced	: (forced)?forced:false,
		complete: function(){
			myRoomUpdate = false;
		},
	});
}

function activateRoomChannels() {
	$('.channel-selector')
		.mousedown(function(){busyU['vchan'] = true; changeRoomChannel(chanNr(parseInt($(this).attr('id').replace('channel',''))));})
		.mouseup(function(){busyU['vchan'] = false;})
}

function displayRoomChannels() {
	var view = '';
	for (var c in mom.roomChannels) {
		view += '<span class="channel-selector" id="channel'+c+'">'+mom.roomChannels[c].name+'</span>';
	}
	$('#channel-selection').html(view);
	channelScrollRegion.update();
	activateRoomChannels();
}

function parseRoomChannels(data) {
	if (dataChanged('roomChannels',data)) {
		mom.roomChannels = jQuery.parseJSON( decodeURIComponent(data.split('&')[1].split('=')[1]) );
		displayRoomChannels();
	}	
}

function urlRoomChannels(){
	var r = roomNr();
	if (r <= 0) return '';
	return 'output='+room2Output(r)+'&chn_list=?';
}

function getRoomChannels(roomNr) {
	if (roomNr <= 0) return;
	balancedAjax({
		url			: 'output='+room2Output(roomNr)+'&chn_list=?',
		success	: parseRoomChannels
	});
	getPagingCombi();
}

function lampHandlerRoomView(lampStatus) {
	if ($('img#lamp'+lampStatus).css('visibility') == 'visible') return;
	for (var l = 0; l <=2; l++) {
		$('img#lamp'+l).css('visibility',(lampStatus==l?'visible':'hidden'));
	}
}

function changeMuted() {
	setRoomSettings(roomNr(),'muted',($('.muted input').is(':checked'))?'1':'0');
}

function displayMyRoomBusy(){
	displayOutputBusy(roomNr(),'.busy');
}
function displayRoomListBusy(){
	displayListBusy('#room-busy');
}

function name2Output(name){
	name = $.trim(name);
	for (var n = 1; n <= maxRooms(); n++){
		var o = room2Output(n);
		if (name == outputName(o)) return o;
	}
	return 0;
}

function fixOutputs(){
	fixedOutputs = hexToBinArr('0');
	var url = window.location.href;
	if (url.indexOf('?') > 0) {
		var args = url.substr(url.indexOf('?')+1).split('&');
		for (var a in args){
			var tag = args[a].split('=')[0];
			var value = decodeURIComponent(args[a].split('=')[1]);
			if (tag == 'view'){
				var outputs = value.split(',')
				for (var o in outputs){
					output = parseInt(outputs[o]);
					if (output > 0 && output <= 64)
						fixedOutputs[64-output] = 1;
					else {
						output = name2Output(outputs[o]);
						if (output > 0)
							fixedOutputs[64-output] = 1;
					}
				}		
			}
		}	
	}
}

function slide(data) {
	var id = $(data.me).attr('id');
	setRoomSettings(roomNr(), id, data.ui.value,(data.forced)?data.forced:false);
	$('#x_'+id).text(mom.config[id+'_ofs']+data.ui.value);
}

var combiData = new Array();
var pagingData = new Array();

function parsePagingCombi(data) {
	// cfg=1&pages=[ {"channel":-1,"selection":"0x0","IP":"0.0.0.0","port":0,"name":""} ]&combies=[ {"name":"combi_01","master":1,"active":0,"multi":0,"outputs":"0xFF"} ]
	var newPaging = jQuery.parseJSON(data.split('&')[1].split('=')[1]);
	if (pagingData != newPaging) {
		pagingData = newPaging;
		if (pagingData[0].channel <= 0) {
			$('.testPaging input').removeAttr('checked');
			$('.testPaging input').attr('disabled','disabled');
		} else {
			$('.testPaging input').removeAttr('disabled');
			if (pagingData[0].selection == "0x0") {
				$('.testPaging input').removeAttr('checked');
			} else {
				$('.testPaging input').attr('checked','checked');
			}
		}
	}
	var newCombi = jQuery.parseJSON(data.split('&')[2].split('=')[1]);
	if (combiData != newCombi) {
		combiData = newCombi;
		if (combiData[0].active)
			$('.testCombi input').attr('checked','checked');
		else
			$('.testCombi input').removeAttr('checked');
	}
}

function getPagingCombi() {
	balancedAjax({
		url			: 'cfg=*&pages=?&combies=?',
		success	: parsePagingCombi
	});
}

function changePaging() {
	if ($('.testPaging input').is(':checked'))
		setConfig('page=1&cont=1', false);
	else
		setConfig('page=1&stop=1', false);
}

function changeCombi() {
	if ($('.testCombi input').is(':checked'))
		setConfig('combi=1&active=1', false);
	else
		setConfig('combi=1&active=0', false);
}

function userRoomView(){
	myRoomUpdate = false;
	fixOutputs();
	
	document.write(getHTML('html/testing-view.html'));	

	$('div.slider').each(function() {
		$(this).empty().slider({
			value: 1,
			min: 0,
			max: mom.config[$(this).attr('id')+'_range']-1,
			range: 'min',
			animate: true,
			orientation: 'vertical',
			slide: function( event, ui ) {
				slide({me : this, ui : ui});
			},
			start : function(){busyU[$(this).attr('id')] = true;},
			stop : function(event, ui){
							slide({me : this, ui : ui, forced : true});
							busyU[$(this).attr('id')] = false;
			}
		});
		var me = this;
		var id = $(this).attr('id');
		$('.box.'+id).mouseleave(
			function(){
				if (busyU[id]) { $(me).mouseup(); }
			}
		);
	});

	$('.muted input').click(function(){changeMuted();});
	
	roomScrollRegion = $('#roomregion');
	roomScrollRegion.tinyscrollbar();

	channelScrollRegion = $('#channelregion');
	channelScrollRegion.tinyscrollbar();

	mom.changed.output.register(displayRoomList);
	mom.changed.busy.register(displayRoomListBusy);
	mom.changed.busy.register(displayMyRoomBusy);
	registerLampHandler(lampHandlerRoomView);

	$('.testPaging input').click(function(){changePaging();});
	$('.testCombi input').click(function(){changeCombi();});

	$(function(){
		$('div#container').css('visibility','visible');
		getCombiesConfig();
		getZonesConfig();
		registerPoll([''],{id : 'config'},{url: urlOutputs, success: parseOutputs});
		registerPoll([''],{id : 'config2'},{url: urlInputs, success: parseInputs});
		displayRoomList();
		requestsBusy = 0; //hack
		registerPoll([''],{id : 'user', weight : 20},{url: urlRoomChannels, success: parseRoomChannels});
		registerPoll([''],{id : 'user'},{url : urlRoomSettings, success: parseRoomSettings});
		registerPoll([''],{id : 'user'},{url : urlBusy, success: parseBusy});
		$('.version').text(version);
	}); 
}
