var pagingCombiScrollRegion = 0;
var pagingCombiHTML = '';
var actPageNr =1;
busyP = {channel : false};

function pageNr(){
	return actPageNr;
}

function setCombiConfig(){
	balancedAjax({
		url: 'cfg=1&_combies='+$.toJSON(mom.combies),
		complete: function(){busyC.combi = false;}
	});
}
function setZonesConfig(){
	balancedAjax({
		url: 'cfg=1&_zones='+$.toJSON(mom.zones),
		complete: function(){busyC.zone = false;}
	});
}

function setOneCombiConfig(me){
	busyC.combi = true;
	var tag = me.attr('name').replace('combi-','');
	var c = parseInt(tag.substr(0,tag.indexOf('-')));
	var o = parseInt(tag.substr(tag.indexOf('-')+1,2));

	var b = hexToBinArr(mom.combies[c-1].outputs);
	b[64-o] = (me.is(':checked')) ? 1 : 0;
	mom.combies[c-1].outputs =  binArrToHex(b);
	
	if (!me.is(':checked')){
		var master = 'master-'+c.toString()+'-'+o.toString();
		if ($('input[name="'+master+'"]').is(':checked')){
			mom.combies[c-1].master = 0;
			$('input[name="'+master+'"]').removeAttr('checked');
		}
	}	
	setCombiConfig();
}

function setMaster(me){
	busyC.combi = true;
	var tag = me.attr('name').replace('master-','');
	var c = parseInt(tag.substr(0,tag.indexOf('-')));
	var o = parseInt(tag.substr(tag.indexOf('-')+1,2));
	if (me.is(':checked')){
		mom.combies[c-1].master = o;
		me.removeClass('master-input');
		$('.master-input:checked').removeAttr('checked');
		me.addClass('master-input');
		$('input[name="combi-'+c.toString()+'-'+o.toString()+'"]').attr('checked','checked');
		var b = hexToBinArr(mom.combies[c-1].outputs);
		b[64-o] = 1;
		mom.combies[c-1].outputs =  binArrToHex(b);
	}	
	else
		mom.combies[c-1].master = 0;	
	setCombiConfig();
}

function setOneZoneConfig(me){
	busyC.zone = true;
	var tag = me.attr('name').replace('zone-','');
	var z = parseInt(tag.substr(0,tag.indexOf('-')));
	var o = parseInt(tag.substr(tag.indexOf('-')+1,2));
	
	var b = hexToBinArr(mom.zones[z-1].outputs);
	b[64-o] = (me.is(':checked')) ? 1 : 0;
	mom.zones[z-1].outputs = binArrToHex(b);

	setZonesConfig();
}

function setCombiName(me){
	busyC.zone = true;
	var c = parseInt(me.attr('name').replace('combi-name',''));
	mom.combies[c-1].name = me.val();
	setCombiConfig();
}

function setPagingName(me){
	busyC.zone = true;
	var z = parseInt(me.attr('name').replace('paging-name',''));
	mom.zones[z-1].name = me.val();
	setZonesConfig();
}

function activatePagingCombi(){
	$('.combi-input').click(function(){
		setOneCombiConfig($(this));});
	$('.zone-input').click(function(){
		setOneZoneConfig($(this));});
	$('.master-input').click(function(){
		setMaster($(this));});
	$('.combi-name').blur( function(){
		setCombiName($(this));});
	$('.paging-name').blur( function(){
		setPagingName($(this));
	});
	$('.page-channel')
		.change(function(){
			var p = parseInt($(this).attr('name').replace('page-channel',''));
			mom.pages[p].channel = parseInt($(this).val());
			setPageChannel(p);
		})
	.mousedown(function(){busyP['channel'] = true;})
	.blur(function() {busyP['channel'] = false;});
}

function displayPagingCombiViewCombi(){
	for (var c = 1; c <= mom.config.max_combies; c++){
		$('input[name="combi-name'+c.toString()+'"]').val(mom.combies[c-1].name);
	}
	$('.combi-col').removeAttr('checked');
	for (var n = 1; n <= maxRooms(); n++){
		var o = room2Output(n);
		for (var c = 1; c <= mom.config.max_combies; c++){
			var b = hexToBinArr(mom.combies[c-1].outputs);
			combi = 'combi-'+c.toString()+'-'+o.toString();
			master = 'master-'+c.toString()+'-'+o.toString();
			if (b[64-o] == 1){
				$('input[name="'+combi+'"]').attr('checked','checked');
				if (mom.combies[c-1].master == o) 
					$('input[name="'+master+'"]').attr('checked','checked');
			}
		}
	}
}

function displayPagingCombiViewZones(){
	for (var z = 1; z <= mom.config.max_zones; z++){
		$('input[name="paging-name'+z.toString()+'"]').val(mom.zones[z-1].name);
	}
	for (var n = 1; n <= maxRooms(); n++){
		var o = room2Output(n);
		for (var z = 1; z <= mom.config.max_zones; z++){
			var b = hexToBinArr(mom.zones[z-1].outputs);
			name = 'zone-'+z.toString()+'-'+o.toString();
			if (b[64-o] == 1) 
				$('.paging-col input[name="'+name+'"]').attr('checked','checked');
			else
				$('.paging-col input[name="'+name+'"]').removeAttr('checked');
		}
	}
}

function displayPageInputOptions(pageNr){
	var view = xLateText('<option value="0">{not_selected}</option>');
	for (var c = 1; c <= maxChannels(); c++) {
		var i = channel2Input(c);
		if (inputType(i)=='AUX')
		view += '<option value="'+i.toString()+'">'+inputConnection(i)+'</option>';
	}
	if (!busyP['channel']){
		$('[name="page-channel'+pageNr.toString()+'"]').html(view);
		$('[name="page-channel'+pageNr.toString()+'"]').val(mom.pages[pageNr].channel.toString());
	}	
}

function displayAllPageInputOptions(){
		for (p = 1; p <= mom.config.max_pages; p++){
			displayPageInputOptions(p);
		}
}

function displayPagingCombilist() {
	var view = '';
	
	if (mom.config.max_zones == 1 && mom.config.max_combies == 1)
		$('.paging-combi-titles').css('height', 22);
	var pagingTitleZone = xLateKey('{Paging}');
	pagingTitleZone += xLateText(' <label>{Input}: </label> <select class="page-channel" name="page-channel1"></select>');
	if (mom.config.max_zones > 1){
		pagingTitleZone += '<br/>';
		for (i = 1; i <= mom.config.max_zones; i++){
			pagingTitleZone += '<span class="paging-name-col">'+ i.toString()+'</span>';
		}
	}
	$('#paging-combi-paging-title').html(pagingTitleZone);
	displayAllPageInputOptions();
		
	var combiTitle = xLateKey('{PartyMaster}');
	if (mom.config.max_combies > 1){
		combiTitle += '<br/>';
		for (i = 1; i <= mom.config.max_combies; i++){
			combiTitle += '<span class="combi-name-col">'+ i.toString()+'</span><span class="combi-col">&nbsp;</span>';
		}
	}
	$('#paging-combi-combi-title').html(combiTitle);
	
	if (board!='mac808_B'){
		$('#paging-combi-names').show();
		var combiNames = '';
		for (i = 1; i <= mom.config.max_combies; i++){
			combiNames += '<input class="combi-name combi-name-col" name="combi-name'+i.toString()+'" size="16" maxlength="16">';
		}
		$('.combi-names').html(combiNames);
		var pagingNames = '';
		for (i = 1; i <= mom.config.max_zones; i++){
			pagingNames += '<input class="paging-name paging-name-col" name="paging-name'+i.toString()+'" size="16" maxlength="16">';
		}
		$('.paging-names').html(pagingNames);
		
	} else {
		$('#paging-combi-names').hide();
	}
	
	for (var n = 1; n <= maxRooms(); n++){
		o = room2Output(n);
		row = pagingCombiHTML
		.replace(/_row_/g,n.toString())
		.replace('<output>',outputConnection(o))
		.replace('<name>',outputName(o));
		
		pagingRow = '';
		for (var i = 1; i <= mom.config.max_zones; i++){
			pagingRow += '<span class="paging-name-col"><span class="paging-col"><input class="zone-input" type="checkbox" name="zone-'+i.toString()+'-'+o.toString()+ '"/></span></span>';
		}
		row = row.replace('<paging>',pagingRow);
		
		combiRow = '';
		for (var c = 1; c <= mom.config.max_combies; c++){
			combiRow += '<span class="combi-name-col"><span class="combi-col"><input class="combi-input" type="checkbox" name="combi-'+c.toString()+'-'+o.toString()+ '"/></span>';
			combiRow += '<span class="master-col combi-col"><input class="master-input" type="radio" name="master-'+c.toString()+'-'+o.toString()+ '"/></span></span>';
		}
		row = row.replace('<combies>',combiRow);
		
		view += row;
	}
	$('#paging-combi-list').html(view);
	
	
	displayPagingCombiViewZones();
	displayPagingCombiViewCombi();
	activatePagingCombi();
	pagingCombiScrollRegion.update();

}

function initPagingCombiTab(){
	pagingCombiScrollRegion.update();
	if (board!='mac808_B') 
		chimeScrollRegion.update();
}

function chimeUploadChanged(){
	var fn = $('#upload-file-chime').val();
	if (fn){
		$('#upload-file-chime-name option').html($('#upload-file-chime').val());
	}	
}

function chimeUpload(){
	if (!$('#upload-file-chime-name option').html()) {
		alert(xLateText('{no_file_selected}'));
		return;
	}
	ajaxFileUpload('upload-file-chime','chime');
	$('#upload-file-chime-name option').html('');
}

function configPagingCombiView(){

	pagingCombiHTML = getHTML('html/config-output-paging-combi-view.html');
	document.write(getHTML('html/board/config-paging-combi-view.html'));	

	pagingCombiScrollRegion = $('#paging-combi-region');
	pagingCombiScrollRegion.tinyscrollbar();
	
	if (board!='mac808_B'){
		chimeScrollRegion = $('#chimesregion');
		chimeScrollRegion.tinyscrollbar();
	}	
	
	
	$('#upload-chime-start').click(chimeUpload);

	$('#upload-file-chime-area').click(function(){
		$('#upload-file-chime').trigger('click');
	});
		
	getZonesConfig();
	getCombiesConfig();
	getPages();

	mom.changed.output.register(displayPagingCombilist);
	mom.changed.input.register(displayAllPageInputOptions);
	mom.changed.zones.register(displayPagingCombiViewZones);
	mom.changed.combies.register(displayPagingCombiViewCombi);
	mom.changed.pages.register(displayAllPageInputOptions);
	mom.changed.chimes.register(displayGPIOChimes);
	mom.changed.gpio.register(displayGPIO);
	mom.changed.racks.register(displayGPIO2);
}
