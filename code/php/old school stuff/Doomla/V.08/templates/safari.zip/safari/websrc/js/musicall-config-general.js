setupScrollRegion = 0;
mom.changed.wc = new notifier();
mom.wc = {};


function flipRDSinfo(onOff) {
	mom.wc.wc_show_rds = (onOff)?1:0;//TEST moet naar 1 en 0
	mom.wc.wc_hide_setup = (mom.wc.wc_hide_setup==1)?1:0; //TEST
	setConfig('cfg=*&wc='+encodeURIComponent($.toJSON(mom.wc)));
}

function flipHideSetup(onOff) {
	mom.wc.wc_hide_setup = (onOff)?1:0; //TEST moet naar 1 en 0
	mom.wc.wc_show_rds = (mom.wc.wc_show_rds==1)?1:0; //TEST
	setConfig('cfg=*&wc='+encodeURIComponent($.toJSON(mom.wc)));
}

function flipPageRelVolumeSetup(onOff) {
	mom.page_rel_volume = (onOff)?1:0;
	setConfig('cfg=*&_page_rel_volume='+mom.page_rel_volume);
}

function parseWC(data) {
	if (dataChanged('wc',data)){
		mom.wc = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		mom.changed.wc.notify();
	}
}

function urlWC(){
	return 'cfg=1&wc=?';
}

function getWC () {
	balancedAjax({
		url			: urlWC(),
		async		: false,
		success	: parseWC
	});
}

function parseSetup(data){
	if (dataChanged('setup',data)){
		mom.setup = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]).replace(/=/g,':'));
		displaySetup();
	}
}

function urlSetup(){
	return 'cfg=*&setup_list=?';
}

function getSetup(){
	balancedAjax({
		url			: urlSetup(),
		async		: false,
		success	: parseSetup
	});
}

function activateSetup(){
	$('#setup-list input').click(function(){
		$('input[name="settingsfile"]').val($('#setup-list input:checked').val().replace(/.xml$/i,''));
	});
	$('input[name="settingsfile"]').blur(function(){
		var value = $(this).val()+'.xml';
		$('#setup-list input').removeAttr('checked');
		$('#setup-list input').each(function(){
			if (value == $(this).val()) $(this).attr('checked', true);
		});
	});
}

function displaySetup(){
	var value = $('#setup-list input:checked').val();
	var view = '';
	for (var c = 0; c < mom.setup.length; c++){
		view += '<li><span class="setup-item">'+mom.setup[c].name+'</span><input type="radio" name="setup-item" value="'+mom.setup[c].name+'" ' +
						((mom.setup[c].name==value)?'checked="checked"':'')+'/></li>';
	}
	$('#setup-list').html(view);
	setupScrollRegion.update();
	activateSetup();
	
}

function displayWCRDS() {
	if (mom.wc.wc_show_rds == 1)
		$('#wc-rdsinfo-check').attr('checked',true);
	else
		$('#wc-rdsinfo-check').removeAttr('checked');
}

function displayWCHideSetup() { // Attention: hide wordt vertaald naar show in GUI
	if (mom.wc.wc_hide_setup == 0)
		$('#wc-showsetup-check').attr('checked',true);
	else
		$('#wc-showsetup-check').removeAttr('checked');
}

function displayPageRelVolume() {
	if (mom.page_rel_volume == 1)
		$('#page-rel-volume-check').attr('checked',true);
	else
		$('#page-rel-volume-check').removeAttr('checked');
}

function displayLanguages(){
	var languages = xLateLanguages();
	var options = '';
	for (l in languages){
		options += '<option value="'+l+'">'+languages[l]+'('+l+')</option>';
	}
	$('#language select').html(options);
	$('#language select').val(mom.lang);
}

function initGeneralTab(){
	displayWCRDS();
	displayWCHideSetup();
	displayPageRelVolume();
	if (board=='mac808_B'){
		displayOutputSTMO();
		displayAmpList();
	}	
	displayLanguages();
}

function waitReboot(){
	balancedAjax({
		url : 'firm=1&config=?',
		success : function(){
								window.location.reload(true);
							},
		error : function(){
							setTimeout("waitReboot();",1000);
						}
	});	
}

function factoryRestore(){
	var restoreScope = 0;
	$('#factory-restore input:checked').each(function(){
		restoreScope += parseInt($(this).val());
	});
	if(restoreScope > 0){
		$('#restore-waiting').html(xLateText('<p>{wait_restart}</p><p><img src="../css/images/wait01.gif"/></p>'));
		canPoll = false;
		balancedAjax({
			url : 'cfg=*&_restore='+restoreScope,
			success : function(){
									setTimeout("waitReboot();",1000);
								},
			error : 	function(){
									$('#restore-waiting').html('');
								}			
		});
	}	
}

function setupExist(fn){
	var exist = false;
	$('#setup-list input').each(function(){
		if ($(this).val() == fn) exist = true;
	});
	return exist;
}

function setupDelete(){
	var mySettingsFilename = $('input[name="settingsfile"]').val();
	if (mySettingsFilename && setupExist(mySettingsFilename+'.xml')){
		balancedAjax({
			url : 'setup=*&remove='+mySettingsFilename+'.xml'
		});
	}
}

function setupDownload(){
	var mySettingsFilename = $('input[name="settingsfile"]').val();
	if (mySettingsFilename && setupExist(mySettingsFilename+'.xml')){
		window.location = mySettingsFilename+'.xml?loc=setup';
	}	
}

function setupUploadChanged(){
	var fn = $('#upload-file-setup').val();
	if (fn){
		var m = fn.match(/\.xml$/gi)
		if (m) $('#upload-file-setup-name option').html($('#upload-file-setup').val());
	}	
}

function setupUpload(){
		if (!$('#upload-file-setup-name option').html()) {
			alert(xLateText('{no_file_selected}'));
			return;
		}
		ajaxFileUpload('upload-file-setup','setup');
		$('#upload-file-setup-name option').html('');
}

function myRestore(){
	var mySettingsFilename = $('input[name="settingsfile"]').val();
	if (mySettingsFilename && setupExist(mySettingsFilename+'.xml')){
		$('#restore-waiting').html(xLateText('<p>{wait_restart}</p><p><img src="../css/images/wait01.gif"/></p>'));
		canPoll = false;
		balancedAjax({
			url : 'setup=*&load='+mySettingsFilename+'.xml',
			//url : 'cfg=*&stamp=dummy',
			success : function(){
									setTimeout("waitReboot();",1000);
								},
			error : 	function(){
									setTimeout("waitReboot();",1000);
								},
			timeout : 2000					
		});
	}
}

function mySave(){
	var mySettingsFilename = $('input[name="settingsfile"]').val();
	if (mySettingsFilename){
		balancedAjax({
			url : 'setup=*&save='+mySettingsFilename+'.xml'
		});
	}
}

function ajaxFileUpload(tag, type){
	//starting setting some animation when the ajax starts and completes
	//$("#loading")
	
	$.ajaxFileUpload
	(
		{
			url:'doajaxfileupload.php?type='+type, 
			secureuri:false,
			fileElementId:tag,
			dataType: 'json',
			success: function (data, status)
			{
				if(typeof(data.error) != 'undefined') {
					if(data.error != '') {
						alert(data.error);
					} else {
						alert(data.msg);
					}
				}
			},
			error: function (data, status, e)
			{
				alert(e);
			}
		}
	)
	return false;
}
	
function configGeneralView(){
	document.write(getHTML('html/board/config-general-view.html'));	

	setupScrollRegion = $('#setupregion');
	setupScrollRegion.tinyscrollbar();
	initGeneralTab();

	$('#wc-rdsinfo-check').change(function(){
		flipRDSinfo($('#wc-rdsinfo-check').is(':checked'));
	});

	$('#wc-showsetup-check').change(function(){
		flipHideSetup(!$('#wc-showsetup-check').is(':checked'));
	});
		
	$('#page-rel-volume-check').change(function(){
		flipPageRelVolumeSetup($('#page-rel-volume-check').is(':checked'));
	});
	
	$('#language select').change(function(){
		mom.lang = $('#language select').val();
		setConfig('cfg=*&_lang='+mom.lang+''); // got hack , aanpassen in volgende firmware
		setTimeout("window.location.reload(true);",200);
	});

	$('#factory-restore button').click(factoryRestore);
	
	$('#my-restore-start').click(myRestore);
	
	$('#my-save-start').click(mySave);
	
	$('#delete-setup-start').click(setupDelete);

	$('#download-setup-start').click(setupDownload);

	$('#upload-setup-start').click(setupUpload);
	
	$('#upload-file-setup-area').click(function(){
		$('#upload-file-setup').trigger('click');
	});
	
	$('#factory-restore input').removeAttr('checked');
	
	mom.changed.wc.register(displayWCRDS);
	mom.changed.wc.register(displayWCHideSetup);
	if (board=='mac808_B'){
		mom.changed.output.register(displayOutputSTMO); 
		mom.changed.output.register(displayAmpList); 
	}
}