var board = 'musicall_D';

function boardInit (aForConfig)
{
	if (aForConfig)
		document.title="Dateq MusicAll Configuration";
	else
		document.title="Dateq MusicAll";
}

function boardPostInit (aForConfig)
{
	if (aForConfig) {
		// Because MusicAll doesn't have an amplitier
		$('#room-amplifier').css('visibility','hidden');
	}
	$('#temperature').css('visibility', 'hidden');
}
