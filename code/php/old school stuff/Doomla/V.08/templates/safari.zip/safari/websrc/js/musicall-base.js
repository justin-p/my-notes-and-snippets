websrcVersion = '2.32n';
audioPrefix = '/audio_set?';
mom = {"previous" : {}, "changed" : {}}; // Musicall Object Model;
forceDisplay = new Object();

$.exists = function(selector) {
	return ($(selector).length > 0);
}

function dataChanged(tag, data){ 
	if (!mom.previous[tag] || mom.previous[tag] != data){
		mom.previous[tag] = data;
		return true; 
	}
	return false;
}

function notifier(id){
	this.changed = false;
	this.handlers = new Array;
	this.alreadyNotified = false;
	this.id = (id)?id:'anonymous';
	
	this.register = function(handler){
		this.handlers[this.handlers.length] = handler;
		if (this.alreadyNotified) handler();
	}
	this.notify = function(dictator){
		if (!dictator) var dictator = '';
		for (var h in this.handlers) this.handlers[h](dictator);
		this.alreadyNotified = true;
		this.changed = false;
	}
}

function binArrToHex(binArr){
	var hexString = '';
	var hexString8 = '';
	var b = 0;
	var n = 0;
	var nibble = 0;
	while (b < binArr.length){
		nibble = nibble << 1;
		nibble += binArr[b];
		if (++n > 3){
			hexString8 += nibble.toString(16);
			if (hexString8.length == 8){
				while ((hexString8.length > 0) && (hexString8.charAt(0) == '0')) hexString8 = hexString8.substr(1,hexString8.length-1);
				if (hexString8.length > 0) hexString += ((hexString.length > 0)?'.':'') + '0x'+hexString8;
				hexString8 = '';
			}
			n = 0;
			nibble = 0;
		} 
		b++;
	}
	if (hexString.length == 0) hexString = '0x0';
	return hexString;
}

function hexToBinArr(hexString){
	if (typeof hexString == 'undefined') hexString = '0x0000';
	hexString = hexString.replace(/0x/g,'').replace('.','');
	var binArr = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	var b = binArr.length;
	for (var c = hexString.length - 1; c >= 0; c--){
		nibble = parseInt(hexString[c],16);
		for (var n = 1; n <= 4; n++){
			b--;
			binArr[b] = nibble & 1;
			nibble = nibble >> 1;
		}
	}
	return binArr;
}

var lastLogTime = 0;

function logPrintf(msg){
	var logTime = jQuery.now ();
	var deltaT = lastLogTime ? logTime - lastLogTime : 0;
	console.log (deltaT + " : " + msg);
	lastLogTime = logTime;
}

function message(msg, blink) {
	$('#message').text(msg);
	$('#message').css('visibility', 'visible');
	if (blink) {
		setTimeout(function(){
			$('#message').css('visibility', 'hidden');
			$('#message').text('');
		},4000);
	}
}



