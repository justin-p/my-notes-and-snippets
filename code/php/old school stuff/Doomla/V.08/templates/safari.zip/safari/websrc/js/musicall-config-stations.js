var stationScrollRegion = 0;
mom.changed.stations = new notifier();

var autosearchReady = true;
var testTuner = 4;

var busyP = false;

function initStationScrollRegion(){
	if ( typeof stationScrollRegion.updated == 'undefined' ) {
		stationScrollRegion.update();
		stationScrollRegion.updated = true;
	} 
}

function parseResetStations(data) {
	if (data.indexOf('auto_search=0') > 0) {
		autosearchReady = true;
		$('#reset-stations-waiting').html('');
	} 
}

function pollResetStations() {
	if (!autosearchReady) {
		balancedAjax({
			url			: 'radio='+testTuner+'&auto_search=?',
			success	: parseResetStations
		});
		setTimeout(pollResetStations,1000);
	}	
}

function resetStations() {
	$('#reset-stations-waiting').html('<img src="../css/images/wait01.gif"/>');
	autosearchReady = false;
	balancedAjax({
		url			: 'radio='+testTuner+'&auto_search=1',
		success	: function(data) {setTimeout(pollResetStations,1000);} //start polling when chance of success
	});
}

function saveStations() {
	balancedAjax({
		url			: 'cfg=1&preset_list=' + encodeURIComponent($.toJSON(mom.stations)),
		success : function(data){mom.changed.stations.notify();}
	});
}

function freqDisplay(freq) {
	return (freq > 0)?(freq/100).toFixed(2):'';
}

function freqRack(freq) {
	return  Number((freq * 100).toString());
}

function displayStations() {
	for (var p in mom.stations) {
		var i = parseInt(p) + 1;
		$('#station-row' + i + ' input.station-name')
			.val(mom.stations[p].name)
			.attr('tabindex',300+i)
			.removeAttr('disabled');
		$('#station-row' + i + ' span.station-freq').text(freqDisplay(mom.stations[p].freq));
		$('#station-row' + i)
			.draggable( "option", "disabled", false )
			.droppable( "option", "disabled", false );
	}
	for (p = mom.stations.length+1; p <= mom.config.max_presets; p++) {
		$('#station-row' + p + ' span.station-freq').text('');
		$('#station-row' + p)
			.droppable( "option", "disabled", ((p == mom.stations.length+1)?false:true))
			.draggable( "option", "disabled", true );

		$('#station-row' + p + ' input.station-name')
			.val('')
			.attr('disabled','disabled');
	}
}

function parseStations(data) {
	if (dataChanged('stations',data)) {
		mom.stations = jQuery.parseJSON(decodeURIComponent(data.split('&')[1].split('=')[1]));
		displayStations();
		mom.changed.stations.notify();
	}	
}

function urlStations(){
	return 'cfg=*&preset_list=?';
}

function getStations(){
	if (busyP || !autosearchReady) return;
	balancedAjax({
		url			: urlStations(),
		async		: false,
		success	: parseStations
	});
} 

function freq2Station(freq){
	for (var s in mom.stations) if (mom.stations[s].freq == freq) return s;
	return '';
}

function name2Station(name) {
	for (var s in mom.stations) if (mom.stations[s].name == name) return s;
	return '';
}

function tunerControl(id, tuner, pollingCycle, active) {
	// constructor
	this.id = id;
	this.tuner = tuner;
	this.active = active;
	this.pollingCycle = pollingCycle;
	this.pollStatus = 0;
	this.GUI = null;

	this.view = function () {
		return getHTML('html/config-tuner-control.html').replace('<tuner-context>',this.id);
	}
	
	this.freq = function() {
		return freqRack($('.tuner-freq-actual.front',this.GUI).text());
	}
	
	this.station = function() {
		return freq2Station(this.freq());
	}
	
	this.seekFMchannel = function(dir) {
		balancedAjax({
			url: 'radio='+this.tuner+'&seek='+dir+'1',
		});
		this.pollStatus = 0;
	}

	this.tuneFMchannel = function(freq, dir) {
		var f = parseFloat(freq)
		if (dir == '+') f += mom.radio.step/100; 
		if (dir == '-') f -= mom.radio.step/100; 
		if (f > mom.radio.max_freq/100) f = mom.radio.min_freq/100;		
		if (f < mom.radio.min_freq/100) f = mom.radio.max_freq/100;
		balancedAjax({
			url: 'radio='+this.tuner+'&fmchannel='+freqRack(f),
		});
		this.pollStatus = 0;
	}

	this.changeFreq = function() {
		this.tuneFMchannel($('.tuner-freq',this.GUI).val(),'');
		$('.tuner-freq-actual',this.GUI).addClass('front');
	}

	this.parseOneFreq = function(data, me){
		var settings = jQuery.parseJSON(data.split('&')[1].split('=')[1]); 
		for (var s in settings) {
			switch (s){
				case 'freq'	: $('.tuner-freq',me.GUI).val(freqDisplay(settings[s])); $('.tuner-freq-actual.front',me.GUI).text(freqDisplay(settings[s])); break; 
				case 'rds'	: $('.station-rds span',me.GUI).text(decodeURIComponent(settings[s])); break;
				case 'rssi'	: $('.station-rssi span',me.GUI).text(decodeURIComponent(settings[s])); break;
				case 'pi'		: $('.station-pi span',me.GUI).text(decodeURIComponent(settings[s])); break;
				case 'ps'		: $('.station-name span',me.GUI).text((settings.pi != '0x0000')?decodeURIComponent(settings[s]):'unknown'); break;
			}
		}		
	}

	this.urlPollOneFreq = function(me) {
		if ((me.tuner > 0) && me.active() && ($('.tuner-freq-actual',me.GUI).hasClass('front'))) {
			me.pollStatus++; if (me.pollStatus < 0) pollStatus = 10; // reset overflow
			if ((me.pollStatus <= 2)  || (me.pollStatus % 2 == 0)) {
				return 'radio='+me.tuner+'&rds_info=?';
			}
		}	
		return '';
	}
	
	this.pollInfo = function(){
		return this;
	}

	this.pollFreq = function(){
			registerPoll(['config-stations'],{id : 'setting', weight : 5},{url: this.urlPollOneFreq, success: this.parseOneFreq, info : this.pollInfo});		
	}

	this.activate = function() {
		this.GUI = $('#'+this.id);
		var me = this;
		$('.tuner-next',me.GUI).mousedown(function(){me.tuneFMchannel($('.tuner-freq',me.GUI).val(),'+');});
		$('.tuner-prev',me.GUI).mousedown(function(){me.tuneFMchannel($('.tuner-freq',me.GUI).val(),'-');});
		$('.tuner-seek-next',me.GUI).mousedown(function(){me.seekFMchannel('+');});
		$('.tuner-seek-prev',me.GUI).mousedown(function(){me.seekFMchannel('-');});
		$('.tuner-freq-actual',me.GUI).dblclick(function(){
			$(this).removeClass('front');
			$('.tuner-freq',me.GUI).focus();
		});
			
		$('.tuner-freq',me.GUI).blur(function(){me.changeFreq();})
										.dblclick(function(event){event.preventDefault(); me.changeFreq();})
										.keypress(function(event){

			k = event.which
			if ((k == 13)) {
				event.preventDefault();
				me.changeFreq();
			}	
		});
		
		$('.tuner-preset-freq',me.GUI).click(function(event){
			freqPreset('station-row200',$('.station-rds span',me.GUI).text(), $('.tuner-freq-actual',me.GUI).text(),$('.station-rssi span',me.GUI).text());
		});
		this.pollFreq();
	}
} // tunerControl

function freqPreset(id, rds, freq, rssi){
	var f = freqRack(freq);
	var e = freq2Station(f);
	if (e > '') mom.stations[e].freq = 0; // mark to be deleted
	if ((e == '') && (mom.stations.length == mom.config.max_presets)) {
		alert(xLateText('{maximum_presets_reached_at}')+' '+mom.config.max_presets);
		return;
	}	
	var i = parseInt(id.replace('station-row','')) - 1;
	if (i > mom.stations.length) i = mom.stations.length;
	
	var newStation = new Object();
	newStation.name = rds;
	newStation.freq = f;
	newStation.rssi = Number(rssi);
	mom.stations.splice(i,0,newStation);
	if (e > '') mom.stations.splice(freq2Station(0),1);
	setTimeout(function(){displayStations(); saveStations();},5);
}

function presetMove(id, targetId) {
	var moveStation = mom.stations[parseInt(id.replace('station-row','')) - 1];
	var targetFreq = 0;
	var t = parseInt(targetId.replace('station-row','')) - 1;
	if (t < mom.stations.length) targetFreq = mom.stations[t].freq;
	mom.stations.splice(parseInt(id.replace('station-row','')) - 1,1);
	if (targetFreq > 0)
		mom.stations.splice(freq2Station(targetFreq),0,moveStation);
	else
		mom.stations.splice(mom.stations.length,0,moveStation);
	setTimeout(function(){displayStations(); saveStations();},5);
}

function presetDrop (event,ui) {
	cl = ui.draggable.attr('class');
	targetId = $(this).attr('id');
	if (cl.indexOf('tuner-freq-actual') == 0) freqPreset(targetId, $('.station-rds span',stationsTuner.GUI).text(),ui.draggable.text(),$('.station-rssi span',stationsTuner.GUI).text());
	if (cl.indexOf('station-preset') == 0) presetMove(ui.draggable.attr('id'), targetId);
}
function reDisplayStations(id) {
	displayStations();
	saveStations();
}

function presetDelete (event, ui) {
	id = ui.draggable.attr('id');
	mom.stations.splice(parseInt(id.replace('station-row','')) - 1,1);
	setTimeout(function(){reDisplayStations(id)},100);
}	

function configStationsView(){
	var view = getHTML('html/config-stations-view.html');

	var stationPreset = getHTML('html/config-station-preset-view.html');
	var stationSelection = '';
	for (var i = 1; i <= mom.config.max_presets; i++)
		stationSelection += stationPreset.replace(/_row_/g,i.toString());
	
	stationsTuner = new tunerControl('stations-tuner',testTuner,pollCycle, function(){ return selectedTab() == 'config-stations';});
	registerPoll(['config-stations'],{id : 'setting', weight : 5},{url: stationsTuner.urlPollOneFreq, success: stationsTuner.parseOneFreq, info : stationsTuner});		

	view = view.replace('<station-selection>',stationSelection)
					.replace('<tuner-control>',stationsTuner.view());
	
	document.write(view);	
	
	getStations();
	
	stationsTuner.activate();

	$('.station-name').change(function(){
		id = Number($(this).attr('name').replace('station-name',''))-1;
		mom.stations[id].name = $(this).val();
		saveStations();	});
	$('.station-name').focus(function(){
		var s = name2Station($(this).val());
		stationsTuner.tuneFMchannel(freqDisplay(mom.stations[s].freq),'');
	});
	
	$(".tuner-freq-actual.front",stationsTuner.GUI).draggable({
		opacity: 0.50,
		helper:'clone'
	});  
	
	$("#thrash").droppable({
		hoverClass	: "station-hit",
		accept			: ".station-preset",
		drop				: presetDelete
	 });
 
 	$(".station-preset").droppable({
		hoverClass	: "station-hit",
		accept			: ".tuner-freq-actual.front, .station-preset",
		drop				: presetDrop
	 });
	 $(".station-preset").draggable({
		appendTo : '#config-stations',
		opacity: 0.50,
		helper:'clone'
	 });
				
	$('#reset-stations-button').click(function(){
		if (mom.stations.length == 0)
			resetStations();
		else 
			  jConfirm(xLateKey('create_new_list_radio_presets'), 'New List', function(r) {
				if (r) resetStations();
			});
	});

	stationScrollRegion = $('#stationsregion');
	stationScrollRegion.tinyscrollbar();
}

	
