function configZonesView(){
	var view = getHTML('html/config-zones-view.html');
	var titles = '';
	for (var i=1; i <= 16 ; i++) {
		titles += '<span class="zone-title">'+i.toString()+'</span>';
	}
	view = view.replace('<zone-titles>',titles);
	
	// var stationPreset = getHTML('html/config-station-preset-view.html');
	//var stationSelection = '';
	//for (var i = 1; i <= mom.config.max_presets; i++)
		//stationSelection += stationPreset.replace(/_row_/g,i.toString());

	document.write(view);	
}