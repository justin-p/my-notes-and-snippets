canPoll = true; //global switch to prevent polling, when needed
busyPollGrp = false;
fakePoll = 'cfg=1&stamp=fake';
getPollingTab = function(){ // to be changed when tab-handler is needed and in place
	return '';
}

pollingScheme = [];
function getTabPoll(tab){
	for (var t in pollingScheme){
		if (pollingScheme[t].tab == tab) return pollingScheme[t];
	}
	t = pollingScheme.length;
	pollingScheme[t] = {};
	pollingScheme[t].tab = tab;
	pollingScheme[t].grp = [];
	return pollingScheme[t];
}

function getGrpPoll(tabPoll, grp){
	for (var g in tabPoll.grp){
		if (tabPoll.grp[g].id == grp.id) return tabPoll.grp[g];
	}
	g = tabPoll.grp.length;
	tabPoll.grp[g] = {};
	tabPoll.grp[g].id = grp.id;
	tabPoll.grp[g].weight = 1;
	tabPoll.grp[g].poll = [];
	tabPoll.grp[g].total = 0;
	return tabPoll.grp[g];
}

function registerPoll(tab, grp, poll){ 
	for (var t in tab){
		var tabPoll = getTabPoll(tab[t]);
		var grpPoll = getGrpPoll(tabPoll,grp);
		if (grp.weight) grpPoll.weight = grp.weight;
		if (!poll.info) poll.info = false;
		grpPoll.poll[grpPoll.poll.length] = poll;
	}
}

function pollGrpTabNr(tab){
	for (var t = 0; t < pollingScheme.length; t++){
		if (pollingScheme[t].tab == tab) return t;
	}
	return -1;
}

function getNextRelevantPollGrp(tabNr){
	var topGrp = -1;
	var topTotal = -1;
	for (var g = 0; g < pollingScheme[tabNr].grp.length; g++){
		if (pollingScheme[tabNr].grp[g].relevant && pollingScheme[tabNr].grp[g].total > topTotal){
			topTotal = pollingScheme[tabNr].grp[g].total;
			topGrp = g;
		}	
	}
	return topGrp;
}

function setPollGrpRelevant(tabNr){
	for (var g = 0; g < pollingScheme[tabNr].grp.length; g++)
		pollingScheme[tabNr].grp[g].relevant = true;
}

function pollGrpUrlRelevant(tabNr, grpNr){
	var url = '';
	var next;
	var urlRelevant = false;
	for (var p = 0; p < pollingScheme[tabNr].grp[grpNr].poll.length; p++){
		next = pollingScheme[tabNr].grp[grpNr].poll[p].url(pollingScheme[tabNr].grp[grpNr].poll[p].info);
		if (next == '') 
			next = fakePoll; // dummy request to fill up and maintain poll order
		else {
			next = next.replace(/&&/g,'&stamp=II&&'); //prevent special groups from being interpreted as pollgroups
			urlRelevant = true;
		}	
		url += ((url!='')?'&&':'') + next;
	}
	if (urlRelevant) 
		 pollingScheme[tabNr].grp[grpNr].url = url;
	return urlRelevant;
}

function setBusyPollGrp(tab){
	var tabNr = pollGrpTabNr(tab);
	if (tabNr < 0) return false;
	setPollGrpRelevant(tabNr);
	var relevantGrpFound = false;
	var grpNr;
	do {
		grpNr = getNextRelevantPollGrp(tabNr);
		if (grpNr >= 0){
			if (!pollGrpUrlRelevant(tabNr, grpNr)){
				pollingScheme[tabNr].grp[grpNr].relevant = false;
				pollingScheme[tabNr].grp[grpNr].total = 0;
			} else relevantGrpFound = true;
		}
	} while(!relevantGrpFound && grpNr >= 0);
	if (relevantGrpFound) 
		busyPollGrp = pollingScheme[tabNr].grp[grpNr];
}

function incrementPollGrp(tab){
	for (var t = 0; t < pollingScheme.length; t++){
		if (pollingScheme[t].tab == tab){
			for (var g = 0; g < pollingScheme[t].grp.length; g++)
				pollingScheme[t].grp[g].total += pollingScheme[t].grp[g].weight;
		} else {
			for (var g = 0; g < pollingScheme[t].grp.length; g++)
				pollingScheme[t].grp[g].total = 0; 
		}
	}
}

function grpPollSuccess(data){
	data = data.replace(/&stamp=II&&/g,'&'); //prevent special groups from being interpreted as pollgroups
	dataArr = data.split('&&');
	for (var p in busyPollGrp.poll){
		if (busyPollGrp.poll[p].success &&  dataArr[p].indexOf(fakePoll) == -1)
		{
			busyPollGrp.poll[p].success(dataArr[p],busyPollGrp.poll[p].info);
		}	
	}
}

function grpPollError(XMLHttpRequest, textStatus, errorThrown) {
	for (var p in busyPollGrp.poll)
		if (busyPollGrp.poll[p].error)
			busyPollGrp.poll[p].error(XMLHttpRequest, textStatus, errorThrown);
}

function grpPollComplete(){
	for (var p in busyPollGrp.poll)
		if (busyPollGrp.poll[p].complete)
			busyPollGrp.poll[p].complete();
	busyPollGrp.total = 0;	
	busyPollGrp = false;
}

function grpPoll(){
	return balancedAjax({
									url 		: busyPollGrp.url,
									async		: true,
									isPoll	: true,
									success : grpPollSuccess,
									error		: grpPollError,
									complete: grpPollComplete
	});
}

function doPoll(){
	if (canPoll && (!busyPollGrp)){ // prevent paralel polling
		setBusyPollGrp(getPollingTab());
		if (busyPollGrp){
			if (grpPoll()){
				busyPollGrp.url = '';
				busyPollGrp.total = 0;			
				incrementPollGrp(getPollingTab());
			}	else busyPollGrp = false;
		}
	}
}

function Polling(){
	doPoll();
	setTimeout(Polling,tripTimeGet(pollCycle));
}

Polling();
